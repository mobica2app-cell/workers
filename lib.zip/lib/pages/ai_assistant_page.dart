import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:universal_html/html.dart' as html;

class AiAssistantPage extends StatefulWidget {
  const AiAssistantPage({super.key});
  @override
  State<AiAssistantPage> createState() => _AiAssistantPageState();
}

class _AiAssistantPageState extends State<AiAssistantPage> {
  final _controller = TextEditingController();
  final _scrollController = ScrollController();
  final List<_ChatMessage> _messages = [];
  bool _busy = false;

  @override
  void dispose() {
    _controller.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  Future<void> _send([String? quickPrompt]) async {
    final question = (quickPrompt ?? _controller.text).trim();
    if (question.isEmpty || _busy) return;
    final username = html.window.localStorage['remembered_username'] ?? '';
    final password = html.window.localStorage['remembered_password'] ?? '';
    if (username.isEmpty || password.isEmpty) {
      _addMessage(const _ChatMessage(
        text: 'Login credentials were not found. Please sign in again.',
        isUser: false,
      ));
      return;
    }
    setState(() {
      _messages.add(_ChatMessage(text: question, isUser: true));
      _controller.clear();
      _busy = true;
    });
    try {
      final result = await Supabase.instance.client.functions.invoke(
        'mood-ai',
        body: {'username': username, 'password': password, 'question': question},
      );
      final data = result.data;
      if (result.status < 200 || result.status >= 300) {
        throw Exception(data is Map ? (data['error'] ?? 'Request failed') : 'Request failed');
      }
      final answer = data is Map ? (data['answer'] ?? '').toString() : '';
      _addMessage(_ChatMessage(
        text: answer.isEmpty ? 'No answer was returned.' : answer,
        isUser: false,
      ));
    } catch (e) {
      _addMessage(_ChatMessage(
        text: 'Could not contact MOOD AI. Deploy the mood-ai Edge Function and configure its secrets.\n\nDetails: $e',
        isUser: false,
      ));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _addMessage(_ChatMessage message) {
    if (!mounted) return;
    setState(() => _messages.add(message));
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 250),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final fg = dark ? Colors.white : const Color(0xFF0F172A);
    final surface = dark ? const Color(0xFF121212) : Colors.white;
    return Scaffold(
      appBar: AppBar(title: const Row(children: [
        Icon(Icons.auto_awesome, color: Color(0xFF2563EB)),
        SizedBox(width: 10), Text('MOOD AI'),
      ])),
      body: Column(children: [
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(14),
          color: dark ? const Color(0xFF101827) : const Color(0xFFEFF6FF),
          child: Text('Read-only assistant • sap_main_orders + sap_done_orders',
              style: TextStyle(color: fg, fontSize: 12)),
        ),
        if (_messages.isEmpty)
          Padding(
            padding: const EdgeInsets.all(16),
            child: Wrap(spacing: 8, runSpacing: 8, children: [
              _suggestion('Summarize current orders'),
              _suggestion('Compare main and done orders'),
              _suggestion('Find delayed orders'),
              _suggestion('لخص حالة الطلبات الحالية'),
              _suggestion('قارن بين الطلبات الحالية والمنتهية'),
            ]),
          ),
        Expanded(child: ListView.builder(
          controller: _scrollController,
          padding: const EdgeInsets.all(16),
          itemCount: _messages.length + (_busy ? 1 : 0),
          itemBuilder: (context, index) {
            if (_busy && index == _messages.length) {
              return const Padding(padding: EdgeInsets.all(12),
                child: Align(alignment: Alignment.centerLeft,
                  child: CircularProgressIndicator()));
            }
            final m = _messages[index];
            return Align(
              alignment: m.isUser ? Alignment.centerRight : Alignment.centerLeft,
              child: Container(
                constraints: const BoxConstraints(maxWidth: 760),
                margin: const EdgeInsets.only(bottom: 12),
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: m.isUser ? const Color(0xFF2563EB) : surface,
                  borderRadius: BorderRadius.circular(16),
                  border: m.isUser ? null : Border.all(color: dark ? Colors.white12 : Colors.black12),
                ),
                child: SelectableText(m.text,
                  style: TextStyle(color: m.isUser ? Colors.white : fg, height: 1.5)),
              ),
            );
          },
        )),
        SafeArea(top: false, child: Padding(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
          child: Row(children: [
            Expanded(child: TextField(
              controller: _controller, minLines: 1, maxLines: 5,
              onSubmitted: (_) => _send(),
              decoration: const InputDecoration(
                hintText: 'Ask about orders… / اسأل عن الطلبات…',
                border: OutlineInputBorder(),
              ),
            )),
            const SizedBox(width: 8),
            IconButton.filled(onPressed: _busy ? null : () => _send(),
              icon: const Icon(Icons.send), tooltip: 'Send'),
          ]),
        )),
      ]),
    );
  }

  Widget _suggestion(String text) => ActionChip(
    label: Text(text), onPressed: _busy ? null : () => _send(text));
}

class _ChatMessage {
  final String text;
  final bool isUser;
  const _ChatMessage({required this.text, required this.isUser});
}
