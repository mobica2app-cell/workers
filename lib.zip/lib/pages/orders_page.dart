// lib/pages/orders_page.dart
import 'dart:async';
import 'dart:convert';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:mobitem/pages/employee_managment_page.dart';
import 'package:mobitem/services/product_tracking_service.dart';
import 'package:mobitem/pages/track_order.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:universal_html/html.dart' as html;
import '../main.dart';
import '../models/employee_model.dart';
import '../models/product_tracking_model.dart';
import '../services/audit_service.dart';
import '../services/csv_export_service.dart';
import '../services/employee_service.dart';
import '../services/sap_service.dart';
import 'excel_dialog.dart';
import 'login_page.dart';
import 'order_detail_page.dart';

extension FirstOrNull<T> on Iterable<T> {
  T? get firstOrNull => isEmpty ? null : first;
}

class OrdersPage extends StatefulWidget {
  final SAPMainService sapService;
  final EmployeeAuth? loggedInEmployee;
  /// When true, reuse the same full table UI and combine main + archived SAP orders.
  final bool doneOrdersOnly;
  final bool readOnly;
  /// Reuses the Orders layout for the separate approval-tracking view.
  final bool approvalTrackingMode;

  const OrdersPage({
    super.key,
    required this.sapService,
    this.loggedInEmployee,
    this.doneOrdersOnly = false,
    this.readOnly = false,
    this.approvalTrackingMode = false,
  });

  @override
  State<OrdersPage> createState() => _OrdersPageState();
}

class _OrdersPageState extends State<OrdersPage> {
  // Data - Using SAPMainOrder instead of SAPOrderHeader
  List<SAPMainOrder> _allOrders = [];
  List<SAPMainOrder> _doneOrders = [];
  // Approval milestone values derived from order_audit_log, keyed by order ID.
  final Map<String, Map<String, String>> _approvalTrackingByOrder = {};
  // IDs originating from sap_done_orders when this page combines both tables.
  final Set<String> _archivedOrderIds = <String>{};
  bool _doneOrdersExpanded = false;
  bool _doneOrdersLoading = false;
  bool _doneOrdersLoaded = false;
  bool _isLoading = false;
  String _searchQuery = '';
  List<SAPMainOrder>? _searchResults;
  Timer? _searchDebounce;
  int _searchRequestId = 0;
  bool _isSearchingAllOrders = false;
  bool _searchExpanded = false;
  final FocusNode _searchFocusNode = FocusNode();
  String? _filterDesignTeam;
  bool _filterMyWork = false;
  String? _selectedWorkEmployee; // Head-only employee work selector
  bool _editMode = false;
  String _sortBy = 'item_asc'; // 'default', 'value_asc', 'value_desc', 'date_asc', 'date_desc'
  String _approvalContractFilter = 'all';

  // Fast O(1) Lookups & Pre-computed Lists
  Map<SAPMainOrder, int> _orderIndexMap = {};
  List<dynamic> _flatList = [];

  // Controllers
  final TextEditingController _searchController = TextEditingController();
  final ScrollController _horizontalScrollController = ScrollController();
  final ScrollController _leftVerticalScrollController = ScrollController();
  final ScrollController _rightVerticalScrollController = ScrollController();
  bool _isSyncing = false;
  List<EmployeeAuth> _allEmployees = [];

  // Factory/SLoc descriptions loaded from Supabase `factory_names`.
  // Key = SLoc/factory code, Value = description.
  Map<String, String> _factoryDescriptions = {};
  // Preserve the exact Supabase SLoc code while descriptions are indexed case-insensitively.
  Map<String, String> _factoryCodes = {};

  // Selection
  final Set<String> _selectedRowsIds = {};

  bool _isOrderSelected(SAPMainOrder order) => _selectedRowsIds.contains(order.id);

  // Services
  final EmployeeService _employeeService = EmployeeService();
  final ProductTrackingService _trackingService = ProductTrackingService();

  // Caches
  Map<String, ProductTracking> _allTrackingCache = {};
  Map<String, List<JobAssignment>> _jobsCache = {};
  final Map<String, Employee?> _employeeCache = {};

  String? _editingField; // Which field is being edited (orderId_field)
  final Map<String, TextEditingController> _editControllers = {};
  // Per-cell debounce and save state for live inline editing.
  final Map<String, Timer> _inlineSaveTimers = {};
  final Map<String, String> _inlineLastSavedValues = {};
  final Set<String> _inlineSavingKeys = {};

  // Filters
  String? _filterStatus;
  String? _filterFactory;
  String? _filterSalesEngineer;
  String? _filterResponsibleEngineer;
  String? _filterReviewer;
  String? _filterCorrespondenceEngineer;
  List<String> _sortedStatuses = [];

  String? _lastSelectedOrderId;

  // Expandable sections+
  final Set<String> _expandedSections = {};
  Map<String, List<SAPMainOrder>> _groupedOrders = {};

  List<String> _allStatuses = [];

  // Columns pinned beside the Name column.
  // Name itself is always pinned and is not included here.
  final Set<String> _pinnedColumns = <String>{};

  bool _isColumnPinned(String column) {
    return _pinnedColumns.contains(column);
  }

  void _toggleColumnPin(String column) {
    setState(() {
      if (_pinnedColumns.contains(column)) {
        _pinnedColumns.remove(column);
      } else {
        _pinnedColumns.add(column);
      }
    });
  }

  // Theme helper getters
  bool get _isDarkMode => Theme.of(context).brightness == Brightness.dark;

  Color get _backgroundColor => _isDarkMode ? const Color(0xFF000000) : const Color(0xFFF8FAFC);
  Color get _surfaceColor => _isDarkMode ? const Color(0xFF121212) : Colors.white;
  Color get _textColor => _isDarkMode ? const Color(0xFFF5F5F5) : const Color(0xFF0F172A);
  Color get _secondaryTextColor => _isDarkMode ? const Color(0xFFAAAAAA) : const Color(0xFF64748B);
  Color get _borderColor => _isDarkMode ? const Color(0xFF2A2A2A) : const Color(0xFFE2E8F0);
  Color get _hoverColor => _isDarkMode ? const Color(0xFF242424).withOpacity(0.5) : const Color(0xFFF1F5F9);
  Color get _headerBgColor => _isDarkMode ? const Color(0xFF101010) : const Color(0xFFF1F5F9);

  String get _userStatusKey {
    final userId = widget.loggedInEmployee?.id ?? 'default';
    return 'status_order_$userId';
  }

  List<Map<String, dynamic>> get _tableColumns => [
    {
      'key': 'status',
      'label': 'Status',
      'width': 140.0,
    },
    {
      'key': 'item',
      'label': 'Item',
      'width': 70.0,
    },
    {
      'key': 'product_code',
      'label': 'Product Code',
      'width': 150.0,
    },
    {
      'key': 'contract_number',
      'label': 'Contract Num',
      'width': 110.0,
    },
    {
      'key': 'description',
      'label': 'Description',
      'width': 200.0,
    },
    {
      'key': 'design_order',
      'label': 'Design Order',
      'width': 110.0,
    },
    {
      'key': 'quantity',
      'label': 'QTY',
      'width': 70.0,
    },
    {
      'key': 'unit',
      'label': 'Unit',
      'width': 70.0,
    },
    {
      'key': 'value',
      'label': 'Value',
      'width': 110.0,
    },
    {
      'key': 'sales_engineer',
      'label': 'Sales Engineer',
      'width': 150.0,
    },
    {
      'key': 'order_date',
      'label': 'O-Date',
      'width': 100.0,
    },
    {
      'key': 'end_date',
      'label': 'E-Date',
      'width': 100.0,
    },
    {
      'key': 'delivery_date',
      'label': 'Del. Date',
      'width': 100.0,
    },
    {
      'key': 'factory',
      'label': 'Factory',
      'width': 120.0,
    },
    {
      'key': 'design_team',
      'label': 'Design Team',
      'width': 130.0,
    },
    {
      'key': 'responsible_engineer',
      'label': 'Resp. Eng.',
      'width': 130.0,
    },
    {
      'key': 'reviewer',
      'label': 'Reviewer',
      'width': 120.0,
    },
    {
      'key': 'correspondence_engineer',
      'label': 'Alternative Eng.',
      'width': 120.0,
    },
  ]..addAll(widget.approvalTrackingMode
      ? [
    {'key': 'created_at_tracking', 'label': 'Created At', 'width': 115.0},
    {'key': 'drawing_approval_date', 'label': 'رسم الاعتماد', 'width': 125.0},
    {'key': 'sales_approval_date', 'label': 'اعتماد البيع', 'width': 125.0},
    {'key': 'modifications_count', 'label': 'التعديلات - العدد', 'width': 105.0},
    {'key': 'modifications_last_date', 'label': 'التعديلات - آخر تاريخ', 'width': 125.0},
    {'key': 'operation_date', 'label': 'تاريخ التشغيل', 'width': 125.0},
  ]
      : []);

  double _columnWidth(String key) {
    final column = _tableColumns.firstWhere(
          (c) => c['key'] == key,
    );

    return column['width'] as double;
  }

  static const List<String> _defaultStatuses = [
    'Drawing Submittal',
    'imported',
    'Approval',
    'modifications submitted',
    'Manufacturing Drawing',
    'Done',
    'Task Done',
    'Review',
    'Master Data',
    'Sales',
    'As Built',
    'Tasks',
    'planning',
    'partation  master data',
    'الادارة الهندسه',
    'design studio',
    'ادارة تصميم المنتجات',
    'automated',
    'Partition Editing',
  ];

  static const List<String> _allTeamStatuses = [
    'partition division',
    'product division',
    'تفصيل مصنع',
    'Chair & Sofa Division',
    'purch',
    'cladding division',
  ];

  void _loadStatusesFromStorage() {
    try {
      final saved = html.window.localStorage[_userStatusKey];
      if (saved != null && saved.isNotEmpty) {
        final decoded = jsonDecode(saved) as List<dynamic>;
        _allStatuses = decoded.map((e) => e.toString()).toList();

        // Check for new statuses that might not be in saved list
        for (var status in _defaultStatuses) {
          if (!_allStatuses.contains(status)) {
            _allStatuses.add(status);
          }
        }
      } else {
        _allStatuses = List.from(_defaultStatuses);
        _saveStatusesToStorage();
      }
    } catch (e) {
      _allStatuses = List.from(_defaultStatuses);
    }
  }

// Save statuses to localStorage
  void _saveStatusesToStorage() {
    try {
      html.window.localStorage[_userStatusKey] = jsonEncode(_allStatuses);
    } catch (e) {
      print('Error saving statuses: $e');
    }
  }

// Move status up
  void _moveStatusUp(int index) {
    if (index > 0) {
      setState(() {
        final temp = _allStatuses[index];
        _allStatuses[index] = _allStatuses[index - 1];
        _allStatuses[index - 1] = temp;
        _saveStatusesToStorage();
        _rebuildGroups();
      });
    }
  }

// Move status down
  void _moveStatusDown(int index) {
    if (index < _allStatuses.length - 1) {
      setState(() {
        final temp = _allStatuses[index];
        _allStatuses[index] = _allStatuses[index + 1];
        _allStatuses[index + 1] = temp;
        _saveStatusesToStorage();
        _rebuildGroups();
      });
    }
  }

// Reset to default
  void _resetStatusesToDefault() {
    setState(() {
      _allStatuses = List.from(_defaultStatuses);
      _saveStatusesToStorage();
      _rebuildGroups();
    });
  }

  void _showStatusArrangementDialog() {
    showDialog(
      context: context,
      builder: (ctx) {
        // Use a separate StatefulWidget for the dialog to avoid conflicts
        return _StatusArrangementDialog(
          statuses: List.from(_allStatuses),
          onReorder: (newList) {
            setState(() {
              _allStatuses = newList;
              _saveStatusesToStorage();
              _rebuildGroups();
            });
          },
          onReset: () {
            setState(() {
              _allStatuses = List.from(_defaultStatuses);
              _saveStatusesToStorage();
              _rebuildGroups();
            });
          },
        );
      },
    );
  }

  // Add this method to check if user is admin
  bool get _isAdmin {
    final role = widget.loggedInEmployee?.role?.toLowerCase() ?? '';
    return role == 'admin' || role == 'software head' || role == 'head';
  }

  bool _isHeaderResponsibleEngineerRow(SAPMainOrder order) {
    return order.responsibleEngineer?.trim().toLowerCase() == 'header';
  }

  // Responsible Engineer = "No One" behaves like a header row:
  // normal users cannot change it; admins/heads can change it.
  bool _isNoOneResponsibleEngineerLocked(SAPMainOrder order) {
    final responsible =
        order.responsibleEngineer?.trim().toLowerCase() ?? '';

    return responsible == 'no one' && !_isAdmin;
  }

  String _getSortLabel() {
    switch (_sortBy) {
      case 'value_asc':
        return 'Value ↑';
      case 'value_desc':
        return 'Value ↓';
      case 'date_asc':
        return 'Date ↑';
      case 'date_desc':
        return 'Date ↓';
      case 'item_asc':
        return 'Contract / Item ↑';
      default:
        return 'Sort';
    }
  }

  // Add audit service
  final AuditService _auditService = AuditService(Supabase.instance.client);

  // Helper to get current user info
  String get _currentUserName => widget.loggedInEmployee?.fullName ?? 'Unknown';

  String get _currentUserId => widget.loggedInEmployee?.id ?? '';

  // Get old value before update (from the current order object)
  String? _getCurrentFieldValue(SAPMainOrder order, String field) {
    switch (field) {
      case 'status':
        return order.status;
      case 'design_team':
        return order.designTeam;
      case 'responsible_engineer':
        return order.responsibleEngineer;
      case 'reviewer':
        return order.reviewer;
      case 'correspondence_engineer':
        return order.correspondenceEngineer;
      case 'sales_engineer':
        return order.salesEngineer;
      case 'factory':
        return order.factory;
      default:
        return null;
    }
  }

  // Check if user is from Data Entry department (can edit any row)
  bool get _isDataEntry {
    final department = widget.loggedInEmployee?.department?.toLowerCase() ?? '';
    return department == 'data entry';
  }

  // Update the _isOrderEditable method
  bool _canEditPdcContract(SAPMainOrder order) {
    return _isHedOrManager &&
        order.contractNumber.trim().toUpperCase().startsWith('PDC');
  }

  bool _isOrderEditable(SAPMainOrder order) {
    if (widget.readOnly) return false;

    // Heads and managers can edit PDC contract rows, even when their status
    // would normally lock the row.
    if (_canEditPdcContract(order)) return true;

    // Locked orders cannot be edited by anyone else.
    if (_isOrderLocked(order)) return false;

    // Data Entry users can edit any row
    if (_isDataEntry||_isAdmin) return true;

    // Regular users can only edit "Tasks" orders
    return order.status.toLowerCase() == 'tasks';
  }

  void _applyMyWorkFilter() {
    setState(() {
      if (_filterMyWork) {
        // Already filtered - clear it
        _filterMyWork = false;
        _filterResponsibleEngineer = null;
        _filterReviewer = null;
        _filterCorrespondenceEngineer = null;
      } else {
        // Apply my work filter
        _filterMyWork = true;
        final myName = widget.loggedInEmployee?.fullName ?? '';
        _filterResponsibleEngineer = myName;
        _filterReviewer = myName;
        _filterCorrespondenceEngineer = myName;
      }
      _rebuildGroups();
    });
  }

  String get _normalizedRole =>
      widget.loggedInEmployee?.role?.trim().toLowerCase() ?? '';

  bool get _isHeadRole => _normalizedRole == 'head';

  bool get _isManagerRole => _normalizedRole == 'manager';

  bool get _isEngineerRole => _normalizedRole == 'engineer';

  void _selectEmployeeWork(String? employeeName) {
    setState(() {
      _selectedWorkEmployee = employeeName;
      _filterMyWork = false;

      // Employee selection means show that employee's complete assigned work,
      // not the union of this selection with any previously active filters.
      _filterStatus = null;
      _filterFactory = null;
      _filterDesignTeam = null;
      _filterSalesEngineer = null;
      _filterResponsibleEngineer = null;
      _filterReviewer = null;
      _filterCorrespondenceEngineer = null;
      _searchQuery = '';
      _searchController.clear();
      _searchExpanded = false;
      _searchFocusNode.unfocus();
      _rebuildGroups();
    });
  }

  Widget _buildEmployeeWorkDropdown({bool isMobile = false}) {
    final names = _allEmployees
        .map((employee) => employee.fullName.trim())
        .where((name) => name.isNotEmpty)
        .toSet()
        .toList()
      ..sort((a, b) => a.toLowerCase().compareTo(b.toLowerCase()));

    // Match the Design Team filter's size and searchable picker behavior.
    // "All orders" clears the employee selection.
    return SizedBox(
      width: 175,
      child: _buildToolbarFilterDropdown(
        'All orders',
        _selectedWorkEmployee ?? 'All orders',
        ['All orders', ...names],
            (value) => _selectEmployeeWork(
          value == null || value == 'All orders' ? null : value,
        ),
        isMobile: isMobile,
      ),
    );
  }

  // Copy a specific field value to clipboard
  void _copyFieldToClipboard(String label, String value) {
    if (value.isEmpty || value == '-') {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('⚠️ No data to copy', style: GoogleFonts.cairo()),
          backgroundColor: Colors.orange,
          behavior: SnackBarBehavior.floating,
          duration: const Duration(milliseconds: 3000),
        ),
      );
      return;
    }

    Clipboard.setData(ClipboardData(text: value));

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          '📋 Copied: $label → "$value"',
          style: GoogleFonts.cairo(),
        ),
        backgroundColor: Colors.green,
        behavior: SnackBarBehavior.floating,
        duration: const Duration(milliseconds: 3000),
      ),
    );
  }

  // Copy order data to clipboard (full row)
  void _copyOrderData(SAPMainOrder order) {
    final StringBuffer buffer = StringBuffer();
    buffer.writeln('📋 Order Details:');
    buffer.writeln('━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    buffer.writeln('Customer: ${order.customerName}');
    buffer.writeln('Design Order: ${order.designOrder}');
    buffer.writeln('Contract Number: ${order.contractNumber}');
    buffer.writeln('Item: ${order.itemNumber}');
    buffer.writeln('Product Code: ${order.productCode}');
    buffer.writeln('Description: ${order.description}');
    buffer.writeln('QTY: ${order.quantity}');
    buffer.writeln('Unit: ${order.unitOfMeasure}');
    buffer.writeln('Value: \$${_formatNumber(order.value)}');
    buffer.writeln('Status: ${order.status}');
    buffer.writeln('Sales Engineer: ${order.salesEngineer}');
    buffer.writeln('Order Date: ${order.orderDate ?? '-'}');
    buffer.writeln('End Date: ${order.endDate ?? '-'}'); // ✅ ADD THIS
    buffer.writeln('Delivery Date: ${order.deliveryDate ?? '-'}');
    buffer.writeln('Factory: ${order.factory ?? '-'}');
    buffer.writeln('Design Team: ${order.designTeam ?? '-'}');
    buffer.writeln('Resp. Engineer: ${order.responsibleEngineer ?? '-'}');
    buffer.writeln('Reviewer: ${order.reviewer ?? '-'}');
    buffer.writeln('Alt. Engineer: ${order.correspondenceEngineer ?? '-'}');
    buffer.writeln('━━━━━━━━━━━━━━━━━━━━━━━━━━━━');

    Clipboard.setData(ClipboardData(text: buffer.toString()));

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          '📋 Full order data copied to clipboard',
          style: GoogleFonts.cairo(),
        ),
        backgroundColor: Colors.green,
        behavior: SnackBarBehavior.floating,
        duration: const Duration(milliseconds: 3000),
      ),
    );
  }

  // Copy selected orders summary
  void _copySelectedOrdersData() {
    if (_selectedRowsIds.isEmpty) {
      _showSnackBar('No orders selected');
      return;
    }

    final selectedOrders = _allOrders
        .where((o) => _selectedRowsIds.contains(o.id))
        .toList();
    final StringBuffer buffer = StringBuffer();
    buffer.writeln('📋 Selected Orders (${selectedOrders.length}):');
    buffer.writeln('━━━━━━━━━━━━━━━━━━━━━━━━━━━━');

    for (var order in selectedOrders) {
      buffer.writeln(
        '• ${order.designOrder} | ${order.customerName} | ${order.status} | \$${_formatNumber(order.value)}',
      );
    }
    buffer.writeln('━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    buffer.writeln('Total Orders: ${selectedOrders.length}');
    buffer.writeln(
      'Total Value: \$${_formatNumber(selectedOrders.fold(0.0, (sum, o) => sum + o.value))}',
    );

    Clipboard.setData(ClipboardData(text: buffer.toString()));

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          '📋 ${selectedOrders.length} orders copied to clipboard',
          style: GoogleFonts.cairo(),
        ),
        backgroundColor: Colors.green,
        behavior: SnackBarBehavior.floating,
        duration: const Duration(milliseconds: 3000),
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    _loadStatusesFromStorage();
    _initializePageData();
  }

  Future<void> _initializePageData() async {
    // Start loading the main orders immediately; factory labels can load in parallel.
    unawaited(_loadFactoryNames());
    await _loadAllDataOnce();

    // Both Orders routes use one combined table; do not load a separate
    // embedded Done Orders section below the main table.
  }

  @override
  void dispose() {
    _horizontalScrollController.dispose();
    _leftVerticalScrollController.dispose();
    _rightVerticalScrollController.dispose();
    _searchDebounce?.cancel();
    _searchController.dispose();
    _searchFocusNode.dispose();
    for (final timer in _inlineSaveTimers.values) {
      timer.cancel();
    }
    _inlineSaveTimers.clear();
    for (final controller in _editControllers.values) {
      controller.dispose();
    }
    _editControllers.clear();
    super.dispose();
  }

  bool get _isHedOrManager {
    final role = widget.loggedInEmployee?.role?.trim().toLowerCase() ?? '';

    return role == 'head' || role == 'manager';
  }

  void _showBulkEditDialog() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(
          'Bulk Edit',
          style: GoogleFonts.cairo(fontWeight: FontWeight.w600),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              '${_selectedRowsIds.length} rows selected',
              style: GoogleFonts.cairo(
                fontSize: 13,
                color: _secondaryTextColor,
              ),
            ),
            const SizedBox(height: 16),
            Wrap(
              spacing: 8,
              children: [
                _buildBulkEditOption('Status', 'status'),
                _buildBulkEditOption('Design Team', 'design_team'),
                _buildBulkEditOption('Factory', 'factory'),
                _buildBulkEditOption('Sales Engineer', 'sales_engineer'),
                _buildBulkEditOption('Resp. Engineer', 'responsible_engineer'),
                _buildBulkEditOption('Reviewer', 'reviewer'),
                _buildBulkEditOption(
                  'Alt. Engineer',
                  'correspondence_engineer',
                ),
                _buildBulkEditOption('Value', 'value'),
                // Add date picker options for bulk edit
                _buildBulkDateOption('O-Date', 'order_date'),
                _buildBulkDateOption('Delivery Date', 'delivery_date'),
              ],
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: Text('Cancel', style: GoogleFonts.cairo()),
          ),
        ],
      ),
    );
  }

  Widget _buildBulkDateOption(String label, String field) {
    return OutlinedButton(
      onPressed: () {
        Navigator.pop(context);
        _pickDateForBulkEdit(field);
      },
      style: OutlinedButton.styleFrom(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.calendar_today, size: 12),
          const SizedBox(width: 4),
          Text(label, style: GoogleFonts.cairo(fontSize: 11)),
        ],
      ),
    );
  }

  Future<void> _pickDateForBulkEdit(String field) async {
    final pickedDate = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2020),
      lastDate: DateTime(2030),
    );

    if (pickedDate != null) {
      final formattedDate = DateFormat('yyyy-MM-dd').format(pickedDate);
      await _applyBulkEditToSelected(field, formattedDate);
    }
  }

  Widget _buildBulkEditOption(String label, String field) {
    return OutlinedButton(
      onPressed: () {
        Navigator.pop(context);
        _bulkEditField(field, '');
      },
      style: OutlinedButton.styleFrom(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
      ),
      child: Text(label, style: GoogleFonts.cairo(fontSize: 11)),
    );
  }

  // Check if user can import/delete (admin role or specific username)
  bool get _canImportDelete {
    final role = widget.loggedInEmployee?.role?.toLowerCase() ?? '';
    return role == 'software head' ||
        role == 'head' ||
        _isDataEntry;
  }

  Future<void> _showAddTaskDialog() async {
    final nameController = TextEditingController();
    final contractController = TextEditingController();
    final designOrderController = TextEditingController();
    final itemController = TextEditingController();
    final productCodeController = TextEditingController();
    final descriptionController = TextEditingController();
    final qtyController = TextEditingController();
    final unitController = TextEditingController(text: 'EA');
    final valueController = TextEditingController();
    final factoryController = TextEditingController();

    final newOrder = await showDialog<SAPMainOrder>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(
          'Add New Task',
          style: GoogleFonts.cairo(fontWeight: FontWeight.w600, fontSize: 18),
        ),
        content: SizedBox(
          width: 500,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: nameController,
                  style: GoogleFonts.cairo(fontSize: 13),
                  decoration: _buildInputDecoration('Customer Name *'),
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: contractController,
                        style: GoogleFonts.cairo(fontSize: 13),
                        decoration: _buildInputDecoration('Contract Number'),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: TextField(
                        controller: designOrderController,
                        style: GoogleFonts.cairo(fontSize: 13),
                        decoration: _buildInputDecoration('Design Order'),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: itemController,
                        style: GoogleFonts.cairo(fontSize: 13),
                        decoration: _buildInputDecoration('Item'),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: TextField(
                        controller: productCodeController,
                        style: GoogleFonts.cairo(fontSize: 13),
                        decoration: _buildInputDecoration('Product Code'),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: descriptionController,
                  style: GoogleFonts.cairo(fontSize: 13),
                  decoration: _buildInputDecoration('Description'),
                  maxLines: 2,
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: qtyController,
                        style: GoogleFonts.cairo(fontSize: 13),
                        decoration: _buildInputDecoration('QTY'),
                        keyboardType: TextInputType.number,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: TextField(
                        controller: unitController,
                        style: GoogleFonts.cairo(fontSize: 13),
                        decoration: _buildInputDecoration('Unit'),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: TextField(
                        controller: valueController,
                        style: GoogleFonts.cairo(fontSize: 13),
                        decoration: _buildInputDecoration('Value'),
                        keyboardType: TextInputType.number,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: factoryController,
                  style: GoogleFonts.cairo(fontSize: 13),
                  decoration: _buildInputDecoration('Factory'),
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: Text('Cancel', style: GoogleFonts.cairo()),
          ),
          ElevatedButton(
            onPressed: () {
              // Only Customer Name is required
              if (nameController.text.trim().isEmpty) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(
                      'Customer Name is required',
                      style: GoogleFonts.cairo(),
                    ),
                    backgroundColor: Colors.red,
                    duration: const Duration(milliseconds: 1000),
                  ),
                );
                return;
              }

              final order = SAPMainOrder(
                id: '',
                status: 'Tasks',
                customerName: nameController.text.trim(),
                // Empty values default to "0"
                itemNumber: itemController.text.trim().isEmpty
                    ? '0'
                    : itemController.text.trim(),
                productCode: productCodeController.text.trim().isEmpty
                    ? '0'
                    : productCodeController.text.trim(),
                contractNumber: contractController.text.trim().isEmpty
                    ? '0'
                    : contractController.text.trim(),
                description: descriptionController.text.trim(),
                designOrder: designOrderController.text.trim().isEmpty
                    ? '0'
                    : designOrderController.text.trim(),
                quantity: double.tryParse(qtyController.text.replaceAll(',', '')) ?? 0,
                unitOfMeasure: unitController.text.trim().isEmpty
                    ? 'EA'
                    : unitController.text.trim(),
                value: double.tryParse(valueController.text.replaceAll(',', '').replaceAll('\$', '')) ?? 0,
                salesEngineer: _currentUserName,
                orderDate: DateFormat('yyyy-MM-dd').format(DateTime.now()),
                // No delivery date
                deliveryDate: null,
                factory: factoryController.text.trim().isEmpty
                    ? null
                    : factoryController.text.trim(),
                designTeam: widget.loggedInEmployee?.department,
                responsibleEngineer: null,
                reviewer: null,
                correspondenceEngineer: null,
                createdAt: DateTime.now(),
              );

              Navigator.pop(ctx, order);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Theme.of(context).colorScheme.primary,
            ),
            child: Text(
              'Add Task',
              style: GoogleFonts.cairo(color: Theme.of(context).colorScheme.onPrimary),
            ),
          ),
        ],
      ),
    );

    if (newOrder != null) {
      setState(() => _isLoading = true);
      try {
        final supabase = Supabase.instance.client;
        final response = await supabase
            .from('sap_main_orders')
            .insert({
          'status': 'Tasks',
          'customer_name': newOrder.customerName,
          'item_number': newOrder.itemNumber,
          'product_code': newOrder.productCode,
          'contract_number': newOrder.contractNumber,
          'description': newOrder.description,
          'design_order': newOrder.designOrder,
          'quantity': newOrder.quantity,
          'unit_of_measure': newOrder.unitOfMeasure,
          'value': newOrder.value,
          'sales_engineer': newOrder.salesEngineer,
          'order_date': newOrder.orderDate,
          'delivery_date': null, // No delivery date
          'factory': newOrder.factory,
          'design_team': newOrder.designTeam,
          'responsible_engineer': newOrder.responsibleEngineer,
          'reviewer': newOrder.reviewer,
          'correspondence_engineer': newOrder.correspondenceEngineer,
        })
            .select()
            .single();

        final createdOrder = SAPMainOrder.fromJson(response);

        setState(() {
          _allOrders.add(createdOrder);
          _orderIndexMap[createdOrder] = _allOrders.length - 1;
          _isLoading = false;
        });

        _rebuildGroups();
        _showSnackBar('✅ Task created successfully!');
      } catch (e) {
        setState(() => _isLoading = false);
        _showSnackBar('Error creating task: $e');
      }
    }
  }

  // Create a contract: shared fields are entered once; item numbers auto-run 1000, 2000, 3000... per contract.
  Future<void> _showAddContractDialog() async {
    final supabase = Supabase.instance.client;
    final countController = TextEditingController(text: '1');
    final customerController = TextEditingController();
    final contractController = TextEditingController();
    final orderDateController = TextEditingController(
      text: DateFormat('yyyy-MM-dd').format(DateTime.now()),
    );
    final endDateController = TextEditingController();
    final deliveryDateController = TextEditingController();
    final salesEngineerController = TextEditingController();
    final List<String?> itemFactoryCodes = [];
    String? selectedResponsibleEngineer;
    String? selectedReviewer;
    List<Map<String, TextEditingController>> itemControllers = [];
    String? selectedExistingContract;
    int nextItemNumber = 1000;

    Map<String, TextEditingController> makeItemControllers(int itemNumber) => {
      'item': TextEditingController(text: itemNumber.toString()),
      'product_code': TextEditingController(),
      'description': TextEditingController(),
      'quantity': TextEditingController(text: '0'),
      'unit': TextEditingController(text: 'EA'),
      'value': TextEditingController(text: '0'),
    };

    void syncItemCount() {
      final count = int.tryParse(countController.text.trim()) ?? 0;
      if (count < 1 || count > 100) return;
      while (itemControllers.length < count) {
        // Continue item numbering from the selected contract, or start at 1000.
        itemControllers.add(makeItemControllers(nextItemNumber));
        nextItemNumber += 1000;
        itemFactoryCodes.add(null);
      }
      while (itemControllers.length > count) {
        itemFactoryCodes.removeLast();
        final removed = itemControllers.removeLast();
        for (final c in removed.values) {
          c.dispose();
        }
      }
    }

    Future<void> pickDate(
        TextEditingController controller,
        BuildContext dialogContext,
        ) async {
      final initial = DateTime.tryParse(controller.text) ?? DateTime.now();
      final date = await showDatePicker(
        context: dialogContext,
        initialDate: initial,
        firstDate: DateTime(2000),
        lastDate: DateTime(2100),
      );
      if (date != null) {
        controller.text = DateFormat('yyyy-MM-dd').format(date);
      }
    }

    Future<void> chooseFactory(
        int itemIndex,
        StateSetter setDialogState,
        BuildContext dialogContext,
        ) async {
      if (_factoryDescriptions.isEmpty) await _loadFactoryNames();
      final searchController = TextEditingController();
      final picked = await showDialog<String>(
        context: dialogContext,
        builder: (factoryContext) => StatefulBuilder(
          builder: (factoryContext, setFactoryState) {
            final q = searchController.text.trim().toLowerCase();
            final matches = _factoryDescriptions.entries.where((e) =>
            e.key.toLowerCase().contains(q) ||
                e.value.toLowerCase().contains(q)
            ).take(100).toList();
            return AlertDialog(
              title: Text('Select Factory',
                  style: GoogleFonts.cairo(fontWeight: FontWeight.w700)),
              content: SizedBox(
                width: 430,
                height: 430,
                child: Column(children: [
                  TextField(
                    controller: searchController,
                    autofocus: true,
                    decoration: InputDecoration(
                      hintText: 'Search by factory name or code',
                      prefixIcon: const Icon(Icons.search),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    onChanged: (_) => setFactoryState(() {}),
                  ),
                  const SizedBox(height: 12),
                  Expanded(
                    child: matches.isEmpty
                        ? const Center(child: Text('No factories found'))
                        : ListView.separated(
                      itemCount: matches.length,
                      separatorBuilder: (_, __) => const Divider(height: 1),
                      itemBuilder: (_, i) {
                        final entry = matches[i];
                        final code = _factoryCodes[entry.key] ?? entry.key;
                        return ListTile(
                          leading: const Icon(Icons.factory_outlined),
                          title: Text(entry.value.isEmpty ? entry.key : entry.value),
                          subtitle: Text('Code: $code'),
                          onTap: () => Navigator.pop(factoryContext, code),
                        );
                      },
                    ),
                  ),
                ]),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(factoryContext),
                  child: const Text('Cancel'),
                ),
              ],
            );
          },
        ),
      );
      searchController.dispose();
      if (picked != null) {
        setDialogState(() => itemFactoryCodes[itemIndex] = picked);
      }
    }

    Future<void> chooseExistingContract(
        StateSetter setDialogState, BuildContext dialogContext) async {
      final contracts = _allOrders
          .where((o) => o.contractNumber.trim().isNotEmpty &&
          o.contractNumber.trim() != '0')
          .map((o) => o.contractNumber.trim())
          .toSet()
          .toList()
        ..sort((a, b) => a.toLowerCase().compareTo(b.toLowerCase()));
      final searchController = TextEditingController();
      final picked = await showDialog<String>(
        context: dialogContext,
        builder: (pickerContext) => StatefulBuilder(
          builder: (pickerContext, setPickerState) {
            final q = searchController.text.trim().toLowerCase();
            final matches = contracts.where((c) => c.toLowerCase().contains(q)).toList();
            return AlertDialog(
              title: const Text('Select an Existing Contract'),
              content: SizedBox(
                width: 450,
                height: 430,
                child: Column(children: [
                  TextField(
                    controller: searchController,
                    autofocus: true,
                    decoration: const InputDecoration(
                      hintText: 'Search contract number',
                      prefixIcon: Icon(Icons.search),
                      border: OutlineInputBorder(),
                    ),
                    onChanged: (_) => setPickerState(() {}),
                  ),
                  const SizedBox(height: 8),
                  Expanded(
                    child: ListView.builder(
                      itemCount: matches.length,
                      itemBuilder: (_, i) {
                        final number = matches[i];
                        final order = _allOrders.firstWhere(
                                (o) => o.contractNumber.trim() == number);
                        return ListTile(
                          title: Text(number),
                          subtitle: Text(order.customerName),
                          onTap: () => Navigator.pop(pickerContext, number),
                        );
                      },
                    ),
                  ),
                ]),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(pickerContext),
                  child: const Text('Cancel'),
                ),
              ],
            );
          },
        ),
      );
      searchController.dispose();
      if (picked == null) return;

      final existing = _allOrders
          .where((o) => o.contractNumber.trim() == picked)
          .toList();
      if (existing.isEmpty) return;
      existing.sort((a, b) =>
          (int.tryParse(a.itemNumber) ?? 0).compareTo(int.tryParse(b.itemNumber) ?? 0));
      final first = existing.first;
      final maxItem = existing
          .map((o) => int.tryParse(o.itemNumber) ?? 0)
          .fold<int>(0, (a, b) => a > b ? a : b);

      setDialogState(() {
        selectedExistingContract = picked;
        if (picked.toUpperCase().startsWith('PDC')) {
          contractController.text = picked.substring(3);
        } else {
          contractController.text = picked;
        }
        customerController.text = first.customerName;
        if (first.orderDate != null && first.orderDate!.isNotEmpty) {
          orderDateController.text = first.orderDate!;
        }
        endDateController.text = first.endDate ?? '';
        deliveryDateController.text = first.deliveryDate ?? '';
        salesEngineerController.text = first.salesEngineer ?? '';
        selectedResponsibleEngineer = first.responsibleEngineer;
        selectedReviewer = first.reviewer;
        nextItemNumber = maxItem >= 1000 ? maxItem + 1000 : 1000;
        // Re-number any currently prepared blank items after the existing ones.
        for (var i = 0; i < itemControllers.length; i++) {
          itemControllers[i]['item']!.text = (nextItemNumber + i * 1000).toString();
        }
        nextItemNumber += itemControllers.length * 1000;
      });
    }

    // Find the next PDC number across active and archived orders.
    // Fetch in pages so Supabase's row limit cannot hide the latest number.
    try {
      var highest = 1000;
      for (final table in ['sap_main_orders', 'sap_done_orders']) {
        var offset = 0;
        const pageSize = 1000;
        while (true) {
          final page = await supabase
              .from(table)
              .select('contract_number')
              .range(offset, offset + pageSize - 1);

          for (final row in page as List) {
            final value = (row['contract_number'] ?? '').toString().trim();
            final match = RegExp(r'^PDC(\d+)$', caseSensitive: false)
                .firstMatch(value);
            final number = int.tryParse(match?.group(1) ?? '');
            if (number != null && number > highest) highest = number;
          }

          if (page.length < pageSize) break;
          offset += pageSize;
        }
      }
      contractController.text = '${highest + 1}';
    } catch (e) {
      // Never fall back to PDC1001: that could create a duplicate contract.
      _showSnackBar('Could not verify the next contract number. Please try again. ($e)');
      countController.dispose();
      customerController.dispose();
      contractController.dispose();
      orderDateController.dispose();
      endDateController.dispose();
      deliveryDateController.dispose();
      salesEngineerController.dispose();
      return;
    }

    final employeeNames = _allEmployees
        .map((e) => e.fullName.trim())
        .where((name) => name.isNotEmpty)
        .toSet()
        .toList()
      ..sort((a, b) => a.toLowerCase().compareTo(b.toLowerCase()));

    syncItemCount();
    final confirmed = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => StatefulBuilder(
        builder: (dialogContext, setDialogState) {
          final theme = Theme.of(dialogContext);
          final primary = theme.colorScheme.primary;
          final inputDecoration = (String label, {IconData? icon}) =>
              InputDecoration(
                labelText: label,
                prefixIcon: icon == null ? null : Icon(icon, size: 19),
                labelStyle: GoogleFonts.cairo(fontSize: 12),
                filled: true,
                fillColor: theme.colorScheme.surface,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: theme.dividerColor),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: theme.dividerColor),
                ),
                contentPadding: const EdgeInsets.symmetric(
                    horizontal: 14, vertical: 13),
              );

          Widget textField(
              TextEditingController c,
              String label, {
                bool numeric = false,
                int lines = 1,
                IconData? icon,
                bool readOnly = false,
              }) => TextField(
            controller: c,
            readOnly: readOnly,
            style: GoogleFonts.cairo(fontSize: 13),
            keyboardType: numeric
                ? const TextInputType.numberWithOptions(decimal: true)
                : TextInputType.text,
            maxLines: lines,
            decoration: inputDecoration(label, icon: icon),
          );

          Widget dateField(
              TextEditingController c,
              String label, {
                bool required = false,
              }) => TextField(
            controller: c,
            readOnly: true,
            style: GoogleFonts.cairo(fontSize: 13),
            decoration: inputDecoration(
              required ? '$label *' : '$label (optional)',
              icon: Icons.calendar_month_outlined,
            ).copyWith(
              suffixIcon: IconButton(
                tooltip: 'Clear date',
                icon: const Icon(Icons.close, size: 18),
                onPressed: required ? null : () => setDialogState(c.clear),
              ),
            ),
            onTap: () => pickDate(c, dialogContext),
          );

          Widget sectionTitle(IconData icon, String title, String subtitle) =>
              Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Row(children: [
                  Container(
                    padding: const EdgeInsets.all(9),
                    decoration: BoxDecoration(
                      color: primary.withOpacity(.10),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Icon(icon, color: primary, size: 20),
                  ),
                  const SizedBox(width: 10),
                  Expanded(child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(title, style: GoogleFonts.cairo(
                          fontSize: 14, fontWeight: FontWeight.w700)),
                      Text(subtitle, style: GoogleFonts.cairo(
                          fontSize: 11, color: theme.hintColor)),
                    ],
                  )),
                ]),
              );

          Widget employeeDropdown(
              String label,
              String? value,
              ValueChanged<String?> onChanged,
              ) => InkWell(
            borderRadius: BorderRadius.circular(12),
            onTap: () async {
              final searchController = TextEditingController();
              final picked = await showDialog<String>(
                context: dialogContext,
                builder: (pickerContext) => StatefulBuilder(
                  builder: (pickerContext, setPickerState) {
                    final query = searchController.text.trim().toLowerCase();
                    final matches = employeeNames.where((name) =>
                        name.toLowerCase().contains(query)).toList();
                    return AlertDialog(
                      title: Text('Select $label'),
                      content: SizedBox(
                        width: 420,
                        height: 420,
                        child: Column(children: [
                          TextField(
                            controller: searchController,
                            autofocus: true,
                            decoration: const InputDecoration(
                              hintText: 'Search...',
                              prefixIcon: Icon(Icons.search),
                              border: OutlineInputBorder(),
                            ),
                            onChanged: (_) => setPickerState(() {}),
                          ),
                          const SizedBox(height: 8),
                          ListTile(
                            title: const Text('Not assigned'),
                            onTap: () => Navigator.pop(pickerContext, ''),
                          ),
                          const Divider(height: 1),
                          Expanded(child: matches.isEmpty
                              ? const Center(child: Text('No results found'))
                              : ListView.builder(
                            itemCount: matches.length,
                            itemBuilder: (_, i) => ListTile(
                              title: Text(matches[i]),
                              selected: matches[i] == value,
                              onTap: () => Navigator.pop(pickerContext, matches[i]),
                            ),
                          )),
                        ]),
                      ),
                    );
                  },
                ),
              );
              searchController.dispose();
              if (picked != null) onChanged(picked.isEmpty ? null : picked);
            },
            child: InputDecorator(
              decoration: inputDecoration(label, icon: Icons.person_search),
              child: Row(children: [
                Expanded(child: Text(value ?? 'Not assigned',
                    overflow: TextOverflow.ellipsis,
                    style: GoogleFonts.cairo(fontSize: 13))),
                const Icon(Icons.arrow_drop_down),
              ]),
            ),
          );

          return Dialog(
            insetPadding: const EdgeInsets.symmetric(
                horizontal: 24, vertical: 20),
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20)),
            child: SizedBox(
              width: 850,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    padding: const EdgeInsets.fromLTRB(24, 20, 18, 18),
                    decoration: BoxDecoration(
                      color: primary.withOpacity(.08),
                      borderRadius: const BorderRadius.vertical(
                          top: Radius.circular(20)),
                    ),
                    child: Row(children: [
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: primary.withOpacity(.14),
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: Icon(Icons.description_outlined,
                            color: primary, size: 25),
                      ),
                      const SizedBox(width: 12),
                      Expanded(child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(selectedExistingContract == null ? 'Create New Contract' : 'Add Items to Contract',
                              style: GoogleFonts.cairo(
                                  fontSize: 18, fontWeight: FontWeight.w800)),
                          Text(selectedExistingContract == null ? 'Enter shared details, then add contract items' : 'Existing contract selected — new items will be added to it',
                              style: GoogleFonts.cairo(
                                  fontSize: 11, color: theme.hintColor)),
                        ],
                      )),
                      IconButton(
                        tooltip: 'Close',
                        onPressed: () => Navigator.pop(dialogContext, false),
                        icon: const Icon(Icons.close),
                      ),
                    ]),
                  ),
                  Flexible(
                    child: SingleChildScrollView(
                      padding: const EdgeInsets.all(22),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          sectionTitle(Icons.assignment_outlined,
                              'Contract details',
                              'These details will be applied to every item'),
                          Row(children: [
                            Expanded(
                              flex: 2,
                              child: textField(customerController,
                                  'Customer Name *',
                                  icon: Icons.business_outlined),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: TextField(
                                controller: contractController,
                                readOnly: true,
                                style: GoogleFonts.cairo(fontSize: 13),
                                decoration: inputDecoration('Contract Number')
                                    .copyWith(prefixText: selectedExistingContract == null ? 'PDC' : null),
                              ),
                            ),
                            const SizedBox(width: 8),
                            OutlinedButton.icon(
                              onPressed: () => chooseExistingContract(setDialogState, dialogContext),
                              icon: const Icon(Icons.history, size: 18),
                              label: const Text('Old'),
                            ),
                          ]),
                          const SizedBox(height: 12),
                          Row(children: [
                            Expanded(child: dateField(orderDateController,
                                'Order Date', required: true)),
                            const SizedBox(width: 12),
                            Expanded(child: dateField(endDateController,
                                'End Date')),
                            const SizedBox(width: 12),
                            Expanded(child: dateField(deliveryDateController,
                                'Delivery Date')),
                          ]),
                          const SizedBox(height: 12),
                          textField(salesEngineerController,
                              'Sales Engineer (optional)',
                              icon: Icons.person_outline),
                          const SizedBox(height: 12),
                          Row(children: [
                            Expanded(child: employeeDropdown(
                              'Responsible Engineer',
                              selectedResponsibleEngineer,
                                  (v) => setDialogState(
                                      () => selectedResponsibleEngineer = v),
                            )),
                            const SizedBox(width: 12),
                            Expanded(child: employeeDropdown(
                              'Reviewer',
                              selectedReviewer,
                                  (v) => setDialogState(
                                      () => selectedReviewer = v),
                            )),
                          ]),
                          const SizedBox(height: 24),
                          Row(children: [
                            Expanded(child: sectionTitle(
                              Icons.inventory_2_outlined,
                              'Contract items',
                              '${itemControllers.length} item(s) in this contract',
                            )),
                            SizedBox(
                              width: 105,
                              child: TextField(
                                controller: countController,
                                textAlign: TextAlign.center,
                                keyboardType: TextInputType.number,
                                decoration: inputDecoration('Item count'),
                                onSubmitted: (_) {
                                  final count = int.tryParse(countController.text.trim()) ?? 0;
                                  if (count < 1 || count > 100) {
                                    _showSnackBar('Enter a number between 1 and 100');
                                    return;
                                  }
                                  setDialogState(syncItemCount);
                                },
                              ),
                            ),
                            const SizedBox(width: 8),
                            IconButton.filledTonal(
                              tooltip: 'Update item count',
                              onPressed: () {
                                final count = int.tryParse(
                                    countController.text.trim()) ?? 0;
                                if (count < 1 || count > 100) {
                                  _showSnackBar(
                                      'Enter a number between 1 and 100');
                                  return;
                                }
                                setDialogState(syncItemCount);
                              },
                              icon: const Icon(Icons.refresh),
                            ),
                          ]),
                          ...List.generate(itemControllers.length, (index) {
                            final item = itemControllers[index];
                            return Container(
                              margin: const EdgeInsets.only(bottom: 12),
                              padding: const EdgeInsets.all(15),
                              decoration: BoxDecoration(
                                border: Border.all(
                                    color: theme.dividerColor),
                                borderRadius: BorderRadius.circular(15),
                                color: theme.colorScheme.surface,
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(children: [
                                    CircleAvatar(
                                      radius: 15,
                                      backgroundColor: primary.withOpacity(.12),
                                      child: Text('${index + 1}',
                                          style: TextStyle(
                                              color: primary,
                                              fontWeight: FontWeight.w700)),
                                    ),
                                    const SizedBox(width: 9),
                                    Text('Item ${index + 1}',
                                        style: GoogleFonts.cairo(
                                            fontWeight: FontWeight.w700)),
                                  ]),
                                  const SizedBox(height: 12),
                                  Row(children: [
                                    Expanded(child: textField(
                                        item['item']!, 'Item',
                                        readOnly: true)),
                                    const SizedBox(width: 10),
                                    Expanded(child: textField(
                                        item['product_code']!, 'Product Code')),
                                  ]),
                                  const SizedBox(height: 10),
                                  textField(item['description']!,
                                      'Description', lines: 2),
                                  const SizedBox(height: 10),
                                  SizedBox(
                                    width: double.infinity,
                                    child: OutlinedButton.icon(
                                      style: OutlinedButton.styleFrom(
                                        padding: const EdgeInsets.symmetric(vertical: 14),
                                        shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(12)),
                                      ),
                                      onPressed: () => chooseFactory(
                                          index, setDialogState, dialogContext),
                                      icon: const Icon(Icons.factory_outlined),
                                      label: Text(itemFactoryCodes[index] == null
                                          ? 'Select factory for this item'
                                          : '${_formatFactoryLabel(itemFactoryCodes[index]!)}',
                                          maxLines: 1, overflow: TextOverflow.ellipsis),
                                    ),
                                  ),
                                  const SizedBox(height: 10),
                                  Row(children: [
                                    Expanded(child: textField(
                                        item['quantity']!, 'Quantity',
                                        numeric: true)),
                                    const SizedBox(width: 10),
                                    Expanded(child: textField(
                                        item['unit']!, 'Unit')),
                                    const SizedBox(width: 10),
                                    Expanded(child: textField(
                                        item['value']!, 'Value',
                                        numeric: true)),
                                  ]),
                                ],
                              ),
                            );
                          }),
                        ],
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(22, 12, 22, 18),
                    child: Row(children: [
                      TextButton(
                        onPressed: () => Navigator.pop(dialogContext, false),
                        child: Text('Cancel',
                            style: GoogleFonts.cairo()),
                      ),
                      const Spacer(),
                      FilledButton.icon(
                        onPressed: () {
                          if (customerController.text.trim().isEmpty) {
                            _showSnackBar('Customer Name is required');
                            return;
                          }
                          if (contractController.text.trim().isEmpty) {
                            _showSnackBar('Contract Number is required');
                            return;
                          }
                          if (DateTime.tryParse(orderDateController.text) == null) {
                            _showSnackBar('Please select the Order Date');
                            return;
                          }
                          if (itemControllers.isEmpty) {
                            _showSnackBar('Add at least one contract item');
                            return;
                          }
                          Navigator.pop(dialogContext, true);
                        },
                        icon: const Icon(Icons.check_circle_outline),
                        label: Text('Create Contract',
                            style: GoogleFonts.cairo(
                                fontWeight: FontWeight.w700)),
                      ),
                    ]),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );

    if (confirmed == true) {
      setState(() => _isLoading = true);
      try {
        final contractNumber = selectedExistingContract ??
            (contractController.text.trim().toUpperCase().startsWith('PDC')
                ? contractController.text.trim()
                : 'PDC${contractController.text.trim()}');
        final rows = itemControllers.map((item) => <String, dynamic>{
          'status': 'Drawing Submittal',
          'customer_name': customerController.text.trim(),
          'item_number': item['item']!.text.trim().isEmpty
              ? '0' : item['item']!.text.trim(),
          'product_code': item['product_code']!.text.trim().isEmpty
              ? '0' : item['product_code']!.text.trim(),
          'contract_number': contractNumber,
          'description': item['description']!.text.trim(),
          'design_order': null,
          'quantity': double.tryParse(
              item['quantity']!.text.replaceAll(',', '')) ?? 0,
          'unit_of_measure': item['unit']!.text.trim().isEmpty
              ? 'EA' : item['unit']!.text.trim(),
          'value': double.tryParse(item['value']!.text
              .replaceAll(',', '').replaceAll('\$', '')) ?? 0,
          'sales_engineer': salesEngineerController.text.trim().isEmpty
              ? null : salesEngineerController.text.trim(),
          'order_date': orderDateController.text.trim(),
          'end_date': endDateController.text.trim().isEmpty
              ? null : endDateController.text.trim(),
          'delivery_date': deliveryDateController.text.trim().isEmpty
              ? null : deliveryDateController.text.trim(),
          'factory': itemFactoryCodes.length > itemControllers.indexOf(item)
              ? itemFactoryCodes[itemControllers.indexOf(item)] : null,
          'design_team': widget.loggedInEmployee?.department,
          'responsible_engineer': selectedResponsibleEngineer,
          'reviewer': selectedReviewer,
          'correspondence_engineer': null,
        }).toList();

        final response = await supabase
            .from('sap_main_orders')
            .insert(rows)
            .select();
        final createdOrders = (response as List)
            .map((row) => SAPMainOrder.fromJson(
            Map<String, dynamic>.from(row)))
            .toList();
        if (mounted) {
          setState(() {
            _allOrders.addAll(createdOrders);
            for (final order in createdOrders) {
              _orderIndexMap[order] = _allOrders.indexOf(order);
            }
            _isLoading = false;
          });
          _rebuildGroups();
          _showSnackBar(
              'Contract $contractNumber updated successfully (${createdOrders.length} items added)');
        }
      } catch (e) {
        if (mounted) {
          setState(() => _isLoading = false);
          _showSnackBar('Error creating contract: $e');
        }
      }
    }

    countController.dispose();
    customerController.dispose();
    contractController.dispose();
    orderDateController.dispose();
    endDateController.dispose();
    deliveryDateController.dispose();
    salesEngineerController.dispose();
    for (final item in itemControllers) {
      for (final controller in item.values) {
        controller.dispose();
      }
    }
  }

  // Helper for input decoration
  InputDecoration _buildInputDecoration(String label) {
    return InputDecoration(
      labelText: label,
      labelStyle: GoogleFonts.cairo(fontSize: 12),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
    );
  }

  Future<void> _bulkEditField(String field, String currentValue) async {
    // Check if any selected order is locked
    final lockedOrders = _allOrders
        .where((o) => _selectedRowsIds.contains(o.id) && _isOrderLocked(o))
        .toList();

    if (lockedOrders.isNotEmpty) {
      _showSnackBar('⚠️ Cannot bulk edit: ${lockedOrders.length} locked order(s) selected (Done, Task Done, or Planning)');
      return;
    }

    final controller = TextEditingController();

    final newValue = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(
          'Bulk Edit ${_formatFieldName(field)}',
          style: GoogleFonts.cairo(fontWeight: FontWeight.w600),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Apply to ${_selectedRowsIds.length} selected rows',
              style: GoogleFonts.cairo(
                fontSize: 13,
                color: _secondaryTextColor,
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: controller,
              style: GoogleFonts.cairo(fontSize: 14),
              decoration: InputDecoration(
                labelText: _formatFieldName(field),
                hintText: 'Enter new value for all selected',
                border: const OutlineInputBorder(),
              ),
              keyboardType: field == 'quantity' || field == 'value'
                  ? TextInputType.number
                  : TextInputType.text,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: Text('Cancel', style: GoogleFonts.cairo()),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, controller.text),
            style: ElevatedButton.styleFrom(
              backgroundColor: Theme.of(context).colorScheme.primary,
            ),
            child: Text(
              'Apply to ${_selectedRowsIds.length} rows',
              style: GoogleFonts.cairo(color: Theme.of(context).colorScheme.onPrimary),
            ),
          ),
        ],
      ),
    );

    if (newValue != null && newValue.isNotEmpty) {
      setState(() => _isLoading = true);
      final supabase = Supabase.instance.client;
      int updated = 0;
      int skipped = 0;

      dynamic parsedValue = newValue;
      if (field == 'quantity') {
        parsedValue = double.tryParse(newValue.replaceAll(',', '')) ?? 0;
      } else if (field == 'value') {
        parsedValue =
            double.tryParse(
              newValue.replaceAll(',', '').replaceAll('\$', ''),
            ) ??
                0;
      }

      for (var orderId in _selectedRowsIds) {
        final order = _allOrders.where((o) => o.id == orderId).firstOrNull;
        if (order != null) {
          // Skip locked orders
          if (_isOrderLocked(order)) {
            skipped++;
            continue;
          }

          // Header rows cannot have an Alternative Engineer.
          if (field == 'correspondence_engineer' &&
              _isHeaderResponsibleEngineerRow(order)) {
            skipped++;
            continue;
          }

          // Header rows may only be changed by admins.
          if (field == 'responsible_engineer' &&
              _isHeaderResponsibleEngineerRow(order) &&
              !_isAdmin) {
            skipped++;
            continue;
          }

          // "No One" is locked for non-admin users, just like a header row.
          if (field == 'responsible_engineer' &&
              _isNoOneResponsibleEngineerLocked(order)) {
            skipped++;
            continue;
          }

          try {
            await supabase
                .from('sap_main_orders')
                .update({field: parsedValue})
                .eq('id', order.id);

            await _auditService.logChange(
              orderId: order.id,
              designOrder: order.designOrder,
              fieldName: field,
              oldValue: _getCurrentFieldValue(order, field),
              newValue: newValue,
              changedBy: _currentUserName,
              changedById: _currentUserId,
              actionType: 'bulk_update',
            );
            updated++;
          } catch (e) {
            print('Failed to update ${order.id}: $e');
          }
        }
      }

      setState(() => _isLoading = false);
      if (skipped > 0) {
        _showSnackBar('✅ $updated rows updated, ⚠️ $skipped locked rows skipped');
      } else {
        _showSnackBar('✅ $updated rows updated!');
      }
      _updateMultipleOrdersLocally(field, parsedValue);
    }
  }

  // Add this method for date picking
  Future<void> _pickDateForEdit(
      SAPMainOrder order,
      String field,
      String currentValue,
      ) async {
    final currentDate = DateTime.tryParse(currentValue) ?? DateTime.now();

    final pickedDate = await showDatePicker(
      context: context,
      initialDate: currentDate,
      firstDate: DateTime(2020),
      lastDate: DateTime(2030),
    );

    if (pickedDate != null) {
      final formattedDate = DateFormat('yyyy-MM-dd').format(pickedDate);

      // If multiple rows selected, apply to all
      if (_editMode && _selectedRowsIds.length > 1) {
        await _applyBulkEditToSelected(field, formattedDate);
        return;
      }

      // Single row update
      try {
        final supabase = Supabase.instance.client;
        await supabase
            .from('sap_main_orders')
            .update({field: formattedDate})
            .eq('id', order.id);

        await _auditService.logChange(
          orderId: order.id,
          designOrder: order.designOrder,
          fieldName: field,
          oldValue: currentValue == '-' ? '' : currentValue,
          newValue: formattedDate,
          changedBy: _currentUserName,
          changedById: _currentUserId,
        );

        _showSnackBar('${_formatFieldName(field)} updated!');
        _updateOrderLocally(order.id, field, formattedDate);
      } catch (e) {
        _showSnackBar('Error updating: $e');
      }
    }
  }

  // Add this method to show an edit dialog for any field
  Future<void> _editOrderField(
      SAPMainOrder order,
      String field,
      String currentValue,
      ) async {
    // If multiple rows are selected in edit mode, apply to ALL selected rows
    if (_editMode && _selectedRowsIds.length > 1) {
      // Just call bulk edit directly
      _bulkEditField(field, currentValue);
      return;
    }

    // Single row edit (normal behavior)
    final controller = TextEditingController(text: currentValue);

    final newValue = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(
          'Edit ${_formatFieldName(field)}',
          style: GoogleFonts.cairo(fontWeight: FontWeight.w600),
        ),
        content: TextField(
          controller: controller,
          style: GoogleFonts.cairo(fontSize: 14),
          decoration: InputDecoration(
            labelText: _formatFieldName(field),
            border: const OutlineInputBorder(),
          ),
          maxLines: field == 'description' ? 3 : 1,
          keyboardType: field == 'quantity' || field == 'value'
              ? TextInputType.number
              : TextInputType.text,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: Text('Cancel', style: GoogleFonts.cairo()),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, controller.text),
            style: ElevatedButton.styleFrom(
              backgroundColor: Theme.of(context).colorScheme.primary,
            ),
            child: Text('Save', style: GoogleFonts.cairo(color: Theme.of(context).colorScheme.onPrimary)),
          ),
        ],
      ),
    );

    if (newValue != null && newValue != currentValue) {
      try {
        final supabase = Supabase.instance.client;
        dynamic parsedValue = newValue;

        if (field == 'quantity') {
          parsedValue = double.tryParse(newValue.replaceAll(',', '')) ?? 0;
        } else if (field == 'value') {
          parsedValue =
              double.tryParse(
                newValue.replaceAll(',', '').replaceAll('\$', ''),
              ) ??
                  0;
        }

        await supabase
            .from(_archivedOrderIds.contains(order.id) ? 'sap_done_orders' : 'sap_main_orders')
            .update({field: parsedValue})
            .eq('id', order.id);

        await _auditService.logChange(
          orderId: order.id,
          designOrder: order.designOrder,
          fieldName: field,
          oldValue: currentValue,
          newValue: newValue,
          changedBy: _currentUserName,
          changedById: _currentUserId,
        );

        _showSnackBar('${_formatFieldName(field)} updated!');
        _updateOrderLocally(
          order.id,
          field,
          parsedValue,
        ); // ✅ Local update instead of reload
      } catch (e) {
        _showSnackBar('Error updating: $e');
      }
    }
  }

  // Helper to format field names nicely
  String _formatFieldName(String field) {
    switch (field) {
      case 'customer_name':
        return 'Customer Name';
      case 'contract_number':
        return 'Contract Number';
      case 'design_order':
        return 'Design Order';
      case 'item_number':
        return 'Item';
      case 'product_code':
        return 'Product Code';
      case 'description':
        return 'Description';
      case 'quantity':
        return 'QTY';
      case 'unit_of_measure':
        return 'Unit';
      case 'value':
        return 'Value';
      case 'sales_engineer':
        return 'Sales Engineer';
      case 'order_date':
        return 'O-Date';
      case 'end_date':
        return 'End Date';
      case 'delivery_date':
        return 'Delivery Date';
      case 'factory':
        return 'Factory';
      case 'design_team':
        return 'Design Team';
      case 'responsible_engineer':
        return 'Resp. Engineer';
      case 'reviewer':
        return 'Reviewer';
      case 'correspondence_engineer':
        return 'Alt. Engineer';
      case 'status':
        return 'Status';
      default:
        return field;
    }
  }

  // Update order locally without a full reload.
  // Keep both the normal list and the all-table search cache in sync;
  // otherwise a search result can keep showing the old value after a save.
  void _updateOrderLocally(String orderId, String field, dynamic newValue) {
    SAPMainOrder updateOrder(SAPMainOrder oldOrder) {
      return SAPMainOrder(
        id: oldOrder.id,
        status: field == 'status' ? newValue.toString() : oldOrder.status,
        customerName: field == 'customer_name'
            ? newValue.toString()
            : oldOrder.customerName,
        itemNumber: field == 'item_number'
            ? newValue.toString()
            : oldOrder.itemNumber,
        productCode: field == 'product_code'
            ? newValue.toString()
            : oldOrder.productCode,
        contractNumber: field == 'contract_number'
            ? newValue.toString()
            : oldOrder.contractNumber,
        description: field == 'description'
            ? newValue.toString()
            : oldOrder.description,
        designOrder: field == 'design_order'
            ? newValue.toString()
            : oldOrder.designOrder,
        quantity: field == 'quantity'
            ? (newValue as num).toDouble()
            : oldOrder.quantity,
        unitOfMeasure: field == 'unit_of_measure'
            ? newValue.toString()
            : oldOrder.unitOfMeasure,
        value: field == 'value'
            ? (newValue as num).toDouble()
            : oldOrder.value,
        salesEngineer: field == 'sales_engineer'
            ? newValue.toString()
            : oldOrder.salesEngineer,
        orderDate: field == 'order_date'
            ? newValue.toString()
            : oldOrder.orderDate,
        deliveryDate: field == 'delivery_date'
            ? newValue?.toString()
            : oldOrder.deliveryDate,
        endDate: field == 'end_date'
            ? newValue?.toString()
            : oldOrder.endDate,
        factory: field == 'factory'
            ? newValue?.toString()
            : oldOrder.factory,
        designTeam: field == 'design_team'
            ? newValue?.toString()
            : oldOrder.designTeam,
        responsibleEngineer: field == 'responsible_engineer'
            ? newValue?.toString()
            : oldOrder.responsibleEngineer,
        reviewer: field == 'reviewer'
            ? newValue?.toString()
            : oldOrder.reviewer,
        correspondenceEngineer: field == 'correspondence_engineer'
            ? newValue?.toString()
            : oldOrder.correspondenceEngineer,
        createdAt: oldOrder.createdAt,
      );
    }

    setState(() {
      final index = _allOrders.indexWhere((o) => o.id == orderId);
      if (index != -1) {
        final oldOrder = _allOrders[index];
        final updatedOrder = updateOrder(oldOrder);
        _allOrders[index] = updatedOrder;
        _orderIndexMap.remove(oldOrder);
        _orderIndexMap[updatedOrder] = index;
      }

      final searchIndex =
          _searchResults?.indexWhere((o) => o.id == orderId) ?? -1;
      if (searchIndex != -1 && _searchResults != null) {
        _searchResults![searchIndex] = updateOrder(_searchResults![searchIndex]);
      }

      final doneIndex = _doneOrders.indexWhere((o) => o.id == orderId);
      if (doneIndex != -1) {
        _doneOrders[doneIndex] = updateOrder(_doneOrders[doneIndex]);
      }
    });
    _rebuildGroups();
  }

  Future<String?> _showEmployeeAssignmentDialog({
    required String field,
    required String? currentValue,
  }) async {
    final searchController = TextEditingController();

    final result = await showDialog<String>(
      context: context,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            final query = searchController.text.trim().toLowerCase();

            final filteredEmployees = _allEmployees.where((emp) {
              if (query.isEmpty) return true;

              final name = emp.fullName.toLowerCase();
              final role = emp.role?.toLowerCase() ?? '';
              final initials = emp.initials.toLowerCase();

              return name.contains(query) ||
                  role.contains(query) ||
                  initials.contains(query);
            }).toList();

            return AlertDialog(
              titlePadding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
              contentPadding: const EdgeInsets.fromLTRB(20, 8, 20, 16),
              title: Row(
                children: [
                  Expanded(
                    child: Text(
                      field == 'responsible_engineer'
                          ? 'Assign Responsible Engineer'
                          : field == 'reviewer'
                          ? 'Assign Reviewer'
                          : 'Assign Alternative Engineer',
                      style: GoogleFonts.cairo(
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                  IconButton(
                    tooltip: 'Close',
                    onPressed: () => Navigator.pop(dialogContext),
                    icon: const Icon(Icons.close, size: 20),
                  ),
                ],
              ),
              content: SizedBox(
                width: 360,
                height: 430,
                child: Column(
                  children: [
                    TextField(
                      controller: searchController,
                      autofocus: true,
                      onChanged: (_) => setDialogState(() {}),
                      decoration: InputDecoration(
                        hintText: 'Search employee...',
                        hintStyle: GoogleFonts.cairo(fontSize: 12),
                        prefixIcon: const Icon(Icons.search, size: 20),
                        suffixIcon: searchController.text.isNotEmpty
                            ? IconButton(
                          tooltip: 'Clear search',
                          onPressed: () {
                            searchController.clear();
                            setDialogState(() {});
                          },
                          icon: const Icon(Icons.clear, size: 18),
                        )
                            : null,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 10,
                          vertical: 10,
                        ),
                      ),
                      style: GoogleFonts.cairo(fontSize: 12),
                    ),
                    const SizedBox(height: 10),
                    Expanded(
                      child: filteredEmployees.isEmpty
                          ? Center(
                        child: Text(
                          'No employees found',
                          style: GoogleFonts.cairo(
                            fontSize: 12,
                            color: _secondaryTextColor,
                          ),
                        ),
                      )
                          : ListView.separated(
                        itemCount: filteredEmployees.length,
                        separatorBuilder: (_, __) => Divider(
                          height: 1,
                          color: _borderColor,
                        ),
                        itemBuilder: (context, index) {
                          final emp = filteredEmployees[index];
                          final isSelected =
                              currentValue == emp.fullName;

                          return ListTile(
                            dense: true,
                            contentPadding: const EdgeInsets.symmetric(
                              horizontal: 4,
                              vertical: 2,
                            ),
                            leading: CircleAvatar(
                              radius: 16,
                              backgroundColor:
                              Colors.blue.withOpacity(0.12),
                              child: Text(
                                emp.initials,
                                style: GoogleFonts.cairo(
                                  fontSize: 10,
                                  fontWeight: FontWeight.w700,
                                  color: Colors.blue,
                                ),
                              ),
                            ),
                            title: Text(
                              emp.fullName,
                              style: GoogleFonts.cairo(
                                fontSize: 12,
                                fontWeight: isSelected
                                    ? FontWeight.w700
                                    : FontWeight.w500,
                                color: isSelected
                                    ? const Color(0xFF6366F1)
                                    : _textColor,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                            subtitle: emp.role != null &&
                                emp.role!.trim().isNotEmpty
                                ? Text(
                              emp.role!,
                              style: GoogleFonts.cairo(
                                fontSize: 10,
                                color: _secondaryTextColor,
                              ),
                              overflow: TextOverflow.ellipsis,
                            )
                                : null,
                            trailing: isSelected
                                ? const Icon(
                              Icons.check_circle,
                              size: 18,
                              color: Color(0xFF6366F1),
                            )
                                : null,
                            onTap: () {
                              Navigator.pop(
                                dialogContext,
                                emp.fullName,
                              );
                            },
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );

    searchController.dispose();
    return result;
  }

  Future<void> _updateOrderEngineer(
      SAPMainOrder order,
      String field,
      String? newValue,
      ) async {
    final oldValue = _getCurrentFieldValue(order, field);

    // A header row must never have an Alternative Engineer.
    if (field == 'correspondence_engineer' &&
        _isHeaderResponsibleEngineerRow(order)) {
      _showYellowWarning(
        '⚠️ Alternative Engineer is locked when Responsible Engineer is header.',
      );
      return;
    }

    // Header rows can only be changed by admins.
    if (field == 'responsible_engineer' &&
        _isHeaderResponsibleEngineerRow(order) &&
        !_isAdmin) {
      _showYellowWarning(
        '⚠️ Only admins can change the Responsible Engineer of a header row.',
      );
      return;
    }

    // Responsible Engineer may be cleared only when the CURRENT status is
    // Drawing Submittal, Imported, or Automated. This check intentionally
    // comes before the "No One" lock so those statuses can also be cleared.
    if (field == 'responsible_engineer' &&
        (newValue == null || newValue.trim().isEmpty) &&
        !_canClearResponsibleEngineer(order.status)) {
      _showYellowWarning(
        '⚠️ Responsible Engineer cannot be empty for this order.',
      );
      return;
    }

    if (_isOrderLocked(order)) {
      _showYellowWarning('⚠️ Cannot edit "Done", "Task Done", "Planning", or "Master Data" orders');
      return;
    }

    // If multiple rows selected, apply to all
    if (_selectedRowsIds.length > 1) {
      setState(() => _isLoading = true);
      final supabase = Supabase.instance.client;
      int updated = 0;
      int skipped = 0;

      for (var orderId in _selectedRowsIds) {
        final selectedOrder = _allOrders
            .where((o) => o.id == orderId)
            .firstOrNull;
        if (selectedOrder != null) {
          final selectedStatus =
          selectedOrder.status.trim().toLowerCase();

          if ((selectedStatus == 'imported' ||
              selectedStatus == 'automated') &&
              !_hasRequiredStatusChangeFields(selectedOrder)) {
            skipped++;
            continue;
          }

          // Skip locked orders
          if (_isOrderLocked(selectedOrder)) {
            skipped++;
            continue;
          }

          // Header rows cannot have an Alternative Engineer.
          if (field == 'correspondence_engineer' &&
              _isHeaderResponsibleEngineerRow(selectedOrder)) {
            skipped++;
            continue;
          }

          // "No One" is locked for non-admin users, just like a header row.
          if (field == 'responsible_engineer' &&
              _isNoOneResponsibleEngineerLocked(selectedOrder)) {
            skipped++;
            continue;
          }

          try {
            await supabase
                .from('sap_main_orders')
                .update({field: newValue})
                .eq('id', selectedOrder.id);

            await _auditService.logChange(
              orderId: selectedOrder.id,
              designOrder: selectedOrder.designOrder,
              fieldName: field,
              oldValue: _getCurrentFieldValue(selectedOrder, field),
              newValue: newValue,
              changedBy: _currentUserName,
              changedById: _currentUserId,
              actionType: 'bulk_update',
            );
            updated++;
          } catch (e) {
            print('Failed: $e');
          }
        }
      }

      setState(() => _isLoading = false);
      if (skipped > 0) {
        _showSnackBar('✅ ${_formatFieldName(field)} updated for $updated rows, ⚠️ $skipped locked rows skipped');
      } else {
        _showSnackBar('✅ ${_formatFieldName(field)} updated for $updated rows!');
      }
      _updateMultipleOrdersLocally(field, newValue);
      return;
    }

    // Single row update
    try {
      final supabase = Supabase.instance.client;
      await supabase
          .from('sap_main_orders')
          .update({field: newValue})
          .eq('id', order.id);

      await _auditService.logChange(
        orderId: order.id,
        designOrder: order.designOrder,
        fieldName: field,
        oldValue: oldValue,
        newValue: newValue,
        changedBy: _currentUserName,
        changedById: _currentUserId,
      );

      _showSnackBar('Updated successfully!');
      _updateOrderLocally(order.id, field, newValue);
    } catch (e) {
      _showSnackBar('Error updating: $e');
    }
  }

  void _showYellowWarning(String warning) {
    if (!mounted) return;

    ScaffoldMessenger.of(context).hideCurrentSnackBar();

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            const Icon(
              Icons.warning_amber_rounded,
              color: Colors.white,
              size: 22,
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                warning,
                style: GoogleFonts.cairo(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: Colors.white,
                ),
              ),
            ),
          ],
        ),
        backgroundColor: Colors.amber.shade700,
        behavior: SnackBarBehavior.floating,
        duration: const Duration(milliseconds: 3000),
        margin: const EdgeInsets.all(16),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
      ),
    );
  }

  Future<void> _updateOrderDesignTeam(
      SAPMainOrder order,
      String newValue,
      ) async {
    final oldValue = order.designTeam;
    final isImported =
        order.status.trim().toLowerCase() == 'imported';

    // Only Imported orders require the SAP fields before changing Design Team.
    if (isImported && !_hasRequiredStatusChangeFields(order)) {
      _showYellowWarning(
        '⚠️ Complete these fields before changing Design Team: '
            '${_missingRequiredStatusChangeFields(order)}',
      );
      return;
    }

    // Changing Design Team changes the Status/section ONLY for Imported orders.
    String getAutoStatus(String team, String currentStatus) {
      if (currentStatus.trim().toLowerCase() != 'imported') {
        return currentStatus;
      }

      switch (team) {
        case 'partition division':
        case 'product division':
        case 'Chair & Sofa Division':
        case 'cladding division':
          return 'Drawing Submittal';
        case 'Master Data division':
          return 'Master Data';
        case 'الادارة الهندسة':
          return 'الادارة الهندسه';
        case 'تصميم المنتجات':
          return 'ادارة تصميم المنتجات';
        case 'design studio':
          return 'design studio';
        case 'planning':
          return 'planning';
        default:
          return currentStatus;
      }
    }

    if (_isOrderLocked(order)) {
      _showYellowWarning(
        '⚠️ Cannot edit "Done", "Task Done", "Planning", or "Master Data" orders',
      );
      return;
    }

    // If multiple rows are selected, apply the same Design Team to each row.
    // Only Imported rows get the automatic Status/section transition.
    if (_selectedRowsIds.length > 1) {
      setState(() => _isLoading = true);
      final supabase = Supabase.instance.client;
      int updated = 0;
      int skipped = 0;
      int statusChanged = 0;

      for (final orderId in _selectedRowsIds) {
        final selectedOrder =
            _allOrders.where((o) => o.id == orderId).firstOrNull;
        if (selectedOrder == null) continue;

        if (_isOrderLocked(selectedOrder)) {
          skipped++;
          continue;
        }

        final selectedIsImported =
            selectedOrder.status.trim().toLowerCase() == 'imported';

        if (selectedIsImported &&
            !_hasRequiredStatusChangeFields(selectedOrder)) {
          skipped++;
          continue;
        }

        final selectedAutoStatus =
        getAutoStatus(newValue, selectedOrder.status);
        final updateValues = <String, dynamic>{
          'design_team': newValue,
        };
        if (selectedAutoStatus != selectedOrder.status) {
          updateValues['status'] = selectedAutoStatus;
        }

        try {
          await supabase
              .from('sap_main_orders')
              .update(updateValues)
              .eq('id', selectedOrder.id);

          await _auditService.logChange(
            orderId: selectedOrder.id,
            designOrder: selectedOrder.designOrder,
            fieldName: 'design_team',
            oldValue: selectedOrder.designTeam,
            newValue: newValue,
            changedBy: _currentUserName,
            changedById: _currentUserId,
            actionType: 'bulk_update',
          );

          if (selectedAutoStatus != selectedOrder.status) {
            await _auditService.logChange(
              orderId: selectedOrder.id,
              designOrder: selectedOrder.designOrder,
              fieldName: 'status',
              oldValue: selectedOrder.status,
              newValue: selectedAutoStatus,
              changedBy: _currentUserName,
              changedById: _currentUserId,
              actionType: 'bulk_update',
            );
            statusChanged++;
          }

          updated++;
          _updateOrderLocally(selectedOrder.id, 'design_team', newValue);
          if (selectedAutoStatus != selectedOrder.status) {
            _updateOrderLocally(
              selectedOrder.id,
              'status',
              selectedAutoStatus,
            );
          }
        } catch (e) {
          print('Failed to update Design Team for ${selectedOrder.id}: $e');
          skipped++;
        }
      }

      if (mounted) setState(() => _isLoading = false);

      if (skipped > 0) {
        _showSnackBar(
          '✅ Design Team updated for $updated rows; '
              '⚠️ $skipped rows skipped (locked or Imported rows missing required fields).',
        );
      } else if (statusChanged > 0) {
        _showSnackBar(
          '✅ Design Team updated for $updated rows; '
              'Status/section changed for $statusChanged Imported rows.',
        );
      } else {
        _showSnackBar(
          '✅ Design Team updated for $updated rows. Status/section unchanged.',
        );
      }
      return;
    }

    // Single-row update.
    final autoStatus = getAutoStatus(newValue, order.status);
    final updateValues = <String, dynamic>{'design_team': newValue};
    if (autoStatus != order.status) {
      updateValues['status'] = autoStatus;
    }

    try {
      final supabase = Supabase.instance.client;
      await supabase
          .from('sap_main_orders')
          .update(updateValues)
          .eq('id', order.id);

      await _auditService.logChange(
        orderId: order.id,
        designOrder: order.designOrder,
        fieldName: 'design_team',
        oldValue: oldValue,
        newValue: newValue,
        changedBy: _currentUserName,
        changedById: _currentUserId,
      );

      if (autoStatus != order.status) {
        await _auditService.logChange(
          orderId: order.id,
          designOrder: order.designOrder,
          fieldName: 'status',
          oldValue: order.status,
          newValue: autoStatus,
          changedBy: _currentUserName,
          changedById: _currentUserId,
        );
        _showSnackBar('Design Team → $newValue, Status → $autoStatus');
        _updateOrderLocally(order.id, 'status', autoStatus);
      } else {
        _showSnackBar('Design Team updated → $newValue. Status unchanged.');
      }

      _updateOrderLocally(order.id, 'design_team', newValue);
    } catch (e) {
      _showSnackBar('Error updating: $e');
    }
  }

  // ==================== SCROLL SYNC ====================
  bool _onLeftScrollNotification(ScrollNotification notification) {
    if (notification is ScrollUpdateNotification && !_isSyncing) {
      if (_rightVerticalScrollController.hasClients) {
        _isSyncing = true;
        _rightVerticalScrollController.jumpTo(
          _leftVerticalScrollController.offset,
        );
        _isSyncing = false;
      }
    }
    return false;
  }

  bool _onRightScrollNotification(ScrollNotification notification) {
    if (notification is ScrollUpdateNotification && !_isSyncing) {
      if (_leftVerticalScrollController.hasClients) {
        _isSyncing = true;
        _leftVerticalScrollController.jumpTo(
          _rightVerticalScrollController.offset,
        );
        _isSyncing = false;
      }
    }
    return false;
  }

  String _formatNumber(double number) {
    if (number == 0) return '0.00';
    final parts = number.toStringAsFixed(2).split('.');
    final buffer = StringBuffer();
    for (int i = 0; i < parts[0].length; i++) {
      if (i > 0 && (parts[0].length - i) % 3 == 0) buffer.write(',');
      buffer.write(parts[0][i]);
    }
    return '${buffer.toString()}.${parts[1]}';
  }

  // Replace the bulk update reload:
  void _updateMultipleOrdersLocally(String field, dynamic newValue) {
    setState(() {
      for (var orderId in _selectedRowsIds) {
        final index = _allOrders.indexWhere((o) => o.id == orderId);
        if (index != -1) {
          final oldOrder = _allOrders[index];

          // Skip locked orders
          if (_isOrderLocked(oldOrder)) {
            continue;
          }

          final updatedOrder = SAPMainOrder(
            id: oldOrder.id,
            status: field == 'status' ? newValue.toString() : oldOrder.status,
            customerName: field == 'customer_name'
                ? newValue.toString()
                : oldOrder.customerName,
            itemNumber: field == 'item_number'
                ? newValue.toString()
                : oldOrder.itemNumber,
            productCode: field == 'product_code'
                ? newValue.toString()
                : oldOrder.productCode,
            contractNumber: field == 'contract_number'
                ? newValue.toString()
                : oldOrder.contractNumber,
            description: field == 'description'
                ? newValue.toString()
                : oldOrder.description,
            designOrder: field == 'design_order'
                ? newValue.toString()
                : oldOrder.designOrder,
            quantity: field == 'quantity'
                ? (newValue as double)
                : oldOrder.quantity,
            unitOfMeasure: field == 'unit_of_measure'
                ? newValue.toString()
                : oldOrder.unitOfMeasure,
            value: field == 'value' ? (newValue as double) : oldOrder.value,
            salesEngineer: field == 'sales_engineer'
                ? newValue.toString()
                : oldOrder.salesEngineer,
            orderDate: field == 'order_date'
                ? newValue.toString()
                : oldOrder.orderDate,
            endDate: field == 'end_date'
                ? newValue.toString()
                : oldOrder.endDate,
            deliveryDate: field == 'delivery_date'
                ? newValue.toString()
                : oldOrder.deliveryDate,
            factory: field == 'factory'
                ? newValue.toString()
                : oldOrder.factory,
            designTeam: field == 'design_team'
                ? newValue.toString()
                : oldOrder.designTeam,
            responsibleEngineer: field == 'responsible_engineer'
                ? newValue.toString()
                : oldOrder.responsibleEngineer,
            reviewer: field == 'reviewer'
                ? newValue.toString()
                : oldOrder.reviewer,
            correspondenceEngineer: field == 'correspondence_engineer'
                ? newValue.toString()
                : oldOrder.correspondenceEngineer,
            createdAt: oldOrder.createdAt,
          );
          _allOrders[index] = updatedOrder;
          _orderIndexMap.remove(oldOrder);
          _orderIndexMap[updatedOrder] = index;
        }
      }
    });
    _rebuildGroups();
  }

  // ==================== DATA LOADING ====================
  Future<void> _loadApprovalTrackingOrders() async {
    setState(() => _isLoading = true);
    try {
      final client = Supabase.instance.client;
      const pageSize = 1000;
      final ordersById = <String, SAPMainOrder>{};
      final archivedIds = <String>{};

      // This page intentionally loads every row from both tables, not only
      // the recent archived subset used by the regular Orders screen.
      for (final table in ['sap_main_orders', 'sap_done_orders']) {
        var offset = 0;
        while (true) {
          final rows = await client
              .from(table)
              .select('*')
              .order('created_at', ascending: false)
              .range(offset, offset + pageSize - 1);
          final batch = (rows as List)
              .map((row) => SAPMainOrder.fromJson(
            Map<String, dynamic>.from(row),
          ))
              .toList();
          for (final order in batch) {
            ordersById[order.id] = order;
            if (table == 'sap_done_orders') archivedIds.add(order.id);
          }
          if (batch.length < pageSize) break;
          offset += pageSize;
        }
      }

      final auditByOrder = <String, List<Map<String, dynamic>>>{};
      var auditOffset = 0;
      while (true) {
        final rows = await client
            .from('order_audit_log')
            .select('order_id, field_name, old_value, new_value, changed_at')
            .eq('field_name', 'status')
            .order('changed_at', ascending: true)
            .range(auditOffset, auditOffset + pageSize - 1);
        final batch = (rows as List)
            .map((row) => Map<String, dynamic>.from(row))
            .toList();
        for (final audit in batch) {
          final orderId = (audit['order_id'] ?? '').toString();
          if (orderId.isEmpty) continue;
          auditByOrder.putIfAbsent(orderId, () => []).add(audit);
        }
        if (batch.length < pageSize) break;
        auditOffset += pageSize;
      }

      String dateOnly(dynamic raw) {
        final parsed = DateTime.tryParse((raw ?? '').toString());
        return parsed == null ? '' : DateFormat('yyyy-MM-dd').format(parsed.toLocal());
      }

      _approvalTrackingByOrder.clear();
      for (final entry in auditByOrder.entries) {
        final milestones = <String, String>{
          'drawing_approval_date': '',
          'sales_approval_date': '',
          'modifications_count': '0',
          'modifications_last_date': '',
          'operation_date': '',
        };
        var modificationCount = 0;
        for (final audit in entry.value) {
          final oldStatus = (audit['old_value'] ?? '').toString().trim().toLowerCase();
          final newStatus = (audit['new_value'] ?? '').toString().trim().toLowerCase();
          final changedAt = dateOnly(audit['changed_at']);
          if (changedAt.isEmpty) continue;

          if (oldStatus == 'drawing submittal' && newStatus == 'approval' &&
              milestones['drawing_approval_date']!.isEmpty) {
            milestones['drawing_approval_date'] = changedAt;
          }
          if (oldStatus == 'approval' && newStatus == 'manufacturing drawing' &&
              milestones['sales_approval_date']!.isEmpty) {
            milestones['sales_approval_date'] = changedAt;
          }
          if (oldStatus == 'modifications submitted' && newStatus == 'approval') {
            modificationCount++;
            milestones['modifications_last_date'] = changedAt;
          }
          if ((oldStatus == 'manufacturing drawing' || oldStatus == 'review') &&
              newStatus == 'master data' &&
              milestones['operation_date']!.isEmpty) {
            milestones['operation_date'] = changedAt;
          }
        }
        milestones['modifications_count'] = modificationCount.toString();
        _approvalTrackingByOrder[entry.key] = milestones;
      }

      if (!mounted) return;
      final orders = ordersById.values.toList()
        ..sort((a, b) => (b.createdAt ?? DateTime(1970))
            .compareTo(a.createdAt ?? DateTime(1970)));
      setState(() {
        _allOrders = orders;
        _archivedOrderIds
          ..clear()
          ..addAll(archivedIds);
        _orderIndexMap = {
          for (var i = 0; i < orders.length; i++) orders[i]: i,
        };
        _initialLoadDone = true;
        _isLoading = false;
        _rebuildGroups();
      });
    } catch (e, stack) {
      debugPrint('Approval tracking load failed: $e\\n$stack');
      if (mounted) setState(() {
        _isLoading = false;
        _initialLoadDone = true;
      });
      if (mounted) _showSnackBar('Could not load approval tracking: $e');
    }
  }

  Future<void> _loadAllDataOnce() async {
    if (widget.approvalTrackingMode) {
      await _loadApprovalTrackingOrders();
      return;
    }
    setState(() => _isLoading = true);
    try {
      final supabase = Supabase.instance.client;

      // Fetch and render the main table immediately; do not wait for tracking,
      // employee metadata, or archived records before showing orders.
      final activeOrders = await widget.sapService.getAllOrders();
      if (!mounted) return;
      setState(() {
        _allOrders = activeOrders;
        _archivedOrderIds.clear();
        _orderIndexMap = {
          for (int i = 0; i < activeOrders.length; i++) activeOrders[i]: i,
        };
        _initialLoadDone = true;
        _isLoading = false;
        _rebuildGroups();
      });

      // The archived page only needs SAP order records to build the table.
      // Avoid loading unrelated tracking/job datasets there; these queries
      // are not required for the SAP Done Orders table and can fail if those
      // optional tables are not installed in this Supabase project.
      if (!widget.doneOrdersOnly) {
        final allTrackings = await _trackingService.getAllProductTracking();
        _allTrackingCache = {};
        for (var t in allTrackings) {
          _allTrackingCache[t.productCode.toLowerCase().trim()] = t;
        }

        final allJobs = await _employeeService.getAllJobs();
        _jobsCache = {};
        for (var job in allJobs) {
          _jobsCache.putIfAbsent(job.productCode, () => []).add(job);
          if (!_employeeCache.containsKey(job.employeeId)) {
            _employeeCache[job.employeeId] = await _employeeService
                .getEmployeeById(job.employeeId);
          }
        }
      }

      // Load employees from employees_auth table
      final employeeAuthService = EmployeeAuthService(supabase);
      _allEmployees = await employeeAuthService.getAllEmployees();

      // Keep only the newest 200 archived rows in the normal page dataset.
      // Older archived rows are fetched from both tables only when searching.
      final archivedRows = await supabase
          .from('sap_done_orders')
          .select('*')
          .order('created_at', ascending: false)
          .limit(200);
      final recentArchived = (archivedRows as List)
          .map((row) => SAPMainOrder.fromJson(Map<String, dynamic>.from(row)))
          .toList();
      if (!mounted) return;
      setState(() {
        _archivedOrderIds
          ..clear()
          ..addAll(recentArchived.map((order) => order.id));
        _allOrders = [..._allOrders, ...recentArchived];
        _orderIndexMap = {
          for (int i = 0; i < _allOrders.length; i++) _allOrders[i]: i,
        };
        _rebuildGroups();
      });
      print('✅ Loaded ${activeOrders.length} active + '
          '${recentArchived.length} recent archived orders.');
    } catch (e) {
      setState(() => _isLoading = false);
    }
  }


  bool _initialLoadDone = false;

  Future<void> _toggleDoneOrders() async {
    if (_doneOrdersExpanded) {
      setState(() => _doneOrdersExpanded = false);
      return;
    }

    setState(() => _doneOrdersExpanded = true);
    if (_doneOrdersLoaded || _doneOrdersLoading) return;

    setState(() => _doneOrdersLoading = true);
    try {
      final orders = await widget.sapService.getAllDoneOrders();
      if (!mounted) return;
      setState(() {
        _doneOrders = orders;
        _doneOrdersLoaded = true;
        _doneOrdersLoading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _doneOrdersLoading = false);
      _showSnackBar('Error loading SAP done orders: $e');
    }
  }

  void _refreshDoneOrdersLater() {
    if (!_doneOrdersLoaded) return;
    widget.sapService.getAllDoneOrders().then((orders) {
      if (!mounted) return;
      setState(() => _doneOrders = orders);
    });
  }

  void _scheduleSearchAllOrders(String value) {
    _searchDebounce?.cancel();
    if (widget.approvalTrackingMode) {
      // All rows are already loaded for this report; filter locally by order ID.
      _searchResults = null;
      _rebuildGroups();
      return;
    }
    final query = value.trim();
    final requestId = ++_searchRequestId;
    if (query.isEmpty) {
      setState(() {
        _searchResults = null;
        _isSearchingAllOrders = false;
      });
      _rebuildGroups();
      return;
    }

    setState(() {
      _searchResults = null;
      _isSearchingAllOrders = true;
    });
    _searchDebounce = Timer(const Duration(milliseconds: 350), () async {
      try {
        final client = Supabase.instance.client;
        final matches = <SAPMainOrder>[];
        final archivedIds = <String>{};
        const pageSize = 1000;
        final safeQuery = query.replaceAll('%', r'\%').replaceAll('_', r'\_');
        final orFilter = 'contract_number.ilike.%$safeQuery%,'
            'customer_name.ilike.%$safeQuery%,'
            'design_order.ilike.%$safeQuery%,'
            'description.ilike.%$safeQuery%';

        // Search every matching row in BOTH tables, paging beyond Supabase's
        // default response limit so old archived contracts are not missed.
        for (final table in ['sap_main_orders', 'sap_done_orders']) {
          var offset = 0;
          while (true) {
            final rows = await client
                .from(table)
                .select('*')
                .or(orFilter)
                .order('created_at', ascending: false)
                .range(offset, offset + pageSize - 1);
            final batch = (rows as List)
                .map((row) => SAPMainOrder.fromJson(
                Map<String, dynamic>.from(row)))
                .toList();
            matches.addAll(batch);
            if (table == 'sap_done_orders') {
              archivedIds.addAll(batch.map((order) => order.id));
            }
            if (batch.length < pageSize) break;
            offset += pageSize;
          }
        }

        if (!mounted || requestId != _searchRequestId) return;
        final unique = <String, SAPMainOrder>{};
        for (final order in matches) {
          unique[order.id] = order;
        }
        final results = unique.values.toList();
        setState(() {
          _searchResults = results;
          _archivedOrderIds.addAll(archivedIds);
          _isSearchingAllOrders = false;
        });
        _rebuildGroups();
      } catch (e) {
        if (!mounted || requestId != _searchRequestId) return;
        setState(() => _isSearchingAllOrders = false);
        _showSnackBar('Could not search all orders: $e');
      }
    });
  }

  void _rebuildGroups() {
    final filtered = _getFilteredOrders();
    _groupedOrders = {};
    for (var order in filtered) {
      final status = order.status;
      _groupedOrders.putIfAbsent(status, () => []).add(order);
    }

    // Sort sections based on _allStatuses order instead of count
    _sortedStatuses = _groupedOrders.keys.toList()
      ..sort((a, b) {
        final indexA = _allStatuses.indexOf(a);
        final indexB = _allStatuses.indexOf(b);
        // If not found in list, put at end
        if (indexA == -1 && indexB == -1) return a.compareTo(b);
        if (indexA == -1) return 1;
        if (indexB == -1) return -1;
        return indexA.compareTo(indexB);
      });

    _rebuildFlatList();
  }

  void _rebuildFlatList() {
    final list = <dynamic>[];
    for (var status in _sortedStatuses) {
      list.add(status);
      if (_expandedSections.contains(status))
        list.addAll(_groupedOrders[status]!);
    }
    setState(() => _flatList = list);
  }

  void _toggleSection(String status) {
    if (_expandedSections.contains(status)) {
      _expandedSections.remove(status);
    } else {
      _expandedSections.add(status);
    }
    _rebuildFlatList();
  }

  // ==================== HELPERS ====================
  String _getProductStatus(String? productCode) {
    if (productCode == null || productCode.isEmpty) return 'Unknown';
    if (_jobsCache.containsKey(productCode))
      return _jobsCache[productCode]!.first.status;
    final lower = productCode.toLowerCase().trim();
    if (_allTrackingCache.containsKey(lower))
      return _allTrackingCache[lower]!.section;
    return 'Unknown';
  }

  String _getProductEmployee(String? productCode) {
    if (productCode == null || productCode.isEmpty) return '-';
    if (_jobsCache.containsKey(productCode))
      return _jobsCache[productCode]!.first.employeeName;
    return '-';
  }

  Color _getStatusColor(String status) {
    switch (status) {
      case 'مطلوب اكوادها الاسترشاديه':
        return Colors.blue;
      case 'تحت المراجعة':
        return Colors.orange;
      case 'Drawing Submittal':
        return Colors.purple;
      case 'modifications submitted':
        return Colors.teal;
      case 'Approval':
        return Colors.green;
      case 'Manufacturing Drawing':
        return Colors.indigo;
      case 'Review':
        return Colors.amber;
      case 'Master Data':
        return Colors.cyan;
      case 'Sales':
        return Colors.deepOrange;
      case 'As Built':
        return Colors.brown;
      case 'Tasks':
        return Colors.lime;
      case 'planning':
        return Colors.pink;
      case 'partation  master data':
        return Colors.deepPurple;
      case 'Done':
        return Colors.green;
      case 'الادارة الهندسه':
        return Colors.blueGrey;
      case 'design studio':
        return Colors.red;
      case 'pending':
        return Colors.orange;
      case 'in_progress':
        return Colors.blue;
      case 'completed':
        return Colors.green;
      case 'on_hold':
        return Colors.red;
      default:
        return _isDarkMode ? Colors.grey.shade400 : Colors.grey;
    }
  }

  // Add this method near _isOrderEditable
  bool _isOrderLocked(SAPMainOrder order) {
    final lockedStatuses = ['task done', 'done', 'planning', 'master data'];
    return lockedStatuses.contains(order.status.toLowerCase());
  }

  // Add this method to _OrdersPageState class
  Future<void> _deleteSelectedOrders() async {
    if (_selectedRowsIds.isEmpty) {
      _showSnackBar('No orders selected');
      return;
    }

    // Check if all selected orders are "Tasks" (or user is admin/data entry)
    final selectedOrders = _allOrders
        .where((o) => _selectedRowsIds.contains(o.id))
        .toList();

    // Check if any selected order is locked
    final hasLockedOrders = selectedOrders.any((o) => _isOrderLocked(o));

    if (hasLockedOrders) {
      _showSnackBar('⚠️ Cannot delete orders with status "Done", "Task Done", "Planning", or "Master Data"');
      return;
    }

    // Check if user can delete these orders
    bool canDeleteAll = _isAdmin || _isDataEntry;

    if (!canDeleteAll) {
      // Regular users can only delete "Tasks" orders
      canDeleteAll = selectedOrders.every(
            (o) => o.status.toLowerCase() == 'tasks',
      );
    }

    if (!canDeleteAll) {
      _showSnackBar('⚠️ You can only delete Tasks orders');
      return;
    }

    // Rest of the delete logic remains the same...
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(
          'Delete Orders',
          style: GoogleFonts.cairo(fontWeight: FontWeight.w600),
        ),
        content: Text(
          'Are you sure you want to delete ${_selectedRowsIds.length} selected orders?\n\nThis action cannot be undone.',
          style: GoogleFonts.cairo(),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: Text('Cancel', style: GoogleFonts.cairo()),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: Text(
              'Delete ${_selectedRowsIds.length} orders',
              style: GoogleFonts.cairo(color: Colors.white),
            ),
          ),
        ],
      ),
    );

    if (confirm != true) return;

    setState(() => _isLoading = true);

    final supabase = Supabase.instance.client;
    int deleted = 0;
    int failed = 0;
    final deletedOrders = <Map<String, String>>[];
    final deletedIds = <String>[];

    // Delete ALL audit rows for the selected orders first.
    // Using one bulk query guarantees that every audit row whose
    // order_id matches a selected order is targeted, including orders
    // that have multiple audit records.
    final selectedOrderIds = selectedOrders
        .map((order) => order.id.trim())
        .where((id) => id.isNotEmpty)
        .toSet()
        .toList();

    if (selectedOrderIds.isNotEmpty) {
      try {
        await supabase
            .from('order_audit_log')
            .delete()
            .inFilter('order_id', selectedOrderIds);
      } catch (e) {
        print('Failed to bulk delete order audits: $e');
        setState(() => _isLoading = false);
        _showSnackBar('❌ Could not delete order audit records. Orders were not deleted.');
        return;
      }
    }

    for (var orderId in _selectedRowsIds.toList()) {
      SAPMainOrder? order;
      for (var o in _allOrders) {
        if (o.id == orderId) {
          order = o;
          break;
        }
      }

      if (order != null) {
        // Skip locked orders during deletion
        if (_isOrderLocked(order)) {
          failed++;
          continue;
        }

        try {
          // Audits for all selected orders were already deleted by the
          // bulk query above. Do NOT create an audit entry for deletion.
          // Now delete the actual order.
          // Deleting the audit rows first also prevents a foreign-key
          // constraint from blocking the order deletion, if one exists.
          await supabase
              .from('sap_main_orders')
              .delete()
              .eq('id', order.id);

          deleted++;
          deletedIds.add(order.id);
          deletedOrders.add({
            'designOrder': order.designOrder,
            'customerName': order.customerName,
          });
        } catch (e) {
          failed++;
          print('Failed to delete order ${order.id} and its audit records: $e');
        }
      }
    }

    setState(() {
      _allOrders.removeWhere((o) => deletedIds.contains(o.id));
      _orderIndexMap.removeWhere((key, value) => deletedIds.contains(key.id));
      _selectedRowsIds.clear();
      _lastSelectedOrderId = null;
      _isLoading = false;
    });

    _rebuildGroups();

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          duration: const Duration(milliseconds: 3000),
          content: Text(
            '✅ $deleted deleted, ❌ $failed failed',
            style: GoogleFonts.cairo(),
          ),
          backgroundColor: deleted > 0 ? Colors.green : Colors.red,
          behavior: SnackBarBehavior.floating,
        ),
      );
    }

    // Do not create a new audit entry for deletion.
    // All audit rows whose order_id matched a deleted order were removed above.
  }

  // A Responsible Engineer is required for manual status changes
  // UNLESS the order is ALREADY in Imported or Automated status.
  //
  // IMPORTANT:
  // We check the CURRENT/OLD status of the order, not the new status.
  // Therefore:
  //   Imported -> Drawing Submittal    = allowed without Responsible Engineer
  //   Automated -> Approval            = allowed without Responsible Engineer
  //   Tasks -> Imported                = Responsible Engineer REQUIRED
  //   Tasks -> Automated               = Responsible Engineer REQUIRED
  bool _canClearResponsibleEngineer(String currentStatus) {
    final normalized = currentStatus.trim().toLowerCase();
    return normalized == 'drawing submittal' ||
        normalized == 'imported' ||
        normalized == 'automated';
  }

  bool _statusRequiresResponsibleEngineer(String currentStatus) {
    final normalized = currentStatus.trim().toLowerCase();
    return normalized != 'imported' && normalized != 'automated';
  }

  bool _hasResponsibleEngineer(SAPMainOrder order) {
    return order.responsibleEngineer != null &&
        order.responsibleEngineer!.trim().isNotEmpty;
  }

  // Imported/Automated orders must have all SAP order details filled
  // before their status can be changed.
  bool _hasRequiredStatusChangeFields(SAPMainOrder order) {
    final item = order.itemNumber.trim();
    final productCode = order.productCode.trim();
    final contractNumber = order.contractNumber.trim();
    final description = order.description.trim();
    final designOrder = order.designOrder.trim();
    final unit = order.unitOfMeasure.trim();
    final salesEngineer = order.salesEngineer.trim();
    final orderDate = order.orderDate?.trim() ?? '';
    final endDate = order.endDate?.trim() ?? '';
    final deliveryDate = order.deliveryDate?.trim() ?? '';

    // QTY and Value must contain an actual value, not zero/empty.
    final hasQuantity = order.quantity > 0;
    final hasValue = order.value >= 0;

    return item.isNotEmpty &&
        productCode.isNotEmpty &&
        contractNumber.isNotEmpty &&
        description.isNotEmpty &&
        designOrder.isNotEmpty &&
        hasQuantity &&
        unit.isNotEmpty &&
        hasValue &&
        salesEngineer.isNotEmpty &&
        orderDate.isNotEmpty &&
        endDate.isNotEmpty &&
        deliveryDate.isNotEmpty;
  }

  String _missingRequiredStatusChangeFields(SAPMainOrder order) {
    final missing = <String>[];

    if (order.itemNumber.trim().isEmpty) missing.add('Item');
    if (order.productCode.trim().isEmpty) missing.add('Product Code');
    if (order.contractNumber.trim().isEmpty) missing.add('Contract Num');
    if (order.description.trim().isEmpty) missing.add('Description');
    if (order.designOrder.trim().isEmpty) missing.add('Design Order');
    if (order.quantity <= 0) missing.add('QTY');
    if (order.unitOfMeasure.trim().isEmpty) missing.add('Unit');
    if (order.value <= 0) missing.add('Value');
    if (order.salesEngineer.trim().isEmpty) missing.add('Sales Engineer');
    if ((order.orderDate?.trim() ?? '').isEmpty) missing.add('O-Date');
    if ((order.endDate?.trim() ?? '').isEmpty) missing.add('E-Date');
    if ((order.deliveryDate?.trim() ?? '').isEmpty) {
      missing.add('Del. Date');
    }

    return missing.join(', ');
  }

  // Update order status with audit
  Future<void> _updateOrderStatus(SAPMainOrder order, String newStatus) async {
    final oldStatus = order.status;

    // Imported and Automated rows cannot leave these statuses until
    // all required SAP columns are filled.
    final currentStatusIsImportedOrAutomated =
        oldStatus.trim().toLowerCase() == 'imported' ||
            oldStatus.trim().toLowerCase() == 'automated';

    if (currentStatusIsImportedOrAutomated &&
        !_hasRequiredStatusChangeFields(order)) {
      _showYellowWarning(
        '⚠️ Complete these fields before changing status: '
            '${_missingRequiredStatusChangeFields(order)}',
      );
      return;
    }

    final isHeader =
        order.responsibleEngineer?.trim().toLowerCase() == 'header';
    final isNoBodyDestination =
    _isNoBodyDestination(oldStatus, newStatus);

    // Only Header rows can bypass the transition/assignment rules.
    // A Header keeps Responsible Engineer = "header".
    if (!isHeader) {
      // A "(no body)" destination requires Responsible Engineer = "No One".
      if (isNoBodyDestination &&
          order.responsibleEngineer?.trim().toLowerCase() != 'no one') {
        _showYellowWarning(
          '⚠️ This status is for orders with no body. Assign Responsible Engineer to "No One" first.',
        );
        return;
      }

      // Normal status changes still require a Responsible Engineer,
      // except when the CURRENT status is Imported or Automated.
      final requiresResponsibleEngineer =
      _statusRequiresResponsibleEngineer(order.status);

      if (requiresResponsibleEngineer && !_hasResponsibleEngineer(order)) {
        _showYellowWarning(
          '⚠️ To change status to "$newStatus", you must assign a Responsible Engineer first.',
        );
        return;
      }
    }

    // Head/Manager and Data Entry users can send eligible orders to Planning.
    if (newStatus.trim().toLowerCase() == 'planning' &&
        !(_isHedOrManager || _isDataEntry) &&
        !isHeader) {
      _showYellowWarning(
        'Sorry, only Head, Manager, or Data Entry can send orders to Planning.',
      );
      return;
    }

    // Archived rows can be moved back to an active status from the combined table.
    final isCurrentlyArchived = _archivedOrderIds.contains(order.id);
    final targetIsArchived = widget.sapService.isArchivedStatus(newStatus);
    final isReturningToActive = isCurrentlyArchived && !targetIsArchived;

    // Keep archived rows locked against normal edits, but allow status changes
    // that move them back to the active table.
    if (_isOrderLocked(order) && !isReturningToActive) {
      _showYellowWarning(
        '⚠️ Cannot change status for "Done", "Task Done", "Planning", or "Master Data" orders',
      );
      return;
    }

    // Returning an archived row to an active status is an explicit transfer,
    // so it is not restricted by the normal forward-transition list.
    final allowedStatuses = _getAllowedStatusesForOrder(order);
    if (!isReturningToActive && !allowedStatuses.any(
          (s) => s.trim().toLowerCase() == newStatus.trim().toLowerCase(),
    )) {
      _showYellowWarning(
        '⚠️ "$newStatus" is not an allowed destination from "$oldStatus".',
      );
      return;
    }

    // If multiple rows are selected, validate ALL rows before updating
    // so a bulk operation does not partially move invalid rows.
    if (_selectedRowsIds.length > 1) {
      final selectedOrders = _selectedRowsIds
          .map((id) => _allOrders.where((o) => o.id == id).firstOrNull)
          .whereType<SAPMainOrder>()
          .toList();

      final invalidRequiredFields = selectedOrders.where((selectedOrder) {
        final currentStatus =
        selectedOrder.status.trim().toLowerCase();

        if (currentStatus != 'imported' && currentStatus != 'automated') {
          return false;
        }

        return !_hasRequiredStatusChangeFields(selectedOrder);
      }).toList();

      if (invalidRequiredFields.isNotEmpty) {
        final details = invalidRequiredFields
            .map((selectedOrder) {
          final missing =
          _missingRequiredStatusChangeFields(selectedOrder);
          return missing.isEmpty ? selectedOrder.designOrder : missing;
        })
            .take(3)
            .join(' | ');

        _showYellowWarning(
          '⚠️ ${invalidRequiredFields.length} Imported/Automated '
              'order(s) are missing required fields. '
              'Complete them before changing status.'
              '${details.isNotEmpty ? ' Missing: $details' : ''}',
        );
        return;
      }

      final invalidTransition = selectedOrders.where((selectedOrder) {
        final selectedIsHeader =
            selectedOrder.responsibleEngineer?.trim().toLowerCase() == 'header';

        if (selectedIsHeader) return false;

        final currentlyArchived = _archivedOrderIds.contains(selectedOrder.id);
        final targetArchived = widget.sapService.isArchivedStatus(newStatus);
        final returningToActive = currentlyArchived && !targetArchived;
        return !returningToActive && !_getAllowedStatusesForOrder(selectedOrder).any(
              (s) => s.trim().toLowerCase() == newStatus.trim().toLowerCase(),
        );
      }).toList();

      if (invalidTransition.isNotEmpty) {
        _showYellowWarning(
          '⚠️ "$newStatus" is not an allowed destination for '
              '${invalidTransition.length == 1 ? '1 selected order' : '${invalidTransition.length} selected orders'}.',
        );
        return;
      }

      final invalidNoBody = selectedOrders.where((selectedOrder) {
        final selectedIsHeader =
            selectedOrder.responsibleEngineer?.trim().toLowerCase() == 'header';

        if (selectedIsHeader) return false;

        return _isNoBodyDestination(selectedOrder.status, newStatus) &&
            selectedOrder.responsibleEngineer?.trim().toLowerCase() != 'no one';
      }).toList();

      if (invalidNoBody.isNotEmpty) {
        _showYellowWarning(
          '⚠️ There is ${invalidNoBody.length == 1 ? '1 order' : '${invalidNoBody.length} orders'} not assigned to "No One". '
              'Assign them to "No One" before sending to "$newStatus".',
        );
        return;
      }

      final invalidEngineer = selectedOrders.where((selectedOrder) {
        final selectedIsHeader =
            selectedOrder.responsibleEngineer?.trim().toLowerCase() == 'header';

        if (selectedIsHeader) return false;

        return _statusRequiresResponsibleEngineer(selectedOrder.status) &&
            !_hasResponsibleEngineer(selectedOrder);
      }).toList();

      if (invalidEngineer.isNotEmpty) {
        _showYellowWarning(
          '⚠️ There is ${invalidEngineer.length == 1 ? '1 order' : '${invalidEngineer.length} orders'} without a Responsible Engineer.',
        );
        return;
      }

      setState(() => _isLoading = true);
      final supabase = Supabase.instance.client;
      int updated = 0;
      int skipped = 0;
      final archivedIds = <String>{};

      for (final selectedOrder in selectedOrders) {
        final currentlyArchived = _archivedOrderIds.contains(selectedOrder.id);
        final targetArchived = widget.sapService.isArchivedStatus(newStatus);
        final returningToActive = currentlyArchived && !targetArchived;
        if (_isOrderLocked(selectedOrder) && !returningToActive) {
          skipped++;
          continue;
        }

        final selectedIsHeader =
            selectedOrder.responsibleEngineer?.trim().toLowerCase() == 'header';

        // Header can move anywhere allowed and remains "header".
        // No-body orders must remain assigned to No One.
        try {
          if (targetArchived) {
            if (currentlyArchived) {
              await supabase
                  .from('sap_done_orders')
                  .update({'status': newStatus})
                  .eq('id', selectedOrder.id);
            } else {
              await widget.sapService.moveOrderToDone(selectedOrder, newStatus);
            }
          } else if (currentlyArchived) {
            // Restore to active table before deleting the archived copy.
            final payload = selectedOrder.toJson()..['status'] = newStatus;
            await supabase.from('sap_main_orders').upsert(payload, onConflict: 'id');
            await supabase.from('sap_done_orders').delete().eq('id', selectedOrder.id);
          } else {
            await supabase
                .from('sap_main_orders')
                .update({'status': newStatus})
                .eq('id', selectedOrder.id);
          }

          await _auditService.logChange(
            orderId: selectedOrder.id,
            designOrder: selectedOrder.designOrder,
            fieldName: 'status',
            oldValue: selectedOrder.status,
            newValue: newStatus,
            changedBy: _currentUserName,
            changedById: _currentUserId,
            actionType: 'bulk_update',
          );

          updated++;
          if (targetArchived) {
            archivedIds.add(selectedOrder.id);
            _archivedOrderIds.add(selectedOrder.id);
          } else if (currentlyArchived) {
            _archivedOrderIds.remove(selectedOrder.id);
          }
        } catch (e) {
          print('Failed to update ${selectedOrder.id}: $e');
        }
      }

      setState(() => _isLoading = false);

      if (skipped > 0) {
        _showSnackBar(
          '✅ Status updated for $updated rows, ⚠️ $skipped locked rows skipped',
        );
      } else {
        _showSnackBar('✅ Status updated for $updated rows!');
      }

      // Both routes display a combined in-memory list. Update the local rows
      // immediately after the database transfer instead of removing archived
      // rows and waiting for a refresh to make them appear again.
      _updateMultipleOrdersLocally('status', newStatus);
      if (mounted) {
        setState(() => _clearSelection());
      }
      return;
    }

    // Single row update.
    try {
      final supabase = Supabase.instance.client;

      final isAlreadyArchived = _archivedOrderIds.contains(order.id);
      if (widget.sapService.isArchivedStatus(newStatus)) {
        if (!isAlreadyArchived) {
          await widget.sapService.moveOrderToDone(order, newStatus);
          _archivedOrderIds.add(order.id);
        } else {
          await supabase
              .from('sap_done_orders')
              .update({'status': newStatus})
              .eq('id', order.id);
        }
      } else if (isAlreadyArchived) {
        // Moving an archived order back to an active status.
        final payload = order.toJson()..['status'] = newStatus;
        await supabase.from('sap_main_orders').upsert(payload, onConflict: 'id');
        await supabase.from('sap_done_orders').delete().eq('id', order.id);
        _archivedOrderIds.remove(order.id);
      } else {
        await supabase
            .from('sap_main_orders')
            .update({'status': newStatus})
            .eq('id', order.id);
      }

      await _auditService.logChange(
        orderId: order.id,
        designOrder: order.designOrder,
        fieldName: 'status',
        oldValue: oldStatus,
        newValue: newStatus,
        changedBy: _currentUserName,
        changedById: _currentUserId,
      );

      _showSnackBar('Status updated!');
      // Keep the order in the combined table and update its group immediately.
      // The archived-ID set was updated above after the successful transfer.
      _updateOrderLocally(order.id, 'status', newStatus);
    } catch (e) {
      _showSnackBar('Error updating status: $e');
    }
  }


  // Log import action
  Future<void> _logImportAction(int recordCount) async {
    await _auditService.logChange(
      orderId: 'import_batch',
      fieldName: 'import',
      oldValue: null,
      newValue: '$recordCount records imported',
      changedBy: _currentUserName,
      changedById: _currentUserId,
      actionType: 'import',
      notes: 'Bulk import of $recordCount records',
    );
  }

  // Log delete action
  Future<void> _logDeleteAction(String orderId, String designOrder) async {
    await _auditService.logChange(
      orderId: orderId,
      designOrder: designOrder,
      fieldName: 'delete',
      oldValue: designOrder,
      newValue: null,
      changedBy: _currentUserName,
      changedById: _currentUserId,
      actionType: 'delete',
      notes: 'Order deleted',
    );
  }

  // Compare identifiers numerically when possible, so 2 sorts before 10.
  int _compareOrderIdentifiers(String? left, String? right) {
    final a = (left ?? '').trim();
    final b = (right ?? '').trim();
    final aNumber = num.tryParse(a.replaceAll(',', ''));
    final bNumber = num.tryParse(b.replaceAll(',', ''));
    if (aNumber != null && bNumber != null) {
      return aNumber.compareTo(bNumber);
    }
    return a.toLowerCase().compareTo(b.toLowerCase());
  }

  // Add this method
  void _applySorting(List<SAPMainOrder> orders) {
    switch (_sortBy) {
      case 'item_asc':
        orders.sort((a, b) {
          // Group all items under each contract, then sort items within it.
          final contractComparison = _compareOrderIdentifiers(
            a.contractNumber,
            b.contractNumber,
          );
          if (contractComparison != 0) return contractComparison;
          final itemComparison = _compareOrderIdentifiers(
            a.itemNumber,
            b.itemNumber,
          );
          if (itemComparison != 0) return itemComparison;
          // Stable, predictable tie-breaker for rows sharing contract and item.
          return _compareOrderIdentifiers(a.designOrder, b.designOrder);
        });
        break;
      case 'value_asc':
        orders.sort((a, b) => a.value.compareTo(b.value));
        break;
      case 'value_desc':
        orders.sort((a, b) => b.value.compareTo(a.value));
        break;
      case 'date_asc':
        orders.sort((a, b) {
          final aDate = a.orderDate ?? '0000-00-00';
          final bDate = b.orderDate ?? '0000-00-00';
          return aDate.compareTo(bDate);
        });
        break;
      case 'date_desc':
        orders.sort((a, b) {
          final aDate = a.orderDate ?? '0000-00-00';
          final bDate = b.orderDate ?? '0000-00-00';
          return bDate.compareTo(aDate);
        });
        break;
      default:
        break; // Keep default order
    }
  }

  String _getStatusLabel(String status) {
    if (status.length > 20) return '${status.substring(0, 18)}...';
    return status;
  }

  List<SAPMainOrder> _getFilteredOrders() {
    var result = _searchQuery.trim().isNotEmpty &&
        _searchResults != null &&
        !widget.approvalTrackingMode
        ? _searchResults!
        : _allOrders;

    if (widget.approvalTrackingMode && _approvalContractFilter != 'all') {
      result = result.where((order) {
        var contract = order.contractNumber.trim().toUpperCase();
        if (contract.startsWith('PDC')) contract = contract.substring(3).trim();
        switch (_approvalContractFilter) {
          case 'five_digits':
            return RegExp(r'^\d{5}$').hasMatch(contract);
          case '91000':
            return contract.startsWith('91000');
          case '31000':
            return contract.startsWith('31000');
          default:
            return true;
        }
      }).toList();
    }

    // Search remains a normal text search first.
    if (_searchQuery.isNotEmpty) {
      final q = _searchQuery.toLowerCase().trim();
      result = result
          .where(
            (o) =>
        o.contractNumber.toLowerCase().contains(q) ||
            o.customerName.toLowerCase().contains(q) ||
            o.designOrder.toLowerCase().contains(q) ||
            o.id.toLowerCase().contains(q) ||
            o.description.toLowerCase().contains(q),
      )
          .toList();
    }

    // Multiple filters use OR logic, NOT AND logic.
    //
    // Example:
    // Status = Approval + Factory = F01
    // means:
    // status == Approval OR factory == F01
    final activeFilterCount =
        (_filterStatus != null ? 1 : 0) +
            (_filterFactory != null ? 1 : 0) +
            (_filterDesignTeam != null ? 1 : 0) +
            (_filterSalesEngineer != null ? 1 : 0) +
            (_filterResponsibleEngineer != null ? 1 : 0) +
            (_filterReviewer != null ? 1 : 0) +
            (_filterCorrespondenceEngineer != null ? 1 : 0) +
            (_filterMyWork ? 1 : 0) +
            (_selectedWorkEmployee != null ? 1 : 0);

    if (activeFilterCount > 0) {
      final myName = widget.loggedInEmployee?.fullName ?? '';

      result = result.where((o) {
        final matchesStatus =
            _filterStatus != null && o.status == _filterStatus;

        final matchesFactory =
            _filterFactory != null && o.factory == _filterFactory;

        final matchesDesignTeam =
            _filterDesignTeam != null && o.designTeam == _filterDesignTeam;


        final matchesSalesEngineer =
            _filterSalesEngineer != null &&
                o.salesEngineer == _filterSalesEngineer;

        final matchesResponsibleEngineer =
            _filterResponsibleEngineer != null &&
                o.responsibleEngineer == _filterResponsibleEngineer;

        final matchesReviewer =
            _filterReviewer != null &&
                o.reviewer == _filterReviewer;

        final matchesCorrespondenceEngineer =
            _filterCorrespondenceEngineer != null &&
                o.correspondenceEngineer == _filterCorrespondenceEngineer;

        final matchesMyWork =
            _filterMyWork &&
                (o.responsibleEngineer == myName ||
                    o.reviewer == myName ||
                    o.correspondenceEngineer == myName);

        final selectedEmployee = _selectedWorkEmployee;
        // Each row belongs to the Alternative Engineer when assigned; otherwise
        // attribute it to the Responsible Engineer. Do not count both people.
        final alternativeEngineer = o.correspondenceEngineer?.trim() ?? '';
        final workOwner = alternativeEngineer.isNotEmpty
            ? alternativeEngineer
            : (o.responsibleEngineer?.trim() ?? '');
        final matchesSelectedEmployee = selectedEmployee != null &&
            workOwner == selectedEmployee;

        return matchesSelectedEmployee || matchesMyWork || matchesStatus ||
            matchesFactory ||
            matchesDesignTeam ||
            matchesSalesEngineer ||
            matchesResponsibleEngineer ||
            matchesReviewer ||
            matchesCorrespondenceEngineer;
      }).toList();
    }

    _applySorting(result);
    return result;
  }

  bool get _hasActiveFilters =>
      _filterStatus != null ||
          _filterFactory != null ||
          _filterDesignTeam != null ||
          _filterSalesEngineer != null ||
          _filterResponsibleEngineer != null ||
          _filterReviewer != null ||
          _filterCorrespondenceEngineer != null ||
          _filterMyWork ||
          _selectedWorkEmployee != null;

  Future<void> _showImportDialog() async {
    await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) =>
          ImportExcelDialog(onImportComplete: () => _loadAllDataOnce()),
    );
  }

  void _toggleRowSelection(SAPMainOrder order) {
    // Use the ACTUAL visible row order from _flatList.
    // The table is displayed as status sections, so _getFilteredOrders()
    // alone does not necessarily match the visual arrangement.
    final visibleOrders = _flatList.whereType<SAPMainOrder>().toList();
    final clickedIndex = visibleOrders.indexWhere((o) => o.id == order.id);

    final shiftPressed =
        HardwareKeyboard.instance.logicalKeysPressed.contains(
          LogicalKeyboardKey.shiftLeft,
        ) ||
            HardwareKeyboard.instance.logicalKeysPressed.contains(
              LogicalKeyboardKey.shiftRight,
            );

    final anchorIndex = _lastSelectedOrderId == null
        ? -1
        : visibleOrders.indexWhere(
          (o) => o.id == _lastSelectedOrderId,
    );

    setState(() {
      if (shiftPressed &&
          anchorIndex != -1 &&
          clickedIndex != -1) {
        final startIndex =
        anchorIndex < clickedIndex ? anchorIndex : clickedIndex;
        final endIndex =
        anchorIndex > clickedIndex ? anchorIndex : clickedIndex;

        // Select every row between the anchor and clicked row,
        // following exactly the order shown on screen.
        for (int i = startIndex; i <= endIndex; i++) {
          _selectedRowsIds.add(visibleOrders[i].id);
        }
      } else if (_selectedRowsIds.contains(order.id)) {
        _selectedRowsIds.remove(order.id);
      } else {
        _selectedRowsIds.add(order.id);
      }

      // The clicked row becomes the new Shift anchor.
      _lastSelectedOrderId = order.id;
    });
  }

  void _selectAllInSection(String status) {
    setState(() {
      final sectionOrders = _groupedOrders[status] ?? [];
      if (sectionOrders.isEmpty) return;
      final allSelected = sectionOrders.every(
            (o) => _selectedRowsIds.contains(o.id),
      );
      if (allSelected) {
        for (var o in sectionOrders) {
          _selectedRowsIds.remove(o.id);
        }
      } else {
        for (var o in sectionOrders) {
          _selectedRowsIds.add(o.id);
        }
      }
    });
  }

  void _clearSelection() {
    setState(() {
      _selectedRowsIds.clear();
      _lastSelectedOrderId = null;
    });
  }

  List<SAPMainOrder> _getSelectedOrders() =>
      _allOrders.where((o) => _selectedRowsIds.contains(o.id)).toList();

  Future<void> _exportSelectedOrders() async {
    if (_selectedRowsIds.isEmpty) {
      _showSnackBar('No orders selected');
      return;
    }
    final selected = _getSelectedOrders();
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(
          'Export Selected',
          style: GoogleFonts.cairo(fontWeight: FontWeight.w600),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '${selected.length} orders',
              style: GoogleFonts.cairo(
                fontSize: 14,
                color: _secondaryTextColor,
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: _buildExportOption(
                    Icons.save_alt,
                    'Save',
                    'Save to device',
                    const Color(0xFF059669),
                        () async {
                      Navigator.pop(ctx);
                      await _saveOrders(selected, 'Selected');
                    },
                  ),
                ),
              ],
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: Text('Cancel', style: GoogleFonts.cairo()),
          ),
        ],
      ),
    );
  }

  Future<void> _saveOrders(List<SAPMainOrder> orders, String prefix) async {
    try {
      if (widget.approvalTrackingMode) {
        await _exportApprovalTrackingToCsv(orders);
        return;
      }
      final path = await ExcelExportService.exportOrdersToExcel(orders);
      _showSnackBar('✅ Saved: $path');
    } catch (e) {
      _showSnackBar('Error: $e');
    }
  }

  Future<void> _exportApprovalTrackingToCsv(
      List<SAPMainOrder> orders) async {
    // Export the same approval milestone values shown in the report table.
    // CSV is Excel-compatible and avoids the regular Orders exporter, which
    // only knows about the standard SAP order columns.
    String cell(dynamic value) {
      final text = (value ?? '').toString();
      return '"${text.replaceAll('"', '""')}"';
    }

    final headers = <String>[
      'Customer',
      'Design Order',
      'Contract Number',
      'Item',
      'Product Code',
      'Description',
      'QTY',
      'Unit',
      'Value',
      'Sales Engineer',
      'Order Date',
      'End Date',
      'Delivery Date',
      'Factory',
      'Design Team',
      'Responsible Engineer',
      'Reviewer',
      'Alternative Engineer',
      'Status',
      'Created At',
      'رسم الاعتماد',
      'اعتماد البيع',
      'التعديلات - العدد',
      'التعديلات - آخر تاريخ',
      'تاريخ التشغيل',
    ];

    final rows = <List<String>>[headers];
    for (final order in orders) {
      final tracking = _approvalTrackingByOrder[order.id] ?? const {};
      rows.add([
        order.customerName,
        order.designOrder,
        order.contractNumber,
        order.itemNumber,
        order.productCode,
        order.description,
        order.quantity,
        order.unitOfMeasure,
        order.value,
        order.salesEngineer,
        order.orderDate,
        order.endDate,
        order.deliveryDate,
        order.factory,
        order.designTeam,
        order.responsibleEngineer,
        order.reviewer,
        order.correspondenceEngineer,
        order.status,
        order.createdAt == null
            ? ''
            : DateFormat('yyyy-MM-dd').format(order.createdAt!.toLocal()),
        tracking['drawing_approval_date'] ?? '',
        tracking['sales_approval_date'] ?? '',
        tracking['modifications_count'] ?? '0',
        tracking['modifications_last_date'] ?? '',
        tracking['operation_date'] ?? '',
      ].map(cell).toList());
    }

    final csv = '\uFEFF' + rows.map((row) => row.join(',')).join('\r\n');
    final blob = html.Blob([csv], 'text/csv;charset=utf-8;');
    final url = html.Url.createObjectUrlFromBlob(blob);
    final anchor = html.AnchorElement(href: url)
      ..download = 'Approval_Tracking_${DateFormat('yyyyMMdd_HHmm').format(DateTime.now())}.csv'
      ..style.display = 'none';
    html.document.body?.children.add(anchor);
    anchor.click();
    anchor.remove();
    html.Url.revokeObjectUrl(url);
    _showSnackBar('Excel-compatible file downloaded (${orders.length} orders)');
  }

  void _showSnackBar(String message) {
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          duration: const Duration(milliseconds: 3000),
          content: Text(message, style: GoogleFonts.cairo()),
          behavior: SnackBarBehavior.floating,
          backgroundColor: message.contains('Error')
              ? Colors.red
              : Colors.green,
        ),
      );
    }
  }

  void _navigateToEmployeeManagement() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const EmployeeManagementPage()),
    ).then((_) => _loadAllDataOnce());
  }

  // Navigate to OrderTrackingPage (heads, managers, and Data Entry)
  void _navigateToOrderTracking(SAPMainOrder order) {
    if (_isHedOrManager || _isDataEntry) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => OrderTrackingPage(order: order)),
      ).then((_) => _refreshAfterTracking());
    }
  }

  // Refresh the orders table after returning from Order Tracking. If the user
  // was searching, refresh the all-orders search results too; otherwise the
  // table could keep showing the pre-restore status from its search cache.
  Future<void> _refreshAfterTracking() async {
    await _loadAllDataOnce();
    if (!mounted) return;

    final query = _searchQuery.trim();
    if (query.isNotEmpty) {
      _scheduleSearchAllOrders(query);
    }
  }

  // Load factory/SLoc descriptions from Supabase.
  Future<void> _loadFactoryNames() async {
    try {
      final response = await Supabase.instance.client
          .from('factory_names')
          .select('s_loc, description');

      final descriptions = <String, String>{};
      final codes = <String, String>{};

      for (final row in response) {
        final code = row['s_loc']?.toString().trim() ?? '';
        final description = row['description']?.toString().trim() ?? '';

        if (code.isNotEmpty) {
          // Keep the factory code even when its description is empty.
          // Normalize whitespace/case so SAP values like " F001 " still match.
          descriptions[code.trim().toLowerCase()] = description.trim();
          codes[code.trim().toLowerCase()] = code.trim();
        }
      }

      if (mounted) {
        setState(() {
          _factoryDescriptions = descriptions;
          _factoryCodes = codes;
        });
      } else {
        _factoryDescriptions = descriptions;
        _factoryCodes = codes;
      }
    } catch (e) {
      print('Error loading factory names: $e');
    }
  }

  // Display factory code with its description:
  // F001 (Melamine Store.)
  // If no description exists, display only:
  // F001
  String _formatFactoryLabel(String code) {
    final trimmedCode = code.trim();
    if (trimmedCode.isEmpty) return trimmedCode;

    final normalizedCode = trimmedCode.toLowerCase();
    final description = _factoryDescriptions[normalizedCode]?.trim() ?? '';

    if (description.isEmpty) {
      return trimmedCode;
    }

    return '$trimmedCode ($description)';
  }

  // Search for a factory/SLoc by its code and apply it as the factory filter.
  Future<void> _showFactorySearchDialog() async {
    final controller = TextEditingController();
    List<Map<String, dynamic>> results = [];

    Future<void> searchFactories(StateSetter setDlg, String query) async {
      final q = query.trim().toLowerCase();

      if (q.isEmpty) {
        setDlg(() => results = []);
        return;
      }

      // Search the already-loaded factory_names data first. This makes the
      // factory search work immediately and avoids depending on a remote
      // ilike query for every keystroke.
      if (_factoryDescriptions.isEmpty) {
        await _loadFactoryNames();
      }

      final localResults = <Map<String, dynamic>>[];
      for (final entry in _factoryDescriptions.entries) {
        final code = entry.key.trim();
        final description = entry.value.trim();

        if (code.contains(q)) {
          localResults.add({
            's_loc': code,
            'description': description,
          });
        }
      }

      localResults.sort(
            (a, b) => a['s_loc'].toString().compareTo(b['s_loc'].toString()),
      );

      setDlg(() {
        results = localResults.take(100).toList();
      });
    }

    await showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDlg) {
          return AlertDialog(
            title: Row(
              children: [
                Icon(
                  Icons.factory_outlined,
                  color: Theme.of(context).colorScheme.primary,
                  size: 22,
                ),
                const SizedBox(width: 8),
                Text(
                  'Search Factory',
                  style: GoogleFonts.cairo(
                    fontWeight: FontWeight.w600,
                    fontSize: 18,
                  ),
                ),
              ],
            ),
            content: SizedBox(
              width: 480,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextField(
                    controller: controller,
                    autofocus: true,
                    style: GoogleFonts.cairo(fontSize: 13),
                    decoration: InputDecoration(
                      labelText: 'Factory Code',
                      hintText: 'e.g. F001, R001, SB01',
                      prefixIcon: const Icon(Icons.search, size: 20),
                      suffixIcon: controller.text.isNotEmpty
                          ? IconButton(
                        icon: const Icon(Icons.clear, size: 18),
                        onPressed: () {
                          controller.clear();
                          setDlg(() => results = []);
                        },
                      )
                          : null,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                    onChanged: (value) {
                      setDlg(() {});
                      searchFactories(setDlg, value);
                    },
                    onSubmitted: (value) {
                      searchFactories(setDlg, value);
                    },
                  ),
                  const SizedBox(height: 12),
                  if (results.isNotEmpty)
                    ConstrainedBox(
                      constraints: const BoxConstraints(maxHeight: 320),
                      child: ListView.separated(
                        shrinkWrap: true,
                        itemCount: results.length,
                        separatorBuilder: (_, __) =>
                            Divider(color: _borderColor, height: 1),
                        itemBuilder: (context, index) {
                          final row = results[index];
                          final code = row['s_loc']?.toString().trim() ?? '';
                          final description =
                              row['description']?.toString().trim() ?? '';

                          return ListTile(
                            dense: true,
                            leading: Icon(
                              Icons.factory_outlined,
                              size: 19,
                              color: _secondaryTextColor,
                            ),
                            title: Text(
                              code,
                              style: GoogleFonts.cairo(
                                fontSize: 13,
                                fontWeight: FontWeight.w700,
                                color: _textColor,
                              ),
                            ),
                            subtitle: description.isNotEmpty
                                ? Text(
                              description,
                              style: GoogleFonts.cairo(
                                fontSize: 11,
                                color: _secondaryTextColor,
                              ),
                            )
                                : null,
                          );
                        },
                      ),
                    )
                  else if (controller.text.trim().isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.all(16),
                      child: Text(
                        'No factory found',
                        style: GoogleFonts.cairo(
                          fontSize: 12,
                          color: _secondaryTextColor,
                        ),
                      ),
                    )
                  else
                    Padding(
                      padding: const EdgeInsets.all(16),
                      child: Text(
                        'Enter a factory code to search',
                        style: GoogleFonts.cairo(
                          fontSize: 12,
                          color: _secondaryTextColor,
                        ),
                      ),
                    ),
                ],
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: Text(
                  'Close',
                  style: GoogleFonts.cairo(),
                ),
              ),
            ],
          );
        },
      ),
    );

    controller.dispose();
  }

  void _showFilterDialog() {
    String? tempStatus = _filterStatus;
    String? tempFactory = _filterFactory;
    String? tempSalesEngineer = _filterSalesEngineer;
    String? tempResponsibleEngineer = _filterResponsibleEngineer;
    String? tempReviewer = _filterReviewer;
    String? tempCorrespondenceEngineer = _filterCorrespondenceEngineer;

    // Get unique values from data
    final factories = <String>{};
    final salesEngineers = <String>{};
    final responsibleEngineers = <String>{};
    final reviewers = <String>{};
    final correspondenceEngineers = <String>{};

    for (var order in _allOrders) {
      if (order.factory != null && order.factory!.isNotEmpty)
        factories.add(order.factory!);
      if (order.salesEngineer.isNotEmpty)
        salesEngineers.add(order.salesEngineer);
      if (order.responsibleEngineer != null &&
          order.responsibleEngineer!.isNotEmpty)
        responsibleEngineers.add(order.responsibleEngineer!);
      if (order.reviewer != null && order.reviewer!.isNotEmpty)
        reviewers.add(order.reviewer!);
      if (order.correspondenceEngineer != null &&
          order.correspondenceEngineer!.isNotEmpty)
        correspondenceEngineers.add(order.correspondenceEngineer!);
    }

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDlg) => AlertDialog(
          title: Row(
            children: [
              Icon(Icons.filter_list, color: Theme.of(context).colorScheme.primary, size: 22),
              const SizedBox(width: 8),
              Text(
                'Filter Orders',
                style: GoogleFonts.cairo(
                  fontWeight: FontWeight.w600,
                  fontSize: 18,
                ),
              ),
              const Spacer(),
              if (tempStatus != null ||
                  tempFactory != null ||
                  tempSalesEngineer != null ||
                  tempResponsibleEngineer != null ||
                  tempReviewer != null ||
                  tempCorrespondenceEngineer != null)
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 3,
                  ),
                  decoration: BoxDecoration(
                    color: const Color(0xFF6366F1).withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    'Active',
                    style: GoogleFonts.cairo(
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      color: const Color(0xFF6366F1),
                    ),
                  ),
                ),
            ],
          ),
          content: SizedBox(
            width: 500,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // ===== STATUS & DEPARTMENT =====
                  _buildFilterSection(
                    '📊 Status & Department',
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: _buildFilterDropdown(
                              'Status',
                              tempStatus,
                              ['All', ..._allStatuses],
                                  (v) => setDlg(() => tempStatus = v),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: _buildFilterDropdown(
                              'Factory (${factories.length})',
                              tempFactory,
                              [
                                'All',
                                ...factories.toList()..sort(),
                              ],
                                  (v) => setDlg(() => tempFactory = v),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),

                  // ===== ENGINEERS =====
                  _buildFilterSection(
                    '👨‍💼 Employee',
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: _buildFilterDropdown(
                              'Sales Eng. (${salesEngineers.length})',
                              tempSalesEngineer,
                              ['All', ...salesEngineers.toList()..sort()],
                                  (v) => setDlg(() => tempSalesEngineer = v),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: _buildFilterDropdown(
                              'Resp. Eng. (${responsibleEngineers.length})',
                              tempResponsibleEngineer,
                              ['All', ...responsibleEngineers.toList()..sort()],
                                  (v) => setDlg(() => tempResponsibleEngineer = v),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          Expanded(
                            child: _buildFilterDropdown(
                              'Reviewer (${reviewers.length})',
                              tempReviewer,
                              ['All', ...reviewers.toList()..sort()],
                                  (v) => setDlg(() => tempReviewer = v),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: _buildFilterDropdown(
                              'Alt. Eng. (${correspondenceEngineers.length})',
                              tempCorrespondenceEngineer,
                              [
                                'All',
                                ...correspondenceEngineers.toList()..sort(),
                              ],
                                  (v) =>
                                  setDlg(() => tempCorrespondenceEngineer = v),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          actions: [
            Row(
              children: [
                TextButton(
                  onPressed: () {
                    setDlg(() {
                      tempStatus = null;
                      tempFactory = null;
                      tempSalesEngineer = null;
                      tempResponsibleEngineer = null;
                      tempReviewer = null;
                      tempCorrespondenceEngineer = null;
                    });
                  },
                  child: Row(
                    children: [
                      const Icon(Icons.clear_all, size: 16, color: Colors.red),
                      const SizedBox(width: 4),
                      Text(
                        'Clear All',
                        style: GoogleFonts.cairo(
                          color: Colors.red,
                          fontSize: 13,
                        ),
                      ),
                    ],
                  ),
                ),
                const Spacer(),
                TextButton(
                  onPressed: () => Navigator.pop(ctx),
                  child: Text('Cancel', style: GoogleFonts.cairo(fontSize: 13)),
                ),
                const SizedBox(width: 8),
                ElevatedButton.icon(
                  onPressed: () {
                    setState(() {
                      _filterStatus = tempStatus;
                      _filterFactory = tempFactory;
                      _filterSalesEngineer = tempSalesEngineer;
                      _filterResponsibleEngineer = tempResponsibleEngineer;
                      _filterReviewer = tempReviewer;
                      _filterCorrespondenceEngineer =
                          tempCorrespondenceEngineer;
                    });
                    _rebuildGroups();
                    Navigator.pop(ctx);
                  },
                  icon: const Icon(Icons.check, size: 18),
                  label: Text(
                    'Apply Filters',
                    style: GoogleFonts.cairo(
                      fontWeight: FontWeight.w600,
                      fontSize: 13,
                    ),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Theme.of(context).colorScheme.primary,
                    foregroundColor: Theme.of(context).colorScheme.onPrimary,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 10,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // Helper widget for filter sections
  Widget _buildFilterSection(String title, {required List<Widget> children}) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _hoverColor,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: _borderColor),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: GoogleFonts.cairo(
              fontSize: 13,
              fontWeight: FontWeight.w700,
              color: _textColor,
            ),
          ),
          const SizedBox(height: 10),
          ...children,
        ],
      ),
    );
  }

  // Filter dialog dropdowns use the same compact style as the app-bar dropdowns.
  Widget _buildFilterDropdown(
      String label,
      String? value,
      List<String> items,
      Function(String?) onChanged,
      ) {
    final hasValue = value != null && value.isNotEmpty;
    final displayValue = hasValue
        ? (label.startsWith('Factory ')
        ? _formatFactoryLabel(value!)
        : value!)
        : 'All';

    return SizedBox(
      height: 38,
      child: Material(
        color: _surfaceColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(7),
          side: BorderSide(color: _borderColor),
        ),
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: () => _showSearchableFilterPicker(
            label: label,
            value: value,
            items: items,
            onChanged: onChanged,
          ),
          child: Padding(
            padding: EdgeInsets.symmetric(
              horizontal: 10,
              vertical: 3,
            ),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        label,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: GoogleFonts.cairo(
                          fontSize: 9,
                          fontWeight: FontWeight.normal,
                          height: 1,
                          color: _secondaryTextColor,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        displayValue,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: GoogleFonts.cairo(
                          fontSize: 11,
                          fontWeight: FontWeight.normal,
                          height: 1,
                          color: hasValue ? _textColor : _secondaryTextColor,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 6),
                Icon(
                  Icons.search,
                  size: 16,
                  color: hasValue
                      ? const Color(0xFF6366F1)
                      : _secondaryTextColor,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _showSearchableFilterPicker({
    required String label,
    required String? value,
    required List<String> items,
    required Function(String?) onChanged,
  }) async {
    final searchController = TextEditingController();
    final uniqueItems = <String>[];

    for (final item in items) {
      if (!uniqueItems.contains(item)) {
        uniqueItems.add(item);
      }
    }

    final result = await showDialog<String>(
      context: context,
      builder: (dialogContext) {
        String query = '';

        return StatefulBuilder(
          builder: (context, setDialogState) {
            final filteredItems = uniqueItems.where((item) {
              if (query.trim().isEmpty) return true;

              final searchText = query.toLowerCase().trim();
              final displayText = item == 'All'
                  ? 'All'
                  : label.startsWith('Factory ')
                  ? _formatFactoryLabel(item)
                  : item;

              return displayText.toLowerCase().contains(searchText);
            }).toList();

            return AlertDialog(
              titlePadding: const EdgeInsets.fromLTRB(20, 18, 20, 8),
              contentPadding: const EdgeInsets.fromLTRB(20, 8, 20, 16),
              title: Row(
                children: [
                  const Icon(Icons.search, size: 20),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Search $label',
                      style: GoogleFonts.cairo(
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ],
              ),
              content: SizedBox(
                width: 430,
                height: 460,
                child: Column(
                  children: [
                    TextField(
                      controller: searchController,
                      autofocus: true,
                      onChanged: (v) {
                        setDialogState(() => query = v);
                      },
                      style: GoogleFonts.cairo(fontSize: 13),
                      decoration: InputDecoration(
                        hintText: 'Type to search...',
                        hintStyle: GoogleFonts.cairo(
                          fontSize: 12,
                          color: _secondaryTextColor,
                        ),
                        prefixIcon: const Icon(Icons.search, size: 19),
                        suffixIcon: searchController.text.isNotEmpty
                            ? IconButton(
                          icon: const Icon(Icons.clear, size: 18),
                          onPressed: () {
                            searchController.clear();
                            setDialogState(() => query = '');
                          },
                        )
                            : null,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 10,
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    Expanded(
                      child: filteredItems.isEmpty
                          ? Center(
                        child: Text(
                          'No results found',
                          style: GoogleFonts.cairo(
                            fontSize: 13,
                            color: _secondaryTextColor,
                          ),
                        ),
                      )
                          : ListView.builder(
                        itemCount: filteredItems.length,
                        itemBuilder: (_, index) {
                          final item = filteredItems[index];
                          final isAll = item == 'All';
                          final selected =
                              (isAll && value == null) ||
                                  (!isAll && item == value);

                          final displayText = isAll
                              ? 'All'
                              : label.startsWith('Factory ')
                              ? _formatFactoryLabel(item)
                              : item;

                          return ListTile(
                            dense: true,
                            selected: selected,
                            leading: Icon(
                              isAll
                                  ? Icons.select_all
                                  : Icons.circle_outlined,
                              size: 18,
                              color: selected
                                  ? const Color(0xFF6366F1)
                                  : _secondaryTextColor,
                            ),
                            title: Text(
                              displayText,
                              style: GoogleFonts.cairo(
                                fontSize: 12,
                                fontWeight: selected
                                    ? FontWeight.w700
                                    : FontWeight.w400,
                                color: selected
                                    ? const Color(0xFF6366F1)
                                    : _textColor,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                            trailing: selected
                                ? const Icon(
                              Icons.check,
                              size: 18,
                              color: Color(0xFF6366F1),
                            )
                                : null,
                            onTap: () {
                              // Empty string is our internal "All"
                              // result. Null means the dialog was
                              // dismissed without changing anything.
                              Navigator.pop(
                                dialogContext,
                                isAll ? '' : item,
                              );
                            },
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );

    searchController.dispose();

    if (result != null) {
      onChanged(result.isEmpty ? null : result);
    }
  }

  // ==================== BUILD ====================
  @override
  Widget build(BuildContext context) {
    return CallbackShortcuts(
      bindings: {
        const SingleActivator(LogicalKeyboardKey.escape): _clearSelection,
      },
      child: Focus(
        child: LayoutBuilder(
          builder: (context, constraints) {
            // Mobile gets a purpose-built card interface; desktop keeps the
            // existing data-dense table and its full toolbar.
            if (constraints.maxWidth < 700) {
              return _buildMobileOrdersPage();
            }
            return Column(
              children: [
                _buildTopBar(),
                Expanded(
                  child: Container(
                    padding: const EdgeInsets.all(18),
                    color: _backgroundColor,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(height: 8),
                        if (_selectedRowsIds.isNotEmpty) _buildSelectionToolbar(),
                        Expanded(
                          child: Column(
                            children: [
                              Expanded(child: _buildTableContainer()),
                              const SizedBox(height: 10),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _buildMobileOrdersPage() {
    final primary = Theme.of(context).colorScheme.primary;
    final isAdmin = _isAdmin;
    return ColoredBox(
      color: _backgroundColor,
      child: SafeArea(
        child: Column(
          children: [
            // App-like compact header with quick actions and live search.
            Container(
              padding: const EdgeInsets.fromLTRB(16, 12, 12, 12),
              decoration: BoxDecoration(
                color: _surfaceColor,
                border: Border(bottom: BorderSide(color: _borderColor)),
              ),
              child: Column(
                children: [
                  Row(children: [
                    Container(
                      width: 80,
                      height: 80,
                      padding: const EdgeInsets.all(3),
                      decoration: BoxDecoration(
                        color: _surfaceColor,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: _borderColor),
                      ),
                      child: Image.asset(
                        'assets/images/logo.png',
                        fit: BoxFit.contain,
                        errorBuilder: (_, __, ___) => Icon(
                          Icons.receipt_long_rounded,
                          color: primary,
                          size: 30,
                        ),
                      ),
                    ),
                    const SizedBox(width: 14),
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(widget.approvalTrackingMode ? 'Approval Tracking' : (widget.doneOrdersOnly ? 'Done Orders' : 'Orders'), style: GoogleFonts.cairo(fontSize: 24, height: 1.15, fontWeight: FontWeight.w800, color: _textColor)),
                      Text('${_getFilteredOrders().length} orders${_selectedRowsIds.isNotEmpty ? ' • ${_selectedRowsIds.length} selected' : ''}', style: GoogleFonts.cairo(fontSize: 13, color: _secondaryTextColor)),
                    ])),
                    if (widget.approvalTrackingMode) ...[
                      IconButton(
                        tooltip: 'Back',
                        onPressed: () => Navigator.of(context).maybePop(),
                        icon: const Icon(Icons.arrow_back),
                        color: _textColor,
                        visualDensity: VisualDensity.compact,
                      ),
                      IconButton(
                        tooltip: 'Download Excel',
                        onPressed: () => _saveOrders(_getFilteredOrders(), 'Approval Tracking'),
                        icon: const Icon(Icons.file_download_outlined),
                        color: _textColor,
                        visualDensity: VisualDensity.compact,
                      ),
                    ] else ...[
                      if (!widget.readOnly)
                        IconButton(tooltip: 'Add task', onPressed: _showAddTaskDialog, icon: Icon(Icons.add_circle_outline_rounded, color: primary,size: 32,)),
                      PopupMenuButton<String>(
                        icon: Icon(Icons.more_vert, color: _textColor, size: 32),
                        onSelected: (value) {
                          switch (value) {
                            case 'edit': setState(() => _editMode = !_editMode); break;
                            case 'arrange': _showStatusArrangementDialog(); break;
                            case 'factories': _showFactorySearchDialog(); break;
                            case 'employees': _navigateToEmployeeManagement(); break;
                            case 'import': _showImportDialog(); break;
                            case 'export': if (_allOrders.isNotEmpty) _saveOrders(_allOrders, 'Orders'); break;
                            case 'approval_tracking':
                              Navigator.of(context).push(MaterialPageRoute(
                                builder: (_) => ApprovalTrackingPage(
                                  sapService: widget.sapService,
                                  loggedInEmployee: widget.loggedInEmployee,
                                ),
                              ));
                              break;
                            case 'clear': _clearSelection(); break;
                          }
                        },
                        itemBuilder: (_) => [
                          if (!widget.readOnly) PopupMenuItem(value: 'edit', child: Text(_editMode ? 'Turn edit mode off' : 'Turn edit mode on')),
                          const PopupMenuItem(value: 'arrange', child: Text('Arrange statuses')),
                          if (_isHedOrManager && !widget.approvalTrackingMode)
                            const PopupMenuItem(value: 'approval_tracking', child: Text('Approval Tracking')),
                          const PopupMenuItem(value: 'factories', child: Text('Factories')),
                          if (isAdmin) const PopupMenuItem(value: 'employees', child: Text('Employees')),
                          if (_canImportDelete) const PopupMenuItem(value: 'import', child: Text('Import orders')),
                          const PopupMenuItem(value: 'export', child: Text('Export orders')),
                          if (_selectedRowsIds.isNotEmpty) const PopupMenuItem(value: 'clear', child: Text('Clear selection')),
                        ],
                      ),
                    ]
                  ]),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _searchController,
                    focusNode: _searchFocusNode,
                    onChanged: (value) { setState(() => _searchQuery = value); _scheduleSearchAllOrders(value); _rebuildGroups(); },
                    style: GoogleFonts.cairo(fontSize: 24, color: _textColor),
                    decoration: InputDecoration(
                      hintText: widget.approvalTrackingMode ? 'Search by Order ID / Design Order…' : 'Search orders, customers, codes…',
                      hintStyle: GoogleFonts.cairo(fontSize: 20, color: _secondaryTextColor,),
                      prefixIcon: const Icon(Icons.search_rounded,size: 28),
                      suffixIcon: _searchController.text.isNotEmpty ? IconButton(icon: const Icon(Icons.close), onPressed: () { _searchController.clear(); setState(() => _searchQuery = ''); _scheduleSearchAllOrders(''); _rebuildGroups(); }) : null,
                      filled: true, fillColor: _backgroundColor,
                      contentPadding: const EdgeInsets.symmetric(vertical: 14),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide(color: _borderColor)),
                      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide(color: _borderColor)),
                    ),
                  ),
                  const SizedBox(height: 10),
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(children: [
                      if (widget.approvalTrackingMode) ...[
                        _buildApprovalContractFilter(),
                        const SizedBox(width: 8),
                      ],
                      _mobileToolChip(Icons.filter_list_rounded, 'Filters', _showFilterDialog),
                      const SizedBox(width: 8),
                      _mobileToolChip(Icons.sort_rounded, _getSortLabel(), () => _showMobileSortMenu()),
                      if (!widget.approvalTrackingMode && !widget.readOnly && (_isHeadRole || _isManagerRole)) ...[
                        const SizedBox(width: 8),
                        _buildEmployeeWorkDropdown(isMobile: true),
                      ],
                      if (!widget.readOnly && (_isEngineerRole || _isManagerRole)) ...[
                        const SizedBox(width: 8),
                        _buildMyWorkButton(isMobile: true),
                      ],
                      const SizedBox(width: 8),
                      _buildDesignTeamFilterButton(isMobile: true),
                    ]),
                  ),
                  if (_editMode) Padding(padding: const EdgeInsets.only(top: 8), child: Row(children: [Icon(Icons.edit_note, size: 17, color: Colors.orange), const SizedBox(width: 6), Text('Edit mode is on', style: GoogleFonts.cairo(fontSize: 11, color: Colors.orange, fontWeight: FontWeight.w700))])),
                ],
              ),
            ),
            if (_selectedRowsIds.isNotEmpty)
              Container(width: double.infinity, padding: const EdgeInsets.fromLTRB(12, 8, 12, 4), child: SingleChildScrollView(scrollDirection: Axis.horizontal, child: _buildSelectionToolbar())),
            Expanded(child: _buildMobileOrderList()),
          ],
        ),
      ),
    );
  }

  Widget _mobileToolChip(IconData icon, String label, VoidCallback onTap) =>
      InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Container(
          height: 50,
          padding: const EdgeInsets.symmetric(horizontal: 14),
          decoration: BoxDecoration(color: _surfaceColor, border: Border.all(color: _borderColor), borderRadius: BorderRadius.circular(13)),
          child: Row(mainAxisSize: MainAxisSize.min, children: [Icon(icon, size: 24, color: _secondaryTextColor), const SizedBox(width: 8), Text(label, style: GoogleFonts.cairo(fontSize: 15, fontWeight: FontWeight.w700, color: _textColor))]),
        ),
      );

  void _showMobileSortMenu() {
    showModalBottomSheet<void>(
      context: context, backgroundColor: _surfaceColor, showDragHandle: true,
      builder: (sheetContext) => SafeArea(child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 20),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Sort orders', style: GoogleFonts.cairo(fontSize: 18, fontWeight: FontWeight.w800, color: _textColor)),
          const SizedBox(height: 8),
          for (final option in <MapEntry<String, String>>[
            const MapEntry('default', 'Default order'), const MapEntry('date_asc', 'Date: oldest first'), const MapEntry('date_desc', 'Date: newest first'), const MapEntry('value_asc', 'Value: low to high'), const MapEntry('value_desc', 'Value: high to low'), const MapEntry('item_asc', 'Contract then Item: low to high'),
          ]) ListTile(dense: true, title: Text(option.value, style: GoogleFonts.cairo(color: _textColor)), trailing: _sortBy == option.key ? Icon(Icons.check_circle, color: Theme.of(context).colorScheme.primary) : null, onTap: () { setState(() => _sortBy = option.key); _rebuildGroups(); Navigator.pop(sheetContext); }),
        ]),
      )),
    );
  }

  Widget _buildMobileOrderList() {
    if (_isLoading && !_initialLoadDone) {
      return Center(
        child: CircularProgressIndicator(
          color: Theme.of(context).colorScheme.primary,
        ),
      );
    }

    // Reuse the already-computed flat workflow list. Building all cards inside
    // a Column when a status expands caused a large frame drop for busy stages.
    final filteredOrders = _getFilteredOrders();
    if (_allOrders.isEmpty || filteredOrders.isEmpty) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.inbox_rounded,
              size: 44,
              color: _secondaryTextColor.withOpacity(.6),
            ),
            const SizedBox(height: 10),
            Text(
              _allOrders.isEmpty ? 'No orders yet' : 'No matching orders',
              style: GoogleFonts.cairo(
                color: _secondaryTextColor,
                fontSize: 14,
              ),
            ),
            if (_searchQuery.isNotEmpty)
              TextButton(
                onPressed: () {
                  _searchController.clear();
                  setState(() => _searchQuery = '');
                  _rebuildGroups();
                },
                child: const Text('Clear search'),
              ),
          ],
        ),
      );
    }

    // _flatList contains only the status headers and orders belonging to
    // expanded sections. ListView.builder now creates cards on demand, instead
    // of building every order in a large status at once.
    return RefreshIndicator(
      onRefresh: _loadAllDataOnce,
      child: ListView.builder(
        key: const PageStorageKey<String>('mobile-orders-flat-list'),
        padding: const EdgeInsets.fromLTRB(12, 12, 12, 28),
        itemCount: _flatList.length,
        itemBuilder: (context, index) {
          final item = _flatList[index];

          if (item is SAPMainOrder) {
            return _buildMobileOrderCard(item);
          }

          final status = item.toString();
          final orders = _groupedOrders[status] ?? const <SAPMainOrder>[];
          final expanded = _expandedSections.contains(status);
          final statusColor = _getStatusColor(status);

          return Container(
            key: ValueKey<String>('mobile-status-$status'),
            margin: const EdgeInsets.only(bottom: 10),
            decoration: BoxDecoration(
              color: _surfaceColor,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: _borderColor),
            ),
            clipBehavior: Clip.antiAlias,
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                onTap: () => _toggleSection(status),
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 14,
                    vertical: 12,
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 4,
                        height: 38,
                        decoration: BoxDecoration(
                          color: statusColor,
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Container(
                        width: 36,
                        height: 36,
                        decoration: BoxDecoration(
                          color: statusColor.withOpacity(.10),
                          borderRadius: BorderRadius.circular(11),
                        ),
                        child: Icon(
                          Icons.view_kanban_rounded,
                          size: 18,
                          color: statusColor,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              status,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: GoogleFonts.cairo(
                                fontSize: 13,
                                fontWeight: FontWeight.w800,
                                color: _textColor,
                              ),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              expanded ? 'Tap to collapse' : 'Tap to view orders',
                              style: GoogleFonts.cairo(
                                fontSize: 10,
                                color: _secondaryTextColor,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 10,
                          vertical: 6,
                        ),
                        decoration: BoxDecoration(
                          color: statusColor.withOpacity(.10),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Text(
                          '${orders.length}',
                          style: GoogleFonts.cairo(
                            fontSize: 11,
                            fontWeight: FontWeight.w800,
                            color: statusColor,
                          ),
                        ),
                      ),
                      const SizedBox(width: 5),
                      Icon(
                        expanded
                            ? Icons.keyboard_arrow_up_rounded
                            : Icons.keyboard_arrow_down_rounded,
                        color: _secondaryTextColor,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  String? _mobileFieldValue(SAPMainOrder order, String field) {
    switch (field) {
      case 'status': return order.status;
      case 'design_order': return order.designOrder;
      case 'contract_number': return order.contractNumber;
      case 'item_number': return order.itemNumber;
      case 'product_code': return order.productCode;
      case 'description': return order.description;
      case 'quantity': return order.quantity.toString();
      case 'value': return order.value.toString();
      case 'order_date': return order.orderDate;
      case 'delivery_date': return order.deliveryDate;
      case 'factory': return order.factory;
      case 'design_team': return order.designTeam;
      case 'responsible_engineer': return order.responsibleEngineer;
      case 'reviewer': return order.reviewer;
      case 'correspondence_engineer': return order.correspondenceEngineer;
      default: return _getCurrentFieldValue(order, field);
    }
  }

  Future<void> _showMobileEditMenu(SAPMainOrder order) async {
    final fields = <MapEntry<String, String>>[
      const MapEntry('design_order', 'Design order'),
      const MapEntry('contract_number', 'Contract number'),
      const MapEntry('item_number', 'Item'),
      const MapEntry('product_code', 'Product code'),
      const MapEntry('description', 'Description'),
      const MapEntry('quantity', 'Quantity'),
      const MapEntry('value', 'Value'),
      const MapEntry('order_date', 'Order date'),
      const MapEntry('delivery_date', 'Delivery date'),
      const MapEntry('factory', 'Factory'),
      const MapEntry('design_team', 'Design team'),
      const MapEntry('responsible_engineer', 'Responsible engineer'),
      const MapEntry('reviewer', 'Reviewer'),
      const MapEntry('correspondence_engineer', 'Alternative engineer'),
    ];
    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: _surfaceColor,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (sheetContext) => SafeArea(
        child: SizedBox(
          height: MediaQuery.of(sheetContext).size.height * .72,
          child: Column(children: [
            Padding(padding: const EdgeInsets.fromLTRB(20, 4, 20, 12), child: Row(children: [
              Expanded(child: Text('Edit order', style: GoogleFonts.cairo(fontSize: 18, fontWeight: FontWeight.w800, color: _textColor))),
              IconButton(onPressed: () => Navigator.pop(sheetContext), icon: Icon(Icons.close, color: _secondaryTextColor)),
            ])),
            Expanded(child: ListView.separated(
              itemCount: fields.length,
              separatorBuilder: (_, __) => Divider(height: 1, color: _borderColor),
              itemBuilder: (context, index) {
                final field = fields[index];
                final current = _mobileFieldValue(order, field.key) ?? '';
                return ListTile(
                  leading: Icon(Icons.edit_outlined, color: Theme.of(context).colorScheme.primary),
                  title: Text(field.value, style: GoogleFonts.cairo(fontSize: 13, fontWeight: FontWeight.w600, color: _textColor)),
                  subtitle: Text(current.isEmpty ? 'Not set' : current, maxLines: 1, overflow: TextOverflow.ellipsis, style: GoogleFonts.cairo(fontSize: 11, color: _secondaryTextColor)),
                  trailing: Icon(Icons.chevron_right, color: _secondaryTextColor),
                  onTap: () {
                    Navigator.pop(sheetContext);
                    if (field.key == 'order_date' || field.key == 'delivery_date') {
                      _pickDateForEdit(order, field.key, current.isEmpty ? '-' : current);
                    } else {
                      _editOrderField(order, field.key, current.isEmpty ? '-' : current);
                    }
                  },
                );
              },
            )),
          ]),
        ),
      ),
    );
  }

  Future<void> _showMobileStatusPicker(SAPMainOrder order) async {
    final currentStatus = order.status;
    final archived = _archivedOrderIds.contains(order.id);
    final locked = _isOrderLocked(order) && !(widget.doneOrdersOnly && archived);
    final allowedStatuses = _getAllowedStatusesForOrder(order);

    if (widget.readOnly) return;
    if (locked) {
      _showYellowWarning('This order is locked and its status cannot be changed.');
      return;
    }

    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: _surfaceColor,
      isScrollControlled: true,
      showDragHandle: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(26)),
      ),
      builder: (sheetContext) => SafeArea(
        child: SizedBox(
          height: MediaQuery.of(sheetContext).size.height * .68,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 4, 20, 14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Change order status', style: GoogleFonts.cairo(fontSize: 19, fontWeight: FontWeight.w800, color: _textColor)),
                    const SizedBox(height: 4),
                    Text('${order.designOrder}  •  ${order.customerName}', maxLines: 2, overflow: TextOverflow.ellipsis, style: GoogleFonts.cairo(fontSize: 11, color: _secondaryTextColor)),
                    const SizedBox(height: 12),
                    Row(children: [
                      Text('CURRENT', style: GoogleFonts.cairo(fontSize: 9, letterSpacing: 1, fontWeight: FontWeight.w800, color: _secondaryTextColor)),
                      const SizedBox(width: 8),
                      Flexible(child: Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5), decoration: BoxDecoration(color: _getStatusColor(currentStatus).withOpacity(.12), borderRadius: BorderRadius.circular(9)), child: Text(currentStatus, maxLines: 1, overflow: TextOverflow.ellipsis, style: GoogleFonts.cairo(fontSize: 11, fontWeight: FontWeight.w700, color: _getStatusColor(currentStatus))))),
                    ]),
                  ],
                ),
              ),
              Divider(height: 1, color: _borderColor),
              Expanded(
                child: allowedStatuses.isEmpty
                    ? Center(child: Text('No available status changes', style: GoogleFonts.cairo(color: _secondaryTextColor)))
                    : ListView.separated(
                  padding: const EdgeInsets.fromLTRB(14, 10, 14, 20),
                  itemCount: allowedStatuses.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 5),
                  itemBuilder: (context, index) {
                    final status = allowedStatuses[index];
                    final isCurrent = status.trim().toLowerCase() == currentStatus.trim().toLowerCase();
                    final color = _getStatusColor(status);
                    return Material(
                      color: isCurrent ? color.withOpacity(.10) : Colors.transparent,
                      borderRadius: BorderRadius.circular(13),
                      child: InkWell(
                        borderRadius: BorderRadius.circular(13),
                        onTap: isCurrent ? null : () {
                          Navigator.pop(sheetContext);
                          _updateOrderStatus(order, status);
                        },
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                          child: Row(children: [
                            Container(width: 10, height: 10, decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
                            const SizedBox(width: 12),
                            Expanded(child: Text(status, style: GoogleFonts.cairo(fontSize: 12, fontWeight: isCurrent ? FontWeight.w800 : FontWeight.w600, color: isCurrent ? color : _textColor))),
                            if (isCurrent) Icon(Icons.check_circle_rounded, size: 19, color: color)
                            else Icon(Icons.chevron_right_rounded, size: 19, color: _secondaryTextColor),
                          ]),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildMobileOrderCard(SAPMainOrder order) {
    final selected = _selectedRowsIds.contains(order.id);
    final statusColor = _getStatusColor(order.status);
    final canEdit = _isOrderEditable(order);
    String valueText;
    try { valueText = _formatNumber(order.value); } catch (_) { valueText = order.value.toString(); }
    Widget detail(IconData icon, String label, String value) => Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(icon, size: 15, color: _secondaryTextColor), const SizedBox(width: 7), Expanded(child: RichText(text: TextSpan(style: GoogleFonts.cairo(fontSize: 11, color: _secondaryTextColor), children: [TextSpan(text: '$label  ', style: const TextStyle(fontWeight: FontWeight.w700)), TextSpan(text: value.trim().isEmpty ? '—' : value, style: TextStyle(color: _textColor))])))]);
    return Container(
      margin: const EdgeInsets.fromLTRB(10, 0, 10, 10),
      decoration: BoxDecoration(color: selected ? const Color(0xFF6366F1).withOpacity(.08) : _surfaceColor, borderRadius: BorderRadius.circular(19), border: Border.all(color: selected ? const Color(0xFF6366F1) : _borderColor.withOpacity(.85), width: selected ? 1.5 : 1), boxShadow: [BoxShadow(color: Colors.black.withOpacity(_isDarkMode ? .10 : .035), blurRadius: 14, offset: const Offset(0, 4))]),
      child: InkWell(
        borderRadius: BorderRadius.circular(19),
        onTap: () => _toggleRowSelection(order),
        onLongPress: () => _copyOrderData(order),
        child: Padding(padding: const EdgeInsets.all(13), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            if (!widget.readOnly) Padding(padding: const EdgeInsets.only(right: 8), child: SizedBox(width: 22, height: 24, child: Checkbox(value: selected, onChanged: (_) => _toggleRowSelection(order), materialTapTargetSize: MaterialTapTargetSize.shrinkWrap, visualDensity: VisualDensity.compact))),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(order.customerName.isEmpty ? 'Unnamed customer' : order.customerName, maxLines: 2, overflow: TextOverflow.ellipsis, style: GoogleFonts.cairo(fontSize: 14, fontWeight: FontWeight.w800, color: _textColor)),
              const SizedBox(height: 3),
              Text('Order ${order.designOrder.isEmpty ? '—' : order.designOrder}', style: GoogleFonts.cairo(fontSize: 10, color: _secondaryTextColor)),
            ])),
            if (widget.readOnly)
              Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6), decoration: BoxDecoration(color: statusColor.withOpacity(.12), borderRadius: BorderRadius.circular(10)), child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 105), child: Text(order.status, maxLines: 2, overflow: TextOverflow.ellipsis, style: GoogleFonts.cairo(fontSize: 9, fontWeight: FontWeight.w800, color: statusColor))))
            else
              Material(
                color: statusColor.withOpacity(.10),
                borderRadius: BorderRadius.circular(10),
                child: InkWell(
                  borderRadius: BorderRadius.circular(10),
                  onTap: () => _showMobileStatusPicker(order),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
                    child: Row(mainAxisSize: MainAxisSize.min, children: [
                      ConstrainedBox(constraints: const BoxConstraints(maxWidth: 94), child: Text(order.status, maxLines: 2, overflow: TextOverflow.ellipsis, style: GoogleFonts.cairo(fontSize: 9, fontWeight: FontWeight.w800, color: statusColor))),
                      const SizedBox(width: 3),
                      Icon(Icons.keyboard_arrow_down_rounded, size: 14, color: statusColor),
                    ]),
                  ),
                ),
              ),
          ]),
          const SizedBox(height: 12),
          Container(height: 1, color: _borderColor.withOpacity(.65)),
          const SizedBox(height: 10),
          detail(Icons.qr_code_2_rounded, 'Product', order.productCode),
          const SizedBox(height: 7),
          detail(Icons.description_outlined, 'Description', order.description),
          const SizedBox(height: 7),
          Row(children: [Expanded(child: detail(Icons.inventory_2_outlined, 'Qty', '${order.quantity} ${order.unitOfMeasure}')), Expanded(child: detail(Icons.payments_outlined, 'Value', valueText))]),
          const SizedBox(height: 7),
          Row(children: [Expanded(child: detail(Icons.person_outline, 'Engineer', order.responsibleEngineer ?? 'Unassigned')), Expanded(child: detail(Icons.factory_outlined, 'Factory', order.factory ?? '—'))]),
          const SizedBox(height: 7),
          Row(children: [Expanded(child: detail(Icons.calendar_today_outlined, 'Order date', order.orderDate ?? '—')), Expanded(child: detail(Icons.local_shipping_outlined, 'Delivery', order.deliveryDate ?? '—'))]),
          if (widget.approvalTrackingMode) ...[
            const SizedBox(height: 7),
            detail(Icons.event_available_outlined, 'Created At', _readOnlyCellText(order, 'created_at_tracking')),
            const SizedBox(height: 7),
            detail(Icons.draw_outlined, 'رسم الاعتماد', _readOnlyCellText(order, 'drawing_approval_date')),
            const SizedBox(height: 7),
            detail(Icons.verified_outlined, 'اعتماد البيع', _readOnlyCellText(order, 'sales_approval_date')),
            const SizedBox(height: 7),
            detail(Icons.edit_note_rounded, 'التعديلات', '${_readOnlyCellText(order, 'modifications_count')} | ${_readOnlyCellText(order, 'modifications_last_date')}'),
            const SizedBox(height: 7),
            detail(Icons.factory_outlined, 'تاريخ التشغيل', _readOnlyCellText(order, 'operation_date')),
          ],
          const SizedBox(height: 11),
          Row(children: [
            if (!widget.readOnly) Expanded(child: OutlinedButton.icon(onPressed: () => _showMobileStatusPicker(order), icon: const Icon(Icons.swap_horiz_rounded, size: 16), label: Text('Status', style: GoogleFonts.cairo(fontSize: 10, fontWeight: FontWeight.w700)), style: OutlinedButton.styleFrom(minimumSize: const Size(0, 38), foregroundColor: statusColor, side: BorderSide(color: statusColor.withOpacity(.45)), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(11))))),
            if (!widget.readOnly && canEdit) const SizedBox(width: 7),
            if (!widget.readOnly && canEdit) Expanded(child: OutlinedButton.icon(onPressed: () => _showMobileEditMenu(order), icon: const Icon(Icons.edit_outlined, size: 16), label: Text('Edit fields', style: GoogleFonts.cairo(fontSize: 10)), style: OutlinedButton.styleFrom(minimumSize: const Size(0, 38), foregroundColor: const Color(0xFF6366F1), side: BorderSide(color: _borderColor), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(11))))),
            if (!widget.readOnly && canEdit) const SizedBox(width: 7),
            Expanded(child: OutlinedButton.icon(onPressed: () => _copyOrderData(order), icon: const Icon(Icons.copy_rounded, size: 15), label: Text('Copy details', style: GoogleFonts.cairo(fontSize: 10)), style: OutlinedButton.styleFrom(minimumSize: const Size(0, 36), foregroundColor: _secondaryTextColor, side: BorderSide(color: _borderColor), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))))),
            if (_isHedOrManager || _isDataEntry) ...[
              const SizedBox(width: 7),
              IconButton.filledTonal(tooltip: 'Track order', onPressed: () => _navigateToOrderTracking(order), icon: const Icon(Icons.track_changes_rounded, size: 18)),
            ],
          ]),
        ])),
      ),
    );
  }

  Widget _buildApprovalContractFilter() {
    return Container(
      height: 38,
      padding: const EdgeInsets.symmetric(horizontal: 10),
      decoration: BoxDecoration(
        color: _surfaceColor,
        border: Border.all(color: _borderColor),
        borderRadius: BorderRadius.circular(7),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: _approvalContractFilter,
          isDense: true,
          dropdownColor: _surfaceColor,
          style: GoogleFonts.cairo(fontSize: 11, color: _textColor),
          icon: Icon(Icons.keyboard_arrow_down, color: _secondaryTextColor),
          items: const [
            DropdownMenuItem(value: 'all', child: Text('All contracts')),
            DropdownMenuItem(value: 'five_digits', child: Text('5-digit contracts')),
            DropdownMenuItem(value: '91000', child: Text('Starts with 91000')),
            DropdownMenuItem(value: '31000', child: Text('Starts with 31000')),
          ],
          onChanged: (value) {
            if (value == null) return;
            setState(() {
              _approvalContractFilter = value;
              _rebuildGroups();
            });
          },
        ),
      ),
    );
  }

  Widget _buildApprovalExcelButton() {
    return OutlinedButton.icon(
      onPressed: () => _saveOrders(_getFilteredOrders(), 'Approval Tracking'),
      icon: const Icon(Icons.file_download_outlined, size: 17),
      label: Text('Excel Download', style: GoogleFonts.cairo(fontSize: 11, fontWeight: FontWeight.w600)),
      style: OutlinedButton.styleFrom(
        foregroundColor: _textColor,
        backgroundColor: _surfaceColor,
        side: BorderSide(color: _borderColor),
        minimumSize: const Size(0, 38),
        padding: const EdgeInsets.symmetric(horizontal: 10),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(7)),
      ),
    );
  }

  Widget _buildApprovalBackButton() {
    return OutlinedButton.icon(
      onPressed: () => Navigator.of(context).maybePop(),
      icon: const Icon(Icons.arrow_back, size: 17),
      label: Text('Back', style: GoogleFonts.cairo(fontSize: 11, fontWeight: FontWeight.w600)),
      style: OutlinedButton.styleFrom(
        foregroundColor: _textColor,
        backgroundColor: _surfaceColor,
        side: BorderSide(color: _borderColor),
        minimumSize: const Size(0, 38),
        padding: const EdgeInsets.symmetric(horizontal: 10),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(7)),
      ),
    );
  }

  Widget _buildTopBar() {
    final isAdmin =
        widget.loggedInEmployee?.role?.toLowerCase() == 'admin' ||
            widget.loggedInEmployee?.role?.toLowerCase() == 'software head' ||
            widget.loggedInEmployee?.role?.toLowerCase() == 'head';

    // One full-width toolbar: the search field takes all remaining space.
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(
        color: _backgroundColor,
        border: Border(bottom: BorderSide(color: _borderColor)),
      ),
      child: LayoutBuilder(
        builder: (context, constraints) {
          final isWide = constraints.maxWidth >= 1050;

          final title = SizedBox(
            width: isWide ? 135 : 190,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  widget.approvalTrackingMode ? 'Approval Tracking' : (widget.doneOrdersOnly ? 'SAP Done Orders' : 'Orders'),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: GoogleFonts.cairo(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: _textColor,
                  ),
                ),
                Text(
                  '${_allOrders.length} records${_selectedRowsIds.isNotEmpty ? ' • ${_selectedRowsIds.length} selected' : ''}',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: GoogleFonts.cairo(
                    fontSize: 10,
                    color: _secondaryTextColor,
                  ),
                ),
              ],
            ),
          );

          final actionsMenu = PopupMenuButton<String>(
            tooltip: 'More actions',
            color: _surfaceColor,
            onSelected: (action) {
              switch (action) {
                case 'arrange':
                  _showStatusArrangementDialog();
                  break;
                case 'edit':
                  setState(() => _editMode = !_editMode);
                  break;
                case 'add_task':
                  _showAddTaskDialog();
                  break;
                case 'add_contract':
                  _showAddContractDialog();
                  break;
                case 'factories':
                  _showFactorySearchDialog();
                  break;
                case 'employees':
                  _navigateToEmployeeManagement();
                  break;
                case 'import':
                  _showImportDialog();
                  break;
                case 'approval_tracking':
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (_) => ApprovalTrackingPage(
                        sapService: widget.sapService,
                        loggedInEmployee: widget.loggedInEmployee,
                      ),
                    ),
                  );
                  break;
                case 'export_excel':
                  if (_allOrders.isNotEmpty) {
                    _saveOrders(_allOrders, 'Orders');
                  }
                  break;
              }
            },
            itemBuilder: (context) => [
              if (!widget.readOnly && _isHedOrManager)
                PopupMenuItem(
                  value: 'add_contract',
                  child: _menuAction(Icons.post_add_rounded, 'Add Contract'),
                ),
              PopupMenuItem(
                value: 'arrange',
                child: _menuAction(Icons.swap_vert, 'Arrange'),
              ),
              if (!widget.readOnly)
                PopupMenuItem(
                  value: 'edit',
                  child: _menuAction(
                    _editMode ? Icons.edit_off : Icons.edit_outlined,
                    _editMode ? 'Edit Mode (ON)' : 'Edit Mode',
                    color: const Color(0xFFE69D00),
                  ),
                ),
              if (!widget.readOnly)
                PopupMenuItem(
                  value: 'add_task',
                  child: _menuAction(Icons.add_task, 'Add Task'),
                ),
              if (_isHedOrManager && !widget.approvalTrackingMode)
                PopupMenuItem(
                  value: 'approval_tracking',
                  child: _menuAction(Icons.fact_check_outlined, 'Approval Tracking'),
                ),
              PopupMenuItem(
                value: 'factories',
                child: _menuAction(Icons.factory_outlined, 'Factories'),
              ),
              if (isAdmin)
                PopupMenuItem(
                  value: 'employees',
                  child: _menuAction(Icons.people_outline, 'Employee Management'),
                ),
              if (!widget.readOnly && _canImportDelete)
                PopupMenuItem(
                  value: 'import',
                  child: _menuAction(Icons.upload_file, 'Import Excel'),
                ),
              PopupMenuItem(
                value: 'export_excel',
                child: _menuAction(Icons.download, 'Export Excel'),
              ),
            ],
            child: Container(
              height: 38,
              padding: const EdgeInsets.symmetric(horizontal: 10),
              decoration: BoxDecoration(
                color: _surfaceColor,
                border: Border.all(color: _borderColor),
                borderRadius: BorderRadius.circular(7),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.more_horiz, size: 16, color: _secondaryTextColor),
                  const SizedBox(width: 6),
                  Text(
                    'Actions',
                    style: GoogleFonts.cairo(
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      color: _textColor,
                    ),
                  ),
                  const SizedBox(width: 4),
                  Icon(Icons.arrow_drop_down, size: 16, color: _secondaryTextColor),
                ],
              ),
            ),
          );

          final filtersButton =
          SizedBox(
            height: 38,
            child: _buildActionBtn(Icons.filter_list, 'Filters', _showFilterDialog),
          );

          if (isWide) {
            return Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                if (widget.approvalTrackingMode) ...[
                  _buildApprovalBackButton(),
                  const SizedBox(width: 12),
                ],
                // Keep the title pinned to the logical start of the app bar.
                Align(
                  alignment: AlignmentDirectional.centerStart,
                  child: title,
                ),
                const SizedBox(width: 12),
                // The toolbar controls occupy a separate end-aligned region.
                // The expandable search grows into the available gap, never
                // changing the title's position.
                Expanded(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      _buildSearchField(anchorRight: true),
                      const SizedBox(width: 8),
                      if (widget.approvalTrackingMode) ...[
                        _buildApprovalContractFilter(),
                        const SizedBox(width: 8),
                      ],
                      if (widget.readOnly && !widget.approvalTrackingMode)
                        OutlinedButton.icon(
                          onPressed: () {
                            Navigator.of(context).pushAndRemoveUntil(
                              MaterialPageRoute(builder: (_) => const LoginPage()),
                                  (route) => false,
                            );
                          },
                          icon: const Icon(Icons.login, size: 16),
                          label: Text(
                            'Back to Login',
                            style: GoogleFonts.cairo(fontSize: 11),
                          ),
                          style: OutlinedButton.styleFrom(
                            foregroundColor: _secondaryTextColor,
                            side: BorderSide(color: _borderColor),
                            backgroundColor: _surfaceColor,
                            minimumSize: const Size(0, 38),
                            maximumSize: const Size(double.infinity, 38),
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 0),
                            tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(7),
                            ),
                          ),
                        ),
                      if (!widget.approvalTrackingMode)
                        SizedBox(width: 175, child: _buildDesignTeamFilterButton()),
                      const SizedBox(width: 8),
                      if (!widget.approvalTrackingMode && !widget.readOnly && (_isHeadRole || _isManagerRole)) ...[
                        _buildEmployeeWorkDropdown(),
                        if (_isManagerRole) ...[
                          const SizedBox(width: 8),
                          _buildMyWorkButton(),

                        ],
                        const SizedBox(width: 8),
                      ] else if (!widget.approvalTrackingMode && !widget.readOnly && _isEngineerRole) ...[
                        _buildMyWorkButton(),
                        const SizedBox(width: 8),
                      ],
                      _buildSortButton(),
                      const SizedBox(width: 8),
                      filtersButton,
                      const SizedBox(width: 8),
                      if (widget.approvalTrackingMode)
                        _buildApprovalExcelButton()
                      else
                        actionsMenu,
                      if (_selectedRowsIds.isNotEmpty) ...[
                        const SizedBox(width: 4),
                        IconButton(
                          tooltip: 'Clear selection',
                          onPressed: _clearSelection,
                          icon: const Icon(Icons.close, size: 16),
                          color: _secondaryTextColor,
                          constraints: const BoxConstraints.tightFor(width: 38, height: 38),
                          padding: EdgeInsets.zero,
                          visualDensity: VisualDensity.standard,
                        ),
                      ],
                    ],
                  ),
                ),
              ],
            );
          }

          return Wrap(
            crossAxisAlignment: WrapCrossAlignment.center,
            spacing: 8,
            runSpacing: 8,
            children: [
              if (widget.approvalTrackingMode) _buildApprovalBackButton(),
              title,
              if (widget.approvalTrackingMode) _buildApprovalContractFilter(),
              if (widget.readOnly && !widget.approvalTrackingMode)
                OutlinedButton.icon(
                  onPressed: () {
                    Navigator.of(context).pushAndRemoveUntil(
                      MaterialPageRoute(builder: (_) => const LoginPage()),
                          (route) => false,
                    );
                  },
                  icon: const Icon(Icons.login, size: 16),
                  label: Text('Back to Login',
                      style: GoogleFonts.cairo(fontSize: 11)),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: _secondaryTextColor,
                    side: BorderSide(color: _borderColor),
                    backgroundColor: _surfaceColor,
                    minimumSize: const Size(0, 38),
                    maximumSize: const Size(double.infinity, 38),
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 0),
                    tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(7),
                    ),
                  ),
                ),
              _buildSearchField(),
              if (!widget.approvalTrackingMode) _buildDesignTeamFilterButton(),
              if (!widget.approvalTrackingMode && !widget.readOnly && (_isHeadRole || _isManagerRole))
                _buildEmployeeWorkDropdown(),
              if (!widget.approvalTrackingMode && !widget.readOnly && _isManagerRole) _buildMyWorkButton(),
              if (!widget.approvalTrackingMode && !widget.readOnly && _isEngineerRole) _buildMyWorkButton(),
              _buildSortButton(),
              filtersButton,
              if (widget.approvalTrackingMode) _buildApprovalExcelButton() else actionsMenu,
              if (_selectedRowsIds.isNotEmpty)
                TextButton.icon(
                  onPressed: _clearSelection,
                  icon: const Icon(Icons.close, size: 16),
                  label: Text('Clear selection',
                      style: GoogleFonts.cairo(fontSize: 11)),
                  style: TextButton.styleFrom(
                    minimumSize: const Size(0, 38),
                    maximumSize: const Size(double.infinity, 38),
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 0),
                    tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                  ),
                ),
            ],
          );
        },
      ),
    );
  }

  Widget _menuAction(IconData icon, String label, {Color? color}) {
    return Row(
      children: [
        Icon(icon, size: 18, color: color ?? _secondaryTextColor),
        const SizedBox(width: 10),
        Text(label, style: GoogleFonts.cairo(fontSize: 12, color: color ?? _textColor)),
      ],
    );
  }

  Widget _employeeDropdownCell(
      String? currentValue,
      SAPMainOrder order,
      String field,
      ) {
    final canEdit = _isOrderEditable(order);
    final canClearResponsibleEngineer =
        field == 'responsible_engineer' &&
            _canClearResponsibleEngineer(order.status) &&
            !_isOrderLocked(order);
    // Reviewer and Alternative Engineer can be cleared in any active status.
    // Keep them protected for Planning, Master Data, Done, and Task Done.
    final canClearReviewerOrAlternative =
        (field == 'reviewer' || field == 'correspondence_engineer') &&
            !_isOrderLocked(order);
    final displayName = currentValue ?? 'Select...';
    final hasValue = currentValue != null && currentValue.isNotEmpty;
    // If Responsible Engineer is "header", Alternative Engineer is fully locked.
    if (field == 'correspondence_engineer' &&
        _isHeaderResponsibleEngineerRow(order)) {
      return SizedBox(
        width: 120,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 2),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 3),
            decoration: BoxDecoration(
              color: Colors.grey.withOpacity(0.08),
              borderRadius: BorderRadius.circular(4),
              border: Border.all(color: Colors.grey.withOpacity(0.25)),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.lock_outline, size: 11, color: Colors.grey),
                const SizedBox(width: 4),
                Flexible(
                  child: Text(
                    'Locked',
                    overflow: TextOverflow.ellipsis,
                    style: GoogleFonts.cairo(
                      fontSize: 10,
                      fontWeight: FontWeight.w600,
                      color: Colors.grey.shade700,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    // Header rows are assigned to "header" during import.
    // Only admins can change the Responsible Engineer of a header row.
    if (field == 'responsible_engineer' &&
        currentValue?.trim().toLowerCase() == 'header' &&
        !_isAdmin) {
      return SizedBox(
        width: field == 'responsible_engineer' ? 130 : 120,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 2),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 3),
            decoration: BoxDecoration(
              color: Colors.grey.withOpacity(0.08),
              borderRadius: BorderRadius.circular(4),
              border: Border.all(
                color: Colors.grey.withOpacity(0.25),
              ),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(
                  Icons.lock_outline,
                  size: 11,
                  color: Colors.grey,
                ),
                const SizedBox(width: 4),
                Flexible(
                  child: Text(
                    'header',
                    overflow: TextOverflow.ellipsis,
                    style: GoogleFonts.cairo(
                      fontSize: 10,
                      fontWeight: FontWeight.w600,
                      color: Colors.grey.shade700,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    // "No One" is locked for Responsible Engineer for non-admin users,
    // just like a header row.
    if (field == 'responsible_engineer' &&
        _isNoOneResponsibleEngineerLocked(order)) {
      return SizedBox(
        width: 130,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 2),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 3),
            decoration: BoxDecoration(
              color: Colors.grey.withOpacity(0.08),
              borderRadius: BorderRadius.circular(4),
              border: Border.all(color: Colors.grey.withOpacity(0.25)),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.lock_outline, size: 11, color: Colors.grey),
                const SizedBox(width: 4),
                Flexible(
                  child: Text(
                    'No One',
                    overflow: TextOverflow.ellipsis,
                    style: GoogleFonts.cairo(
                      fontSize: 10,
                      fontWeight: FontWeight.w600,
                      color: Colors.grey.shade700,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    // Editable searchable assignment dropdown.
    return SizedBox(
      width: field == 'responsible_engineer' ? 130 : 120,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 2),
        child: InkWell(
          borderRadius: BorderRadius.circular(4),
          onTap: () async {
            final selectedValue = await _showEmployeeAssignmentDialog(
              field: field,
              currentValue: currentValue,
            );

            if (selectedValue != null) {
              _updateOrderEngineer(order, field, selectedValue);
            }
          },
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 3),
            decoration: BoxDecoration(
              color: hasValue
                  ? const Color(0xFF6366F1).withOpacity(0.05)
                  : _hoverColor,
              borderRadius: BorderRadius.circular(4),
              border: Border.all(
                color: hasValue
                    ? const Color(0xFF6366F1).withOpacity(0.2)
                    : _borderColor,
              ),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Flexible(
                  child: Text(
                    hasValue ? displayName : '',
                    style: GoogleFonts.cairo(
                      fontSize: 10,
                      fontWeight: FontWeight.w500,
                      color: hasValue ? _textColor : _secondaryTextColor,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                if (hasValue)
                  IconButton(
                    tooltip: 'Clear ${_formatFieldName(field)}',
                    onPressed: (canEdit ||
                        canClearResponsibleEngineer ||
                        canClearReviewerOrAlternative)
                        ? () async {
                      final confirmed = await showDialog<bool>(
                        context: context,
                        builder: (dialogContext) => AlertDialog(
                          title: Text(
                            'Clear ${_formatFieldName(field)}?',
                            style: GoogleFonts.cairo(
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          content: Text(
                            'Are you sure you want to clear the assigned engineer?',
                            style: GoogleFonts.cairo(fontSize: 13),
                          ),
                          actions: [
                            TextButton(
                              onPressed: () =>
                                  Navigator.pop(dialogContext, false),
                              child: Text(
                                'Cancel',
                                style: GoogleFonts.cairo(),
                              ),
                            ),
                            ElevatedButton(
                              onPressed: () =>
                                  Navigator.pop(dialogContext, true),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.red,
                                foregroundColor: Colors.white,
                              ),
                              child: Text(
                                'Clear',
                                style: GoogleFonts.cairo(),
                              ),
                            ),
                          ],
                        ),
                      );

                      if (confirmed == true) {
                        await _updateOrderEngineer(
                          order,
                          field,
                          '',
                        );
                      }
                    }
                        : null,
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(
                      minWidth: 20,
                      minHeight: 20,
                    ),
                    splashRadius: 10,
                    icon: Icon(
                      Icons.close,
                      size: 12,
                      color: (canEdit ||
                          canClearResponsibleEngineer ||
                          canClearReviewerOrAlternative)
                          ? _secondaryTextColor
                          : _secondaryTextColor.withOpacity(0.35),
                    ),
                  ),
                Icon(
                  Icons.arrow_drop_down,
                  size: 12,
                  color: hasValue
                      ? const Color(0xFF6366F1)
                      : _secondaryTextColor,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // Fixed-height toolbar dropdown used by Design Team and All orders.
  // Avoids InputDecorator's intrinsic-height behavior shrinking these controls.
  Widget _buildToolbarFilterDropdown(
      String label,
      String? value,
      List<String> items,
      Function(String?) onChanged, {
        bool isMobile = false,
      }) {
    final hasValue = value != null && value.isNotEmpty;
    final displayValue = hasValue ? value! : 'All';

    return SizedBox(
      height: isMobile ? 50 : 38,
      child: Material(
        color: _surfaceColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(isMobile ? 13 : 7),
          side: BorderSide(color: _borderColor),
        ),
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: () => _showSearchableFilterPicker(
            label: label,
            value: value,
            items: items,
            onChanged: onChanged,
          ),
          child: Padding(
            padding: EdgeInsets.symmetric(
              horizontal: isMobile ? 14 : 10,
              vertical: isMobile ? 5 : 3,
            ),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        label,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: GoogleFonts.cairo(
                          fontSize: isMobile ? 12 : 9,
                          fontWeight: isMobile ? FontWeight.w600 : FontWeight.normal,
                          height: 1,
                          color: _secondaryTextColor,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        displayValue,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: GoogleFonts.cairo(
                          fontSize: isMobile ? 15 : 11,
                          fontWeight: isMobile ? FontWeight.w700 : FontWeight.normal,
                          height: 1,
                          color: hasValue ? _textColor : _secondaryTextColor,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 6),
                Icon(
                  Icons.search,
                  size: isMobile ? 22 : 16,
                  color: hasValue
                      ? const Color(0xFF6366F1)
                      : _secondaryTextColor,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildDesignTeamFilterButton({bool isMobile = false}) {
    final designTeams = <String>{};
    for (final order in _allOrders) {
      final team = order.designTeam?.trim();
      if (team != null && team.isNotEmpty) {
        designTeams.add(team);
      }
    }

    return SizedBox(
      width: 190,
      child: _buildToolbarFilterDropdown(
        'Design Team',
        _filterDesignTeam,
        ['All', ...designTeams.toList()..sort()],
            (value) {
          setState(() {
            _filterDesignTeam = value;
          });
          _rebuildGroups();
        },
        isMobile: isMobile,
      ),
    );
  }

  Widget _buildHeaderRow() {
    return LayoutBuilder(
      builder: (context, constraints) {
        // Use Wrap for screens narrower than 1200px
        final isWide = constraints.maxWidth > 1100;

        if (isWide) {
          return Row(
            children: [
              Expanded(child: _buildHeaderInfo()),
              _buildSearchField(),
              const SizedBox(width: 8),
              _buildDesignTeamFilterButton(),
              const SizedBox(width: 8),
              _buildSortButton(),
              const SizedBox(width: 12),
              SizedBox(
                height: 38,
                child: _buildActionBtn(Icons.filter_list, 'Filters', _showFilterDialog),
              ),
              const SizedBox(width: 8),
              const SizedBox(width: 8),
              // Only show Import for admin or abd.elmoen
              if (_canImportDelete) ...[
                const SizedBox(width: 8),
                _buildImportButton(),
              ],
            ],
          );
        } else {
          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildHeaderInfo(),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  _buildSearchField(),
                  _buildDesignTeamFilterButton(),
                  _buildSortButton(),
                  _buildActionBtn(
                    Icons.filter_list,
                    'Filters',
                    _showFilterDialog,
                  ),
                  // Only show Import for admin or abd.elmoen
                  if (_canImportDelete) _buildImportButton(),
                ],
              ),
            ],
          );
        }
      },
    );
  }

  // Header info (record count + filters)
  Widget _buildHeaderInfo() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Total: ${_allOrders.length} records',
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: GoogleFonts.cairo(
            fontSize: 13,
            color: _secondaryTextColor,
          ),
        ),
        if (_searchQuery.isNotEmpty)
          Text(
            'Filtered: "$_searchQuery"',
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: GoogleFonts.cairo(
              fontSize: 10,
              color: const Color(0xFF6366F1),
            ),
          ),
        if (_hasActiveFilters)
          GestureDetector(
            onTap: () {
              setState(() {
                _filterStatus = null;
                _filterFactory = null;
                _filterDesignTeam = null;
                _filterSalesEngineer = null;
                _filterResponsibleEngineer = null;
                _filterReviewer = null;
                _filterCorrespondenceEngineer = null;
                _filterMyWork = false;
                _selectedWorkEmployee = null;
              });
              _rebuildGroups();
            },
            child: Text(
              'Clear filters',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: GoogleFonts.cairo(
                fontSize: 11,
                color: Colors.red,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
      ],
    );
  }

  // Compact search icon that expands on demand and collapses when cleared.
  Widget _buildSearchField({bool anchorRight = false}) {
    final screenWidth = MediaQuery.of(context).size.width;
    final expandedWidth = screenWidth < 700
        ? (screenWidth - 40).clamp(180.0, 360.0).toDouble()
        : 300.0;

    void expandAndFocus() {
      setState(() => _searchExpanded = true);
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted && _searchExpanded) {
          _searchFocusNode.requestFocus();
        }
      });
    }

    final searchControl = AnimatedContainer(
      duration: const Duration(milliseconds: 240),
      curve: Curves.easeOutCubic,
      width: _searchExpanded ? expandedWidth : 40,
      height: 38,
      decoration: BoxDecoration(
        color: _surfaceColor,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: _searchExpanded && _searchFocusNode.hasFocus
              ? const Color(0xFF6366F1)
              : _borderColor,
        ),
        boxShadow: _searchExpanded && _searchFocusNode.hasFocus
            ? [
          BoxShadow(
            color: const Color(0xFF6366F1).withOpacity(0.10),
            blurRadius: 10,
            spreadRadius: 1,
          ),
        ]
            : null,
      ),
      clipBehavior: Clip.antiAlias,
      child: _searchExpanded
          ? TextField(
        controller: _searchController,
        focusNode: _searchFocusNode,
        autofocus: true,
        // Keep the search field expanded while it contains a query,
        // even when the user taps elsewhere. Collapse only when it is empty.
        onTapOutside: (_) {
          if (_searchController.text.trim().isEmpty && _searchExpanded) {
            setState(() => _searchExpanded = false);
          }
          _searchFocusNode.unfocus();
        },
        onChanged: (value) {
          final isEmpty = value.trim().isEmpty;
          setState(() {
            _searchQuery = value;
            _searchExpanded = !isEmpty;
          });
          _scheduleSearchAllOrders(value);
          _rebuildGroups();
          if (isEmpty) {
            _searchFocusNode.unfocus();
          }
        },
        style: GoogleFonts.cairo(fontSize: 11, color: _textColor),
        decoration: InputDecoration(
          hintText: widget.approvalTrackingMode ? 'Search by Order ID / Design Order...' : 'Search orders...',
          hintStyle: GoogleFonts.cairo(
            color: _secondaryTextColor,
            fontSize: 11,
          ),
          prefixIcon: Icon(
            Icons.search_rounded,
            color: _secondaryTextColor,
            size: 16,
          ),
          prefixIconConstraints: const BoxConstraints(
            minWidth: 34,
            minHeight: 34,
          ),
          suffixIcon: _searchController.text.isNotEmpty
              ? IconButton(
            tooltip: 'Clear search',
            visualDensity: VisualDensity.compact,
            icon: const Icon(Icons.close_rounded, size: 16),
            onPressed: () {
              _searchController.clear();
              setState(() {
                _searchQuery = '';
                _searchExpanded = false;
              });
              _searchFocusNode.unfocus();
              _rebuildGroups();
            },
          )
              : IconButton(
            tooltip: 'Close search',
            visualDensity: VisualDensity.compact,
            icon: const Icon(Icons.close_rounded, size: 16),
            onPressed: () {
              _searchController.clear();
              setState(() {
                _searchQuery = '';
                _searchExpanded = false;
              });
              _searchFocusNode.unfocus();
              _rebuildGroups();
            },
          ),
          filled: true,
          fillColor: Colors.transparent,
          border: InputBorder.none,
          enabledBorder: InputBorder.none,
          focusedBorder: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 4,
            vertical: 10,
          ),
        ),
      )
          : Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: expandAndFocus,
          borderRadius: BorderRadius.circular(10),
          child: Tooltip(
            message: 'Search orders',
            child: Center(
              child: Icon(
                Icons.search_rounded,
                size: 16,
                color: _secondaryTextColor,
              ),
            ),
          ),
        ),
      ),
    );

    if (anchorRight) {
      // Reserve the expanded hit-test area in the layout. The parent toolbar
      // is end-aligned, so the right-side action buttons stay in place while
      // the search field grows to the left. Keeping this at 40px caused the
      // visible overflow to fall outside the parent's hit-test bounds.
      return SizedBox(
        width: _searchExpanded ? expandedWidth : 40,
        height: 38,
        child: Align(
          alignment: AlignmentDirectional.centerEnd,
          child: searchControl,
        ),
      );
    }

    return searchControl;
  }

  // Sort button
  Widget _buildSortButton() {
    return PopupMenuButton<String>(
      onSelected: (value) {
        setState(() => _sortBy = value);
        _rebuildGroups();
      },
      tooltip: 'Sort by',
      child: Container(
        height: 38,
        padding: const EdgeInsets.symmetric(horizontal: 10),
        decoration: BoxDecoration(
          border: Border.all(color: _borderColor),
          borderRadius: BorderRadius.circular(6),
          color: _sortBy != 'default'
              ? const Color(0xFF6366F1).withOpacity(0.05)
              : _surfaceColor,
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.sort,
              size: 16,
              color: _sortBy != 'default'
                  ? const Color(0xFF6366F1)
                  : _secondaryTextColor,
            ),
            const SizedBox(width: 4),
            Text(
              _getSortLabel(),
              style: GoogleFonts.cairo(
                fontSize: 11,
                fontWeight: FontWeight.w600,
                color: _sortBy != 'default'
                    ? const Color(0xFF6366F1)
                    : _secondaryTextColor,
              ),
            ),
            const Icon(Icons.arrow_drop_down, size: 16),
          ],
        ),
      ),
      itemBuilder: (context) => [
        PopupMenuItem(
          value: 'default',
          child: Row(
            children: [
              Icon(
                Icons.sort,
                size: 16,
                color: _sortBy == 'default'
                    ? const Color(0xFF6366F1)
                    : _secondaryTextColor,
              ),
              const SizedBox(width: 8),
              Text(
                'Default',
                style: GoogleFonts.cairo(
                  fontSize: 12,
                  fontWeight: _sortBy == 'default'
                      ? FontWeight.w700
                      : FontWeight.w400,
                ),
              ),
              if (_sortBy == 'default') const Spacer(),
              if (_sortBy == 'default')
                const Icon(Icons.check, size: 16, color: Color(0xFF6366F1)),
            ],
          ),
        ),
        const PopupMenuDivider(),
        PopupMenuItem(
          value: 'item_asc',
          child: Row(
            children: [
              Icon(
                Icons.format_list_numbered,
                size: 16,
                color: _sortBy == 'item_asc'
                    ? const Color(0xFF6366F1)
                    : _secondaryTextColor,
              ),
              const SizedBox(width: 8),
              Text(
                'Contract / Item ↑',
                style: GoogleFonts.cairo(
                  fontSize: 12,
                  fontWeight: _sortBy == 'item_asc'
                      ? FontWeight.w700
                      : FontWeight.w400,
                ),
              ),
              if (_sortBy == 'item_asc') const Spacer(),
              if (_sortBy == 'item_asc') const Icon(Icons.check, size: 16),
            ],
          ),
        ),
        PopupMenuItem(
          value: 'value_desc',
          child: Row(
            children: [
              Icon(
                Icons.arrow_downward,
                size: 14,
                color: _sortBy == 'value_desc'
                    ? const Color(0xFF6366F1)
                    : _secondaryTextColor,
              ),
              const SizedBox(width: 8),
              Text(
                'Value ↓',
                style: GoogleFonts.cairo(
                  fontSize: 12,
                  fontWeight: _sortBy == 'value_desc'
                      ? FontWeight.w700
                      : FontWeight.w400,
                ),
              ),
              if (_sortBy == 'value_desc') const Spacer(),
              if (_sortBy == 'value_desc') const Icon(Icons.check, size: 16),
            ],
          ),
        ),
        PopupMenuItem(
          value: 'value_asc',
          child: Row(
            children: [
              Icon(
                Icons.arrow_upward,
                size: 14,
                color: _sortBy == 'value_asc'
                    ? const Color(0xFF6366F1)
                    : _secondaryTextColor,
              ),
              const SizedBox(width: 8),
              Text(
                'Value ↑',
                style: GoogleFonts.cairo(
                  fontSize: 12,
                  fontWeight: _sortBy == 'value_asc'
                      ? FontWeight.w700
                      : FontWeight.w400,
                ),
              ),
              if (_sortBy == 'value_asc') const Spacer(),
              if (_sortBy == 'value_asc') const Icon(Icons.check, size: 16),
            ],
          ),
        ),
        const PopupMenuDivider(),
        PopupMenuItem(
          value: 'date_desc',
          child: Row(
            children: [
              Icon(
                Icons.calendar_today,
                size: 14,
                color: _sortBy == 'date_desc'
                    ? const Color(0xFF6366F1)
                    : _secondaryTextColor,
              ),
              const SizedBox(width: 8),
              Text(
                'Date ↓',
                style: GoogleFonts.cairo(
                  fontSize: 12,
                  fontWeight: _sortBy == 'date_desc'
                      ? FontWeight.w700
                      : FontWeight.w400,
                ),
              ),
              if (_sortBy == 'date_desc') const Spacer(),
              if (_sortBy == 'date_desc') const Icon(Icons.check, size: 16),
            ],
          ),
        ),
        PopupMenuItem(
          value: 'date_asc',
          child: Row(
            children: [
              Icon(
                Icons.calendar_today,
                size: 14,
                color: _sortBy == 'date_asc'
                    ? const Color(0xFF6366F1)
                    : _secondaryTextColor,
              ),
              const SizedBox(width: 8),
              Text(
                'Date ↑',
                style: GoogleFonts.cairo(
                  fontSize: 12,
                  fontWeight: _sortBy == 'date_asc'
                      ? FontWeight.w700
                      : FontWeight.w400,
                ),
              ),
              if (_sortBy == 'date_asc') const Spacer(),
              if (_sortBy == 'date_asc') const Icon(Icons.check, size: 16),
            ],
          ),
        ),
      ],
    );
  }

  Widget _designTeamDropdownCell(String? currentValue, SAPMainOrder order) {
    final canEdit = _isOrderEditable(order);
    final displayName = currentValue ?? 'Select...';
    final hasValue = currentValue != null && currentValue.isNotEmpty;

    // Editable dropdown
    return SizedBox(
      width: 130,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 2),
        child: PopupMenuButton<String>(
          onSelected: (newValue) {
            _updateOrderDesignTeam(order, newValue);
          },
          offset: const Offset(0, 40),
          position: PopupMenuPosition.under,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 3),
            decoration: BoxDecoration(
              color: hasValue
                  ? const Color(0xFF6366F1).withOpacity(0.05)
                  : _hoverColor,
              borderRadius: BorderRadius.circular(4),
              border: Border.all(
                color: hasValue
                    ? const Color(0xFF6366F1).withOpacity(0.2)
                    : _borderColor,
              ),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Flexible(
                  child: Text(
                    hasValue ? displayName : '-',
                    style: GoogleFonts.cairo(
                      fontSize: 10,
                      fontWeight: FontWeight.w500,
                      color: hasValue ? _textColor : _secondaryTextColor,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                Icon(
                  Icons.arrow_drop_down,
                  size: 12,
                  color: hasValue ? const Color(0xFF6366F1) : _secondaryTextColor,
                ),
              ],
            ),
          ),
          itemBuilder: (context) => [
            PopupMenuItem<String>(
              value: '',
              child: Row(
                children: [
                  const Icon(Icons.clear, size: 14, color: Colors.red),
                  const SizedBox(width: 8),
                  Text(
                    'Clear',
                    style: GoogleFonts.cairo(fontSize: 12, color: Colors.red),
                  ),
                ],
              ),
            ),
            const PopupMenuDivider(),
            ..._allTeamStatuses.map((s) {
              final isSelected = currentValue == s;
              return PopupMenuItem<String>(
                value: s,
                child: Row(
                  children: [
                    if (isSelected)
                      const Icon(
                        Icons.check,
                        size: 16,
                        color: Color(0xFF6366F1),
                      )
                    else
                      const SizedBox(width: 16),
                    const SizedBox(width: 8),
                    Text(
                      s,
                      style: GoogleFonts.cairo(
                        fontSize: 12,
                        fontWeight: isSelected
                            ? FontWeight.w700
                            : FontWeight.w400,
                        color: isSelected
                            ? const Color(0xFF6366F1)
                            : _textColor,
                      ),
                    ),
                  ],
                ),
              );
            }),
          ],
        ),
      ),
    );
  }

  Widget _buildImportButton() => OutlinedButton.icon(
    onPressed: _showImportDialog,
    icon: const Icon(Icons.upload_file, size: 16),
    label: Text(
      'Import Excel',
      style: GoogleFonts.cairo(fontSize: 11, fontWeight: FontWeight.w600),
    ),
    style: OutlinedButton.styleFrom(
      foregroundColor: const Color(0xFF059669),
      side: const BorderSide(color: Color(0xFF059669)),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
      backgroundColor: _surfaceColor,
    ),
  );

  Widget _buildSelectionToolbar() {
    // Check if all selected orders are "Tasks" (for showing delete button)
    final selectedOrders = _allOrders
        .where((o) => _selectedRowsIds.contains(o.id))
        .toList();
    final allAreTasks =
        selectedOrders.isNotEmpty &&
            selectedOrders.every((o) => o.status.toLowerCase() == 'tasks');
    final canDelete = _isAdmin || _isDataEntry || allAreTasks;

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: const Color(0xFFE69D00).withOpacity(0.05),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: const Color(0xFFE69D00).withOpacity(0.2)),
      ),
      child: Row(
        children: [
          const Icon(Icons.check_circle, size: 18, color: Color(0xFFE69D00)),
          const SizedBox(width: 8),
          Text(
            '${_selectedRowsIds.length} selected',
            style: GoogleFonts.cairo(
              fontSize: 13,
              fontWeight: FontWeight.w600,
              color: const Color(0xFFE69D00),
            ),
          ),
          const Spacer(),
          _buildSmallBtn(Icons.copy, 'Copy', _copySelectedOrdersData),
          const SizedBox(width: 8),
          if (_editMode && _selectedRowsIds.isNotEmpty) ...[
            _buildSmallBtn(
              Icons.edit,
              'Bulk Edit',
                  () => _showBulkEditDialog(),
            ),
            const SizedBox(width: 8),
          ],
          _buildSmallBtn(
            Icons.download,
            'Export Selected',
            _exportSelectedOrders,
          ),
          const SizedBox(width: 8),
          // Show delete for admin/data entry OR when all selected are Tasks
          if (canDelete) ...[
            _buildSmallBtn(
              Icons.delete_outline,
              'Delete',
              _deleteSelectedOrders,
            ),
            const SizedBox(width: 8),
          ],
          _buildSmallBtn(Icons.close, 'Clear', _clearSelection),
        ],
      ),
    );
  }

  Widget _buildDoneOrdersSection() {
    return Container(
      decoration: BoxDecoration(
        color: _surfaceColor,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: _borderColor),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          InkWell(
            onTap: _toggleDoneOrders,
            borderRadius: BorderRadius.circular(10),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              child: Row(
                children: [
                  Icon(
                    _doneOrdersExpanded
                        ? Icons.keyboard_arrow_down
                        : Icons.keyboard_arrow_up,
                    size: 20,
                    color: _secondaryTextColor,
                  ),
                  const SizedBox(width: 8),
                  Icon(Icons.inventory_2_outlined, size: 18, color: Colors.cyan),
                  const SizedBox(width: 8),
                  Text(
                    'SAP Done Orders',
                    style: GoogleFonts.cairo(
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      color: _textColor,
                    ),
                  ),
                  const SizedBox(width: 8),
                  if (_doneOrdersLoaded)
                    Text(
                      '${_doneOrders.length}',
                      style: GoogleFonts.cairo(
                        fontSize: 11,
                        color: _secondaryTextColor,
                      ),
                    ),
                  const Spacer(),
                  Text(
                    'Done • Task Done • Planning • Master Data',
                    style: GoogleFonts.cairo(
                      fontSize: 10,
                      color: _secondaryTextColor,
                    ),
                  ),
                ],
              ),
            ),
          ),
          if (_doneOrdersExpanded)
            SizedBox(
              height: 280,
              child: _doneOrdersLoading
                  ? Center(
                child: CircularProgressIndicator(
                  color: Theme.of(context).colorScheme.primary,
                ),
              )
                  : _doneOrders.isEmpty
                  ? Center(
                child: Text(
                  'No SAP done orders',
                  style: GoogleFonts.cairo(
                    color: _secondaryTextColor,
                  ),
                ),
              )
                  : _buildDoneOrdersTable(),
            ),
        ],
      ),
    );
  }

  Widget _buildDoneOrdersTable() {
    final columns = <Map<String, dynamic>>[
      {'key': 'status', 'label': 'Status', 'width': 120.0},
      {'key': 'design_order', 'label': 'Design Order', 'width': 130.0},
      {'key': 'contract_number', 'label': 'Contract Num', 'width': 120.0},
      {'key': 'customer_name', 'label': 'Customer', 'width': 180.0},
      {'key': 'product_code', 'label': 'Product Code', 'width': 150.0},
      {'key': 'description', 'label': 'Description', 'width': 220.0},
      {'key': 'quantity', 'label': 'QTY', 'width': 70.0},
      {'key': 'value', 'label': 'Value', 'width': 110.0},
      {'key': 'sales_engineer', 'label': 'Sales Engineer', 'width': 150.0},
      {'key': 'factory', 'label': 'Factory', 'width': 120.0},
    ];

    String valueFor(SAPMainOrder o, String key) {
      switch (key) {
        case 'status': return o.status;
        case 'design_order': return o.designOrder;
        case 'contract_number': return o.contractNumber;
        case 'customer_name': return o.customerName;
        case 'product_code': return o.productCode;
        case 'description': return o.description;
        case 'quantity': return o.quantity.toString();
        case 'value': return o.value.toString();
        case 'sales_engineer': return o.salesEngineer;
        case 'factory': return o.factory ?? '-';
        default: return '-';
      }
    }

    return Scrollbar(
      thumbVisibility: true,
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: SingleChildScrollView(
          child: DataTable(
            headingRowHeight: 38,
            dataRowMinHeight: 38,
            dataRowMaxHeight: 48,
            columnSpacing: 18,
            headingTextStyle: GoogleFonts.cairo(
              fontSize: 10,
              fontWeight: FontWeight.w700,
              color: _textColor,
            ),
            dataTextStyle: GoogleFonts.cairo(
              fontSize: 10,
              color: _textColor,
            ),
            columns: columns
                .map((c) => DataColumn(
              label: SizedBox(
                width: c['width'] as double,
                child: Text(c['label'] as String),
              ),
            ))
                .toList(),
            rows: _doneOrders.map((order) {
              return DataRow(
                cells: columns.map((c) {
                  final key = c['key'] as String;
                  return DataCell(
                    SizedBox(
                      width: c['width'] as double,
                      child: Text(
                        valueFor(order, key),
                        overflow: TextOverflow.ellipsis,
                        maxLines: 1,
                      ),
                    ),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => OrderTrackingPage(order: order),
                        ),
                      ).then((_) => _refreshAfterTracking());
                    },
                  );
                }).toList(),
              );
            }).toList(),
          ),
        ),
      ),
    );
  }

  Widget _buildTableContainer() {
    if (_isLoading && !_initialLoadDone)
      return Center(child: CircularProgressIndicator(color: Theme.of(context).colorScheme.primary));
    if (_allOrders.isEmpty)
      return Center(
        child: Text(
          'No orders',
          style: GoogleFonts.cairo(
            color: _secondaryTextColor,
            fontSize: 14,
          ),
        ),
      );
    return SelectionArea(
      child: _buildExpandableSections(),
    );
  }

  Widget _buildExpandableSections() {
    final pinnedColumns = _tableColumns
        .where((column) => _pinnedColumns.contains(column['key']))
        .toList();

    final unpinnedColumns = _tableColumns
        .where((column) => !_pinnedColumns.contains(column['key']))
        .toList();

    final pinnedWidth =
        260 +
            pinnedColumns.fold<double>(
              0,
                  (sum, column) => sum + (column['width'] as double),
            );

    final scrollingWidth = unpinnedColumns.fold<double>(
      0,
          (sum, column) => sum + (column['width'] as double),
    );

    return Container(
      decoration: BoxDecoration(
        color: _surfaceColor,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _borderColor),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ============================================================
          // PINNED AREA
          // Name + user-pinned columns
          // ============================================================
          SizedBox(
            width: pinnedWidth,
            child: Column(
              children: [
                SizedBox(
                  height: 48,
                  child: Row(
                    children: [
                      SizedBox(
                        width: 260,
                        child: _buildNameHeader(),
                      ),

                      ...pinnedColumns.map(
                            (column) => _buildPinnedHeader(
                          column['key'] as String,
                          column['label'] as String,
                          column['width'] as double,
                        ),
                      ),
                    ],
                  ),
                ),

                Expanded(
                  child: NotificationListener<ScrollNotification>(
                    onNotification: _onLeftScrollNotification,
                    child: ListView.builder(
                      controller: _leftVerticalScrollController,
                      itemCount: _flatList.length,
                      addAutomaticKeepAlives: false,
                      addRepaintBoundaries: true,
                      itemExtentBuilder: (index, details) =>
                      _flatList[index] is String ? 44.0 : 48.0,
                      itemBuilder: (_, i) {
                        final item = _flatList[i];

                        // Section header
                        if (item is String) {
                          return SizedBox(
                            height: 44,
                            child: Row(
                              children: [
                                SizedBox(
                                  width: 260,
                                  child: _buildSectionHeader(
                                    item,
                                    _groupedOrders[item]!,
                                  ),
                                ),

                                ...pinnedColumns.map(
                                      (column) => SizedBox(
                                    width: column['width'] as double,
                                    child: _buildPinnedSectionPlaceholder(
                                      item,
                                      _groupedOrders[item]!,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          );
                        }

                        final order = item as SAPMainOrder;

                        return Row(
                          children: [
                            SizedBox(
                              width: 260,
                              child: _buildNameCell(
                                order,
                                _orderIndexMap[order] ?? 0,
                              ),
                            ),

                            ...pinnedColumns.map(
                                  (column) => _buildPinnedDataCell(
                                order,
                                column['key'] as String,
                                column['width'] as double,
                              ),
                            ),
                          ],
                        );
                      },
                    ),
                  ),
                ),
              ],
            ),
          ),

          // ============================================================
          // SCROLLING AREA
          // ============================================================
          Expanded(
            child: NotificationListener<ScrollNotification>(
              onNotification: (n) =>
              n.metrics.axis == Axis.vertical ? true : false,
              child: Scrollbar(
                controller: _horizontalScrollController,
                thumbVisibility: true,
                trackVisibility: true,
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  controller: _horizontalScrollController,
                  child: SizedBox(
                    width: scrollingWidth,
                    child: Column(
                      children: [
                        _buildColumnHeaders(
                          columns: unpinnedColumns,
                        ),

                        Expanded(
                          child: NotificationListener<ScrollNotification>(
                            onNotification: _onRightScrollNotification,
                            child: ListView.builder(
                              controller: _rightVerticalScrollController,
                              itemCount: _flatList.length,
                              addAutomaticKeepAlives: false,
                              addRepaintBoundaries: true,
                              itemExtentBuilder: (index, details) =>
                              _flatList[index] is String ? 44.0 : 48.0,
                              itemBuilder: (_, i) {
                                final item = _flatList[i];

                                if (item is String) {
                                  return _buildSectionHeaderPlaceholder(
                                    item,
                                    _groupedOrders[item]!,
                                  );
                                }

                                final order = item as SAPMainOrder;

                                return _buildDataRow(
                                  order,
                                  _orderIndexMap[order] ?? 0,
                                  columns: unpinnedColumns,
                                );
                              },
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPinnedHeader(
      String key,
      String label,
      double width,
      ) {
    final isPinned = _isColumnPinned(key);

    return Container(
      width: width,
      height: 48,
      padding: const EdgeInsets.symmetric(horizontal: 8),
      decoration: BoxDecoration(
        color: _headerBgColor,
        border: Border(
          bottom: BorderSide(color: _borderColor),
          right: BorderSide(
            color: _borderColor,
            width: 1,
          ),
        ),
      ),
      child: Stack(
        children: [
          // Column title
          Positioned.fill(
            child: Center(
              child: Padding(
                padding: const EdgeInsets.only(right: 18),
                child: Text(
                  label,
                  style: GoogleFonts.cairo(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: _textColor,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ),
          ),

          // Pin icon overlay
          Positioned(
            right: 0,
            top: 0,
            bottom: 0,
            child: InkWell(
              onTap: () => _toggleColumnPin(key),
              borderRadius: BorderRadius.circular(4),
              child: Opacity(
                opacity: 0.5,
                child: Padding(
                  padding: const EdgeInsets.all(3),
                  child: Icon(
                    Icons.push_pin,
                    size: 15,
                    color: Theme.of(context).colorScheme.primary,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(String status, List<SAPMainOrder> orders) {
    final isExpanded = _expandedSections.contains(status);
    final allSelected = orders.every((o) => _selectedRowsIds.contains(o.id));
    return GestureDetector(
      onTap: () => _toggleSection(status),
      child: Container(
        height: 44,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        decoration: BoxDecoration(
          color: _getStatusColor(status).withOpacity(0.08),
          border: Border(
            bottom: BorderSide(color: _borderColor),
            right: BorderSide(color: _borderColor, width: 2),
          ),
        ),
        child: Row(
          children: [
            Icon(
              isExpanded ? Icons.expand_less : Icons.expand_more,
              size: 18,
              color: _getStatusColor(status),
            ),
            const SizedBox(width: 6),
            Container(
              width: 10,
              height: 10,
              decoration: BoxDecoration(
                color: _getStatusColor(status),
                shape: BoxShape.circle,
              ),
            ),
            const SizedBox(width: 6),
            Expanded(
              child: Text(
                _getStatusLabel(status),
                style: GoogleFonts.cairo(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: _getStatusColor(status),
                ),
                overflow: TextOverflow.ellipsis,
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
              decoration: BoxDecoration(
                color: _getStatusColor(status).withOpacity(0.15),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                '${orders.length}',
                style: GoogleFonts.cairo(
                  fontSize: 10,
                  fontWeight: FontWeight.w700,
                  color: _getStatusColor(status),
                ),
              ),
            ),
            const SizedBox(width: 8),
            SizedBox(
              width: 20,
              height: 20,
              child: Checkbox(
                value: allSelected,
                onChanged: (v) => _selectAllInSection(status),
                activeColor: _getStatusColor(status),
                materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                visualDensity: VisualDensity.compact,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEditModeButton() {
    return OutlinedButton.icon(
      onPressed: () => setState(() => _editMode = !_editMode),
      icon: Icon(
        _editMode ? Icons.edit : Icons.edit_outlined,
        size: 16,
        color: _editMode ? Colors.white : const Color(0xFFE69D00),
      ),
      label: Text(
        _editMode ? 'Edit Mode (ON)' : 'Edit Mode',
        style: GoogleFonts.cairo(
          fontSize: 11,
          fontWeight: FontWeight.w600,
          color: _editMode ? Colors.white : const Color(0xFFE69D00),
        ),
      ),
      style: OutlinedButton.styleFrom(
        foregroundColor: const Color(0xFFE69D00),
        side: BorderSide(
          color: const Color(0xFFE69D00),
        ),
        backgroundColor: _editMode ? const Color(0xFFE69D00) : _surfaceColor,
        minimumSize: const Size(0, 38),
        maximumSize: const Size(double.infinity, 38),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 0),
        tapTargetSize: MaterialTapTargetSize.shrinkWrap,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(7)),
      ),
    );
  }


  Widget _buildMyWorkButton({bool isMobile = false}) {
    final hasMyWork = _filterMyWork;
    final myName = widget.loggedInEmployee?.fullName ?? '';

    // Count my work items
    final myWorkCount = _allOrders.where((o) {
      return o.responsibleEngineer == myName ||
          o.reviewer == myName ||
          o.correspondenceEngineer == myName;
    }).length;

    return OutlinedButton.icon(
      onPressed: _applyMyWorkFilter,
      icon: Icon(
        hasMyWork ? Icons.work : Icons.work_outline,
        size: isMobile ? 24 : 16,
        color: hasMyWork ? Colors.white : const Color(0xFF6366F1),
      ),
      label: Text(
        hasMyWork ? 'My Work ($myWorkCount)' : 'My Work',
        style: GoogleFonts.cairo(
          fontSize: isMobile ? 15 : 11,
          fontWeight: FontWeight.w700,
          color: hasMyWork ? Colors.white : const Color(0xFF6366F1),
        ),
      ),
      style: OutlinedButton.styleFrom(
        foregroundColor: const Color(0xFF6366F1),
        side: BorderSide(
          color: const Color(0xFF6366F1),
        ),
        backgroundColor: hasMyWork ? const Color(0xFF6366F1) : _surfaceColor,
        minimumSize: Size(0, isMobile ? 50 : 38),
        maximumSize: Size(double.infinity, isMobile ? 50 : 38),
        padding: EdgeInsets.symmetric(horizontal: isMobile ? 14 : 10, vertical: 0),
        tapTargetSize: MaterialTapTargetSize.shrinkWrap,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(isMobile ? 13 : 7),
        ),
      ),
    );
  }

  Widget _buildSectionHeaderPlaceholder(
      String status,
      List<SAPMainOrder> orders,
      ) {
    final isExpanded = _expandedSections.contains(status);
    return GestureDetector(
      onTap: () => _toggleSection(status),
      child: Container(
        height: 44,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        decoration: BoxDecoration(
          color: _getStatusColor(status).withOpacity(0.08),
          border: Border(bottom: BorderSide(color: _borderColor)),
        ),
        child: Row(children: [const Spacer()]),
      ),
    );
  }

  Widget _buildNameHeader() => Container(
    height: 48,
    padding: const EdgeInsets.symmetric(horizontal: 10),
    decoration: BoxDecoration(
      color: _headerBgColor,
      border: Border(
        bottom: BorderSide(color: _borderColor),
        right: BorderSide(
          color: _borderColor,
          width: 2,
        ),
      ),
    ),
    child: Row(
      children: [
        const SizedBox(width: 24, height: 24),
        const SizedBox(width: 8),

        Expanded(
          child: Row(
            children: [
              Icon(
                Icons.push_pin,
                size: 14,
                color: Theme.of(context).colorScheme.primary,
              ),
              const SizedBox(width: 5),
              Text(
                'Name',
                style: GoogleFonts.cairo(
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  color: _textColor,
                ),
              ),
            ],
          ),
        ),

        if (_isAdmin)
          SizedBox(
            width: 36,
            child: Icon(
              Icons.track_changes,
              size: 16,
              color: _secondaryTextColor,
            ),
          ),
      ],
    ),
  );



  Widget _buildNameCell(SAPMainOrder order, int index) {
    if (widget.readOnly) {
      return Container(
        height: 48,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        alignment: Alignment.centerLeft,
        decoration: BoxDecoration(
          color: _surfaceColor,
          border: Border(
            bottom: BorderSide(color: _borderColor.withOpacity(0.3)),
            right: BorderSide(color: _borderColor, width: 2),
          ),
        ),
        child: ClipRect(
          child: ImageFiltered(
            // Keep the real customer name in the widget, but make it strongly
            // blurred for guest/read-only viewers.
            imageFilter: ui.ImageFilter.blur(sigmaX: 8, sigmaY: 8),
            child: ExcludeSemantics(
              child: Text(
                order.customerName,
                style: GoogleFonts.cairo(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: _textColor,
                ),
                overflow: TextOverflow.ellipsis,
                maxLines: 2,
              ),
            ),
          ),
        ),
      );
    }
    final isSelected = _selectedRowsIds.contains(order.id);
    return GestureDetector(
      onTap: () => _toggleRowSelection(order),
      onLongPress: () {
        // Copy only the customer name
        _copyFieldToClipboard('Customer Name', order.customerName);
      },
      child: Container(
        height: 48,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        decoration: BoxDecoration(
          color: isSelected
              ? const Color(0xFF001761).withOpacity(_isDarkMode ? 0.3 : 0.15)
              : _surfaceColor,
          border: Border(
            bottom: BorderSide(color: _borderColor.withOpacity(0.3)),
            right: BorderSide(color: _borderColor, width: 2),
          ),
        ),
        child: Row(
          children: [
            SizedBox(
              width: 24,
              height: 24,
              child: Checkbox(
                value: isSelected,
                onChanged: (v) => _toggleRowSelection(order),
                activeColor: const Color(0xFF6366F1),
                materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                visualDensity: VisualDensity.compact,
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: (_editMode &&
                  _isOrderEditable(order) &&
                  (!_isOrderLocked(order) || _canEditPdcContract(order)))
                  ? Builder(
                builder: (context) {
                  const field = 'customer_name';
                  final editKey = '${order.id}_$field';
                  final controller = _editControllers.putIfAbsent(
                    editKey,
                        () => TextEditingController(
                      text: order.customerName,
                    ),
                  );

                  return SizedBox(
                    height: 32,
                    child: TextField(
                      controller: controller,
                      maxLines: 1,
                      style: GoogleFonts.cairo(
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                        color: _textColor,
                      ),
                      decoration: InputDecoration(
                        isDense: true,
                        hintText: 'Customer name',
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 6,
                          vertical: 7,
                        ),
                        filled: true,
                        fillColor: Colors.orange.withOpacity(0.05),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(4),
                          borderSide: BorderSide(
                            color: Colors.orange.withOpacity(0.5),
                          ),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(4),
                          borderSide: const BorderSide(
                            color: Colors.orange,
                            width: 1.2,
                          ),
                        ),
                      ),
                      onChanged: (value) => _scheduleInlineSave(
                        order,
                        field,
                        value,
                        order.customerName,
                        editKey,
                      ),
                      onSubmitted: (value) async {
                        await _flushInlineSave(
                          order,
                          field,
                          value,
                          order.customerName,
                          editKey,
                        );
                        FocusManager.instance.primaryFocus?.unfocus();
                      },
                      onTapOutside: (_) async {
                        await _flushInlineSave(
                          order,
                          field,
                          controller.text,
                          order.customerName,
                          editKey,
                        );
                        FocusManager.instance.primaryFocus?.unfocus();
                      },
                    ),
                  );
                },
              )
                  : Text(
                order.customerName,
                style: GoogleFonts.cairo(
                  fontSize: 13,
                  fontWeight: FontWeight.w500,
                  color: _textColor,
                ),
                overflow: TextOverflow.ellipsis,
                maxLines: 2,
              ),
            ),
            // Add tracking icon for admin users
            if (_isHedOrManager || _isDataEntry)
              SizedBox(
                width: 36,
                child: IconButton(
                  icon: const Icon(
                    Icons.track_changes,
                    size: 16,
                    color: Color(0xFF6366F1),
                  ),
                  onLongPress: () {
                    if (_isAdmin) {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => OrderDetailPage(
                            order: order,
                            sapService: widget.sapService,
                          ),
                        ),
                      );
                    }

                  },
                  onPressed: () => _navigateToOrderTracking(order),
                  tooltip: 'Track Order',
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(),
                  splashRadius: 16,
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildScrollableHeader(
      String key,
      String label,
      double width,
      ) {
    final isPinned = _isColumnPinned(key);

    return Container(
      width: width,
      height: 48,
      padding: const EdgeInsets.symmetric(horizontal: 8),
      decoration: BoxDecoration(
        color: _headerBgColor,
        border: Border(
          right: BorderSide(
            color: _borderColor,
            width: 1,
          ),
        ),
      ),
      child: Stack(
        children: [
          // Text stays centered
          Positioned.fill(
            child: Center(
              child: Padding(
                padding: const EdgeInsets.only(right: 18),
                child: Text(
                  label,
                  style: GoogleFonts.cairo(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: _textColor,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ),
          ),

          // Pin icon overlay
          Positioned(
            right: 0,
            top: 0,
            bottom: 0,
            child: InkWell(
              onTap: () => _toggleColumnPin(key),
              borderRadius: BorderRadius.circular(4),
              child: Opacity(
                opacity: isPinned ? 0.5 : 0.25,
                child: Padding(
                  padding: const EdgeInsets.all(3),
                  child: Icon(
                    isPinned
                        ? Icons.push_pin
                        : Icons.push_pin_outlined,
                    size: 15,
                    color: Theme.of(context).colorScheme.primary,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }


  Widget _buildColumnHeaders({
    required List<Map<String, dynamic>> columns,
  }) {
    return Container(
      height: 48,
      decoration: BoxDecoration(
        color: _headerBgColor,
        border: Border(
          bottom: BorderSide(color: _borderColor),
        ),
      ),
      child: Row(
        children: columns.map((column) {
          final key = column['key'] as String;
          final label = column['label'] as String;
          final width = column['width'] as double;

          return _buildScrollableHeader(
            key,
            label,
            width,
          );
        }).toList(),
      ),
    );
  }

  String _readOnlyCellText(SAPMainOrder order, String key) {
    // Guest viewers get plain text for every column: no dropdowns, status
    // controls, inline editors, or assignment actions.
    switch (key) {
      case 'status': return order.status;
      case 'item': return order.itemNumber;
      case 'product_code': return order.productCode;
      case 'contract_number': return order.contractNumber;
      case 'description': return order.description;
      case 'design_order': return order.designOrder;
      case 'quantity': return order.quantity.toString();
      case 'unit': return order.unitOfMeasure;
      case 'value': return _formatNumber(order.value);
      case 'sales_engineer': return order.salesEngineer;
      case 'order_date': return order.orderDate ?? '-';
      case 'end_date': return order.endDate ?? '-';
      case 'delivery_date': return order.deliveryDate ?? '-';
      case 'factory':
        final code = order.factory?.trim() ?? '';
        final name = _factoryDescriptions[code.toLowerCase()]?.trim();
        return !_isDataEntry && name?.isNotEmpty == true
            ? name!
            : (code.isEmpty ? '-' : code);
      case 'design_team': return order.designTeam ?? '-';
      case 'responsible_engineer': return order.responsibleEngineer ?? '-';
      case 'reviewer': return order.reviewer ?? '-';
      case 'correspondence_engineer': return order.correspondenceEngineer ?? '-';
      case 'created_at_tracking':
        return order.createdAt == null
            ? ''
            : DateFormat('yyyy-MM-dd').format(order.createdAt!.toLocal());
      case 'drawing_approval_date':
      case 'sales_approval_date':
      case 'modifications_count':
      case 'modifications_last_date':
      case 'operation_date':
        return _approvalTrackingByOrder[order.id]?[key] ?? '';
      default: return '-';
    }
  }

  Widget _buildColumnCell(
      SAPMainOrder order,
      String key,
      double width,
      ) {
    if (widget.approvalTrackingMode) {
      return Container(
        width: width,
        height: 48,
        alignment: Alignment.centerLeft,
        padding: const EdgeInsets.symmetric(horizontal: 8),
        child: Text(
          _readOnlyCellText(order, key),
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: GoogleFonts.cairo(
            fontSize: 11,
            color: _textColor,
            fontWeight: key == 'modifications_count'
                ? FontWeight.w700
                : FontWeight.w400,
          ),
        ),
      );
    }
    if (widget.readOnly) {
      return Container(
        width: width,
        height: 48,
        alignment: Alignment.centerLeft,
        padding: const EdgeInsets.symmetric(horizontal: 8),
        child: Text(
          _readOnlyCellText(order, key),
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
          style: GoogleFonts.cairo(fontSize: 11, color: _textColor),
        ),
      );
    }

    switch (key) {
      case 'status':
        return SizedBox(
          width: width,
          child: _statusCell(
            order.status,
            order,
          ),
        );

      case 'item':
        return _editableCell(
          order.itemNumber,
          width,
          order,
          'item_number',
          'Item',
        );

      case 'product_code':
        return _editableCell(
          order.productCode,
          width,
          order,
          'product_code',
          'Product Code',
          style: GoogleFonts.cairo(
            fontSize: 11,
            color: _textColor,
          ),
        );

      case 'contract_number':
        return _editableCell(
          order.contractNumber,
          width,
          order,
          'contract_number',
          'Contract Number',
        );

      case 'description':
        return _editableCell(
          order.description,
          width,
          order,
          'description',
          'Description',
          overflow: TextOverflow.ellipsis,
          maxLines: 2,
        );

      case 'design_order':
        return _editableCell(
          order.designOrder,
          width,
          order,
          'design_order',
          'Design Order',
          style: GoogleFonts.cairo(
            fontSize: 12,
            fontWeight: FontWeight.w600,
            color: const Color(0xFF6366F1),
          ),
        );

      case 'quantity':
        return _editableCell(
          '${order.quantity}',
          width,
          order,
          'quantity',
          'QTY',
          align: TextAlign.right,
        );

      case 'unit':
        return _editableCell(
          order.unitOfMeasure,
          width,
          order,
          'unit_of_measure',
          'Unit',
        );

      case 'value':
        return _editableCell(
          _formatNumber(order.value),
          width,
          order,
          'value',
          'Value',
          align: TextAlign.right,
          style: GoogleFonts.cairo(
            fontSize: 12,
            fontWeight: FontWeight.w600,
            color: const Color(0xFF059669),
          ),
        );

      case 'sales_engineer':
        return _editableCell(
          order.salesEngineer,
          width,
          order,
          'sales_engineer',
          'Sales Engineer',
        );

      case 'order_date':
        return _editableCell(
          order.orderDate ?? '-',
          width,
          order,
          'order_date',
          'Order Date',
        );

      case 'end_date':
        return _editableCell(
          order.endDate ?? '-',
          width,
          order,
          'end_date',
          'End Date',
        );

      case 'delivery_date':
        return _editableCell(
          order.deliveryDate ?? '-',
          width,
          order,
          'delivery_date',
          'Delivery Date',
        );

      case 'factory':
        final factoryCode = order.factory?.trim() ?? '';
        final factoryName = _factoryDescriptions[factoryCode.toLowerCase()]?.trim();
        return _editableCell(
          factoryCode.isEmpty ? '-' : factoryCode,
          width,
          order,
          'factory',
          'Factory',
          // Data Entry sees the SAP factory code. Other departments see the
          // factory name, matching the Excel export. Keep the stored/edit value
          // as the original code so displaying a name never overwrites the code.
          displayText: _isDataEntry
              ? (factoryCode.isEmpty ? '-' : factoryCode)
              : (factoryName?.isNotEmpty == true ? factoryName! : (factoryCode.isEmpty ? '-' : factoryCode)),
        );

      case 'design_team':
        return SizedBox(
          width: width,
          child: _designTeamDropdownCell(
            order.designTeam,
            order,
          ),
        );

      case 'responsible_engineer':
        return SizedBox(
          width: width,
          child: _employeeDropdownCell(
            order.responsibleEngineer,
            order,
            'responsible_engineer',
          ),
        );

      case 'reviewer':
        return SizedBox(
          width: width,
          child: _employeeDropdownCell(
            order.reviewer,
            order,
            'reviewer',
          ),
        );

      case 'correspondence_engineer':
        return SizedBox(
          width: width,
          child: _employeeDropdownCell(
            order.correspondenceEngineer,
            order,
            'correspondence_engineer',
          ),
        );

      default:
        return SizedBox(
          width: width,
        );
    }
  }

  Widget _buildPinnedDataCell(
      SAPMainOrder order,
      String key,
      double width,
      ) {
    return Container(
      width: width,
      height: 48,
      decoration: BoxDecoration(
        color: _selectedRowsIds.contains(order.id)
            ? const Color(0xFF001761).withOpacity(
          _isDarkMode ? 0.3 : 0.15,
        )
            : _surfaceColor,
        border: Border(
          bottom: BorderSide(
            color: _borderColor.withOpacity(0.3),
          ),
          right: BorderSide(
            color: _borderColor,
            width: 1,
          ),
        ),
      ),
      child: _buildColumnCell(
        order,
        key,
        width,
      ),
    );
  }

  Widget _buildPinnedSectionPlaceholder(
      String status,
      List<SAPMainOrder> orders,
      ) {
    return Container(
      height: 44,
      decoration: BoxDecoration(
        color: _getStatusColor(status).withOpacity(0.08),
        border: Border(
          bottom: BorderSide(
            color: _borderColor,
          ),
          right: BorderSide(
            color: _borderColor,
            width: 1,
          ),
        ),
      ),
    );
  }

  Widget _buildDataRow(
      SAPMainOrder order,
      int index, {
        required List<Map<String, dynamic>> columns,
      }) {
    final isSelected = _selectedRowsIds.contains(order.id);

    return GestureDetector(


      child: Container(
        height: 48,
        decoration: BoxDecoration(
          color: isSelected
              ? const Color(0xFF001761).withOpacity(
            _isDarkMode ? 0.3 : 0.15,
          )
              : _surfaceColor,
          border: Border(
            bottom: BorderSide(
              color: _borderColor.withOpacity(0.3),
            ),
          ),
        ),
        child: Row(
          children: columns.map((column) {
            final key = column['key'] as String;
            final width = column['width'] as double;

            return _buildColumnCell(
              order,
              key,
              width,
            );
          }).toList(),
        ),
      ),
    );
  }

  Widget _editableCell(
      String text,
      double w,
      SAPMainOrder order,
      String field,
      String fieldLabel, {
        TextAlign align = TextAlign.left,
        TextStyle? style,
        TextOverflow overflow = TextOverflow.ellipsis,
        int maxLines = 1,
        String? displayText,
      }) {
    final canEdit = _isOrderEditable(order);
    final isDateField =
        field == 'order_date' ||
            field == 'delivery_date' ||
            field == 'end_date';

    // ============================================
    // EDIT MODE
    // ============================================
    if (_editMode && canEdit &&
        (!_isOrderLocked(order) || _canEditPdcContract(order))) {
      final editKey = '${order.id}_$field';

      // Create controller only once for this cell
      final controller = _editControllers.putIfAbsent(
        editKey,
            () => TextEditingController(
          text: text == '-' ? '' : text,
        ),
      );

      if (isDateField) {
        return SizedBox(
          width: w,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 2),
            child: InkWell(
              onTap: () => _pickDateForEdit(
                order,
                field,
                text,
              ),
              onLongPress: () {
                final copyValue = text == '-' ? '' : text;
                _copyFieldToClipboard(
                  fieldLabel,
                  copyValue,
                );
              },
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 4,
                  vertical: 3,
                ),
                decoration: BoxDecoration(
                  border: Border.all(
                    color: Colors.orange.withOpacity(0.5),
                  ),
                  borderRadius: BorderRadius.circular(4),
                  color: Colors.orange.withOpacity(0.05),
                ),
                child: Row(
                  children: [
                    const Icon(
                      Icons.calendar_today,
                      size: 10,
                      color: Colors.orange,
                    ),
                    const SizedBox(width: 3),
                    Expanded(
                      child: Text(
                        text,
                        style: style ??
                            GoogleFonts.cairo(
                              fontSize: 12,
                              color: _textColor,
                            ),
                        overflow: overflow,
                        maxLines: maxLines,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      }

      // ============================================
      // NORMAL TEXT FIELD INSIDE THE CELL
      // ============================================
      return SizedBox(
        width: w,
        child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 2),
            child: SizedBox(
              width: w,
              height: 32,
              child: TextField(
                controller: controller,
                textAlign: align,
                maxLines: 1,
                keyboardType:
                field == 'quantity' || field == 'value'
                    ? TextInputType.number
                    : TextInputType.text,
                style: style ??
                    GoogleFonts.cairo(
                      fontSize: 12,
                      color: _textColor,
                    ),
                decoration: InputDecoration(
                  isDense: true,
                  contentPadding: const EdgeInsets.symmetric(
                    horizontal: 6,
                    vertical: 7,
                  ),
                  filled: true,
                  fillColor: Colors.orange.withOpacity(0.05),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(4),
                    borderSide: BorderSide(
                      color: Colors.orange.withOpacity(0.5),
                    ),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(4),
                    borderSide: const BorderSide(
                      color: Colors.orange,
                      width: 1.2,
                    ),
                  ),
                ),
                // Save automatically while typing (debounced), without
                // requiring Enter or leaving the cell.
                onChanged: (value) {
                  _scheduleInlineSave(
                    order,
                    field,
                    value,
                    text,
                    editKey,
                  );
                },
                // Enter flushes any pending change immediately.
                onSubmitted: (value) async {
                  await _flushInlineSave(
                    order,
                    field,
                    value,
                    text,
                    editKey,
                  );
                  FocusManager.instance.primaryFocus?.unfocus();
                },
                // Leaving the cell also flushes the latest value.
                onTapOutside: (_) async {
                  await _flushInlineSave(
                    order,
                    field,
                    controller.text,
                    text,
                    editKey,
                  );
                  FocusManager.instance.primaryFocus?.unfocus();
                },
              ),
            )
        ),
      );
    }

    // ============================================
    // NORMAL NON-EDIT MODE
    // ============================================
    return SizedBox(
      width: w,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 4),
        child: GestureDetector(
          onLongPress: () {
            final copyValue = text == '-' ? '' : text;
            _copyFieldToClipboard(
              fieldLabel,
              copyValue,
            );
          },
          child: Align(
            alignment: align == TextAlign.right
                ? Alignment.centerRight
                : Alignment.centerLeft,
            child: Text(
              displayText ?? text,
              style: style ??
                  GoogleFonts.cairo(
                    fontSize: 12,
                    color: _textColor,
                  ),
              overflow: overflow,
              maxLines: maxLines,
            ),
          ),
        ),
      ),
    );
  }

  // Debounce database writes while the user is typing. Each cell has its
  // own timer, so editing another cell/row cannot overwrite this value.
  void _scheduleInlineSave(
      SAPMainOrder order,
      String field,
      String newValue,
      String originalValue,
      String editKey,
      ) {
    _inlineSaveTimers[editKey]?.cancel();
    _inlineSaveTimers[editKey] = Timer(const Duration(milliseconds: 650), () {
      _inlineSaveTimers.remove(editKey);
      _saveInlineEdit(
        order,
        field,
        newValue,
        _inlineLastSavedValues[editKey] ?? originalValue,
        editKey,
        showFeedback: false,
      );
    });
  }

  // Cancel the debounce and persist the latest value now.
  Future<void> _flushInlineSave(
      SAPMainOrder order,
      String field,
      String newValue,
      String originalValue,
      String editKey,
      ) async {
    _inlineSaveTimers.remove(editKey)?.cancel();
    await _saveInlineEdit(
      order,
      field,
      newValue,
      _inlineLastSavedValues[editKey] ?? originalValue,
      editKey,
      showFeedback: true,
    );
  }

  // Save inline edit
  Future<void> _saveInlineEdit(
      SAPMainOrder order,
      String field,
      String newValue,
      String oldValue,
      String editKey, {
        bool showFeedback = true,
      }) async {
    newValue = newValue.trim();

    if (_inlineSavingKeys.contains(editKey)) {
      // A previous write is still in flight. Queue the newest value after it
      // completes instead of allowing out-of-order updates.
      _scheduleInlineSave(order, field, newValue, oldValue, editKey);
      return;
    }

    // When multiple rows are selected in edit mode, propagate this cell's
    // value to every selected row instead of saving only the active row.
    // Include the active row in case it was not part of the selection set.
    if (_editMode && _selectedRowsIds.length > 1) {
      final activeRowAlreadySelected = _selectedRowsIds.contains(order.id);
      await _applyBulkEditToSelected(
        field,
        newValue,
        includeOrderId: activeRowAlreadySelected ? null : order.id,
      );
      _inlineLastSavedValues[editKey] = newValue;
      return;
    }

    if (newValue == oldValue ||
        (oldValue == '-' && newValue.isEmpty)) {
      return;
    }

    _inlineSavingKeys.add(editKey);

    try {
      final supabase = Supabase.instance.client;

      dynamic parsedValue = newValue;

      if (field == 'quantity') {
        parsedValue =
            double.tryParse(
              newValue.replaceAll(',', ''),
            ) ??
                0;
      } else if (field == 'value') {
        parsedValue =
            double.tryParse(
              newValue
                  .replaceAll(',', '')
                  .replaceAll('\$', ''),
            ) ??
                0;
      }

      await supabase
          .from(_archivedOrderIds.contains(order.id)
          ? 'sap_done_orders'
          : 'sap_main_orders')
          .update({
        field: parsedValue,
      })
          .eq('id', order.id);

      await _auditService.logChange(
        orderId: order.id,
        designOrder: order.designOrder,
        fieldName: field,
        oldValue: oldValue == '-' ? '' : oldValue,
        newValue: newValue,
        changedBy: _currentUserName,
        changedById: _currentUserId,
      );

      _updateOrderLocally(
        order.id,
        field,
        parsedValue,
      );
      _inlineLastSavedValues[editKey] = newValue;

      if (showFeedback) {
        _showSnackBar('${_formatFieldName(field)} updated!');
      }
    } catch (e) {
      if (showFeedback) {
        _showSnackBar('Error updating: $e');
      } else {
        debugPrint('Realtime inline save failed for $editKey: $e');
      }
    } finally {
      _inlineSavingKeys.remove(editKey);
      // If the user typed again while the request was running, the scheduled
      // timer will persist that newer text.
    }
  }

  // Apply bulk edit to all selected rows (inline)
  Future<void> _applyBulkEditToSelected(
      String field,
      String newValue, {
        String? includeOrderId,
      }) async {
    final targetIds = <String>{..._selectedRowsIds};
    if (includeOrderId != null) targetIds.add(includeOrderId);

    // Check whether any target row is locked.
    final availableOrders = <String, SAPMainOrder>{
      for (final order in _allOrders) order.id: order,
      for (final order in (_searchResults ?? const <SAPMainOrder>[]))
        order.id: order,
    };
    final lockedOrders = availableOrders.values
        .where((o) => targetIds.contains(o.id) && _isOrderLocked(o))
        .toList();

    if (lockedOrders.isNotEmpty) {
      _showSnackBar('⚠️ Cannot bulk edit: ${lockedOrders.length} locked order(s) selected (Done, Task Done, or Planning)');
      return;
    }

    setState(() => _isLoading = true);
    final supabase = Supabase.instance.client;
    int updated = 0;
    int skipped = 0;

    dynamic parsedValue = newValue;
    if (field == 'quantity') {
      parsedValue = double.tryParse(newValue.replaceAll(',', '')) ?? 0;
    } else if (field == 'value') {
      parsedValue =
          double.tryParse(newValue.replaceAll(',', '').replaceAll('\$', '')) ??
              0;
    }

    for (var orderId in targetIds) {
      final order = availableOrders[orderId];
      if (order != null) {
        // Skip locked orders
        if (_isOrderLocked(order)) {
          skipped++;
          continue;
        }

        // Header rows cannot have an Alternative Engineer, including bulk edits.
        if (field == 'correspondence_engineer' &&
            _isHeaderResponsibleEngineerRow(order)) {
          skipped++;
          continue;
        }

        // Header rows with "No One" are permanently locked for
        // Responsible Engineer, including bulk edits.
        if (field == 'responsible_engineer' &&
            order.responsibleEngineer?.trim().toLowerCase() == 'no one') {
          skipped++;
          continue;
        }

        try {
          await supabase
              .from(_archivedOrderIds.contains(order.id)
              ? 'sap_done_orders'
              : 'sap_main_orders')
              .update({field: parsedValue})
              .eq('id', order.id);

          await _auditService.logChange(
            orderId: order.id,
            designOrder: order.designOrder,
            fieldName: field,
            oldValue: _getCurrentFieldValue(order, field),
            newValue: newValue,
            changedBy: _currentUserName,
            changedById: _currentUserId,
            actionType: 'bulk_update',
          );
          updated++;
        } catch (e) {
          print('Failed to update ${order.id}: $e');
        }
      }
    }

    setState(() => _isLoading = false);
    if (skipped > 0) {
      _showSnackBar('✅ $updated rows updated, ⚠️ $skipped locked rows skipped');
    } else {
      _showSnackBar('✅ $updated rows updated!');
    }
    for (final id in targetIds) {
      _updateOrderLocally(id, field, parsedValue);
    }
  }

  Widget _hdr(String text, double w, [TextAlign a = TextAlign.left]) =>
      SizedBox(
        width: w,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4),
          child: Align(
            alignment: a == TextAlign.right
                ? Alignment.centerRight
                : Alignment.centerLeft,
            child: Text(
              text,
              style: GoogleFonts.cairo(
                fontSize: 11,
                fontWeight: FontWeight.w700,
                color: _textColor,
              ),
            ),
          ),
        ),
      );

  Widget _statusCell(String status, SAPMainOrder order) {
    final allowedStatuses = _getAllowedStatusesForOrder(order);

    return SizedBox(
      width: 140,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 2),
        child: PopupMenuButton<String>(
          onSelected: (newStatus) => _updateOrderStatus(order, newStatus),
          offset: const Offset(0, 40),
          position: PopupMenuPosition.under,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
            decoration: BoxDecoration(
              color: _getStatusColor(status).withOpacity(0.1),
              borderRadius: BorderRadius.circular(4),
              border: Border.all(
                color: _getStatusColor(status).withOpacity(0.3),
              ),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Flexible(
                  child: Text(
                    _getStatusLabel(status),
                    style: GoogleFonts.cairo(
                      fontSize: 10,
                      fontWeight: FontWeight.w600,
                      color: _getStatusColor(status),
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                const SizedBox(width: 2),
                Icon(
                  Icons.arrow_drop_down,
                  size: 14,
                  color: _getStatusColor(status),
                ),
              ],
            ),
          ),
          itemBuilder: (context) => allowedStatuses.map((s) {
            return PopupMenuItem<String>(
              value: s,
              child: Row(
                children: [
                  Container(
                    width: 10,
                    height: 10,
                    decoration: BoxDecoration(
                      color: _getStatusColor(s),
                      shape: BoxShape.circle,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      s,
                      style: GoogleFonts.cairo(
                        fontSize: 12,
                        color: s == status
                            ? _getStatusColor(s)
                            : _textColor,
                        fontWeight: s == status
                            ? FontWeight.w700
                            : FontWeight.w400,
                      ),
                    ),
                  ),
                  if (s == status)
                    Icon(
                      Icons.check,
                      size: 16,
                      color: _getStatusColor(s),
                    ),
                ],
              ),
            );
          }).toList(),
        ),
      ),
    );
  }

  // Allowed status transitions.
  // The "(no body)" routes below mean the order MUST have
  // Responsible Engineer = "No One".
  List<String> _getAllowedStatusesForOrder(SAPMainOrder order) {
    final current = order.status.trim().toLowerCase();

    // The combined SAP Done Orders page must allow archived rows to return
    // to any active workflow status. Their status change will move the row
    // back to sap_main_orders and remove it from sap_done_orders.
    if (widget.doneOrdersOnly && _archivedOrderIds.contains(order.id)) {
      return _allStatuses
          .where((status) => !widget.sapService.isArchivedStatus(status))
          .toList();
    }

    final isHeader =
        order.responsibleEngineer?.trim().toLowerCase() == 'header';

    // Header rows can move anywhere, except the permanently locked
    // statuses which cannot be moved FROM.
    if (isHeader) {
      // A header can move to any status. If its CURRENT status is
      // Done/Task Done/Planning, _isOrderLocked() still prevents moving it.
      return List<String>.from(_allStatuses);
    }

    const transitions = <String, List<String>>{
      'drawing submittal': [
        'Approval',
        'Partition Editing',
      ],
      'approval': [
        'modifications submitted',
        'Manufacturing Drawing',
      ],
      'modifications submitted': [
        'Approval',
      ],
      'manufacturing drawing': [
        'Review',
        'Master Data',
        'partation  master data',
      ],
      'review': [
        'Master Data',
      ],
      'master data': [
      ],
      'sales': [
        'Drawing Submittal',
      ],
      'as built': [
        'Drawing Submittal',
      ],
      'planning': [
        'Drawing Submittal',
      ],
      'partation  master data': [
        'Done',
      ],
      'الادارة الهندسه': [
        'Master Data',
      ],
      'ادارة تصميم المنتجات': [
        'Master Data',
      ],
      'design studio': [
        'Master Data',
      ],
      'partition editing': [
        'Manufacturing Drawing',
        'partation  master data',
      ],
      'imported': [
        'Drawing Submittal',
        'Master Data',
        'planning',
        'الادارة الهندسه',
        'ادارة تصميم المنتجات',
        'design studio',
      ],
      'automated': [
        'Drawing Submittal',
        'Master Data',
        'planning',
        'الادارة الهندسه',
        'ادارة تصميم المنتجات',
        'design studio',
      ],
      'tasks': [
        'Task Done',
      ],
    };

    final noBodyTransitions = <String, List<String>>{
      'drawing submittal': [
        'Sales',
        'As Built',
        'Master Data',
        'planning',
        'ادارة تصميم المنتجات',
        'design studio',
        'الادارة الهندسه',
      ],
      'approval': [
        'Sales',
        'As Built',
        'Master Data',
        'planning',
        'ادارة تصميم المنتجات',
        'design studio',
        'الادارة الهندسه',
      ],
      'sales': [
        'planning',
        'As Built',
        'Master Data',
      ],
      'as built': [
        'Sales',
      ],
      'planning': [
        'As Built',
        'Master Data',
      ],
    };

    final normal = transitions[current] ?? const <String>[];
    final noBody = noBodyTransitions[current] ?? const <String>[];

    final hasNoOne = order.responsibleEngineer?.trim().toLowerCase() == 'no one';

    final result = <String>[
      ...normal,
      if (hasNoOne) ...noBody,
    ];

    // Keep only statuses that actually exist in the user's configured list.
    return result
        .where((target) => _allStatuses.any(
          (configured) =>
      configured.trim().toLowerCase() == target.trim().toLowerCase(),
    ))
        .map((target) => _allStatuses.firstWhere(
          (configured) =>
      configured.trim().toLowerCase() == target.trim().toLowerCase(),
    ))
        .toList();
  }

  bool _isNoBodyDestination(String currentStatus, String newStatus) {
    final current = currentStatus.trim().toLowerCase();
    final target = newStatus.trim().toLowerCase();

    const noBodyTransitions = <String, Set<String>>{
      'drawing submittal': {
        'sales',
        'as built',
        'master data',
        'planning',
        'ادارة تصميم المنتجات',
        'design studio',
        'الادارة الهندسه',
      },
      'approval': {
        'as built',
        'master data',
        'planning',
        'ادارة تصميم المنتجات',
        'design studio',
        'الادارة الهندسه',
      },
      'sales': {
        'planning',
        'as built',
        'master data',
      },
      'as built': {
        'sales',
      },
      'planning': {
        'as built',
        'master data',
      },
    };

    return noBodyTransitions[current]?.contains(target) ?? false;
  }

  Widget _cell(
      String text,
      double w, {
        TextAlign align = TextAlign.left,
        TextStyle? style,
        TextOverflow overflow = TextOverflow.ellipsis,
        int maxLines = 1,
      }) => SizedBox(
    width: w,
    child: Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4),
      child: Align(
        alignment: align == TextAlign.right
            ? Alignment.centerRight
            : Alignment.centerLeft,
        child: Text(
          text,
          style:
          style ??
              GoogleFonts.cairo(fontSize: 12, color: _textColor),
          overflow: overflow,
          maxLines: maxLines,
        ),
      ),
    ),
  );

  Widget _buildSmallBtn(IconData icon, String label, VoidCallback onTap) =>
      TextButton.icon(
        onPressed: onTap,
        icon: Icon(icon, size: 14),
        label: Text(
          label,
          style: GoogleFonts.cairo(fontSize: 11, fontWeight: FontWeight.w600),
        ),
        style: TextButton.styleFrom(
          foregroundColor: const Color(0xFFE69D00),
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(4),
            side: BorderSide(color: const Color(0xFFE69D00).withOpacity(0.3)),
          ),
        ),
      );

  Widget _buildIconBtn(IconData icon, VoidCallback onTap) => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 4),
    child: IconButton(
      onPressed: onTap,
      icon: Icon(icon, color: _secondaryTextColor),
      style: IconButton.styleFrom(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(100)),
      ),
    ),
  );

  Widget _buildActionBtn(IconData icon, String label, VoidCallback onTap) =>
      OutlinedButton.icon(
        onPressed: onTap,
        icon: Icon(icon, size: 16),
        label: Text(
          label,
          style: GoogleFonts.cairo(fontSize: 11, fontWeight: FontWeight.w600),
        ),
        style: OutlinedButton.styleFrom(
          foregroundColor: _secondaryTextColor,
          side: BorderSide(color: _borderColor),
          minimumSize: const Size(0, 38),
          maximumSize: const Size(double.infinity, 38),
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 0),
          tapTargetSize: MaterialTapTargetSize.shrinkWrap,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(7)),
          backgroundColor: _surfaceColor,
        ),
      );

  Widget _buildExportOption(
      IconData icon,
      String label,
      String subtitle,
      Color color,
      VoidCallback onTap,
      ) => GestureDetector(
    onTap: onTap,
    child: Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.2)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: color, size: 32),
          const SizedBox(height: 8),
          Text(
            label,
            style: GoogleFonts.cairo(
              fontWeight: FontWeight.w600,
              fontSize: 14,
              color: color,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            subtitle,
            style: GoogleFonts.cairo(
              fontSize: 10,
              color: _secondaryTextColor,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    ),
  );
}

class _StatusArrangementDialog extends StatefulWidget {
  final List<String> statuses;
  final Function(List<String>) onReorder;
  final VoidCallback onReset;

  const _StatusArrangementDialog({
    required this.statuses,
    required this.onReorder,
    required this.onReset,
  });

  @override
  State<_StatusArrangementDialog> createState() => _StatusArrangementDialogState();
}

class _StatusArrangementDialogState extends State<_StatusArrangementDialog> {
  late List<String> _localStatuses;

  @override
  void initState() {
    super.initState();
    _localStatuses = List.from(widget.statuses);
  }

  @override
  Widget build(BuildContext context) {
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;
    final surfaceColor = isDarkMode ? const Color(0xFF121212) : Colors.white;
    final textColor = isDarkMode ? const Color(0xFFE2E8F0) : const Color(0xFF0F172A);
    final secondaryTextColor = isDarkMode ? const Color(0xFF94A3B8) : const Color(0xFF64748B);
    final borderColor = isDarkMode ? const Color(0xFF334155) : const Color(0xFFE2E8F0);
    final hoverColor = isDarkMode ? const Color(0xFF334155).withOpacity(0.3) : Colors.grey.shade50;

    return AlertDialog(
      title: Row(
        children: [
          Text(
            'Arrange Status Order',
            style: GoogleFonts.cairo(fontWeight: FontWeight.w600, color: textColor),
          ),
          const Spacer(),
          Icon(
            Icons.drag_indicator,
            color: secondaryTextColor,
            size: 20,
          ),
        ],
      ),
      content: SizedBox(
        width: 400,
        height: 500,
        child: Column(
          children: [
            Text(
              '🖱️ Drag and drop to arrange. Changes saved automatically.',
              style: GoogleFonts.cairo(fontSize: 12, color: secondaryTextColor),
            ),
            const SizedBox(height: 12),
            Expanded(
              child: ReorderableListView.builder(
                itemCount: _localStatuses.length,
                onReorder: (oldIndex, newIndex) {
                  setState(() {
                    if (newIndex > oldIndex) {
                      newIndex -= 1;
                    }
                    final item = _localStatuses.removeAt(oldIndex);
                    _localStatuses.insert(newIndex, item);
                  });
                  // Save changes
                  widget.onReorder(List.from(_localStatuses));
                },
                itemBuilder: (context, index) {
                  return Container(
                    key: ValueKey(_localStatuses[index]),
                    margin: const EdgeInsets.only(bottom: 4),
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    decoration: BoxDecoration(
                      color: hoverColor,
                      borderRadius: BorderRadius.circular(6),
                      border: Border.all(color: borderColor),
                    ),
                    child: Row(
                      children: [
                        Icon(
                          Icons.drag_indicator,
                          color: secondaryTextColor,
                          size: 20,
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            '${index + 1}. ${_localStatuses[index]}',
                            style: GoogleFonts.cairo(fontSize: 13, color: textColor),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () {
            widget.onReset();
            setState(() {
              _localStatuses = List.from(widget.statuses);
            });
          },
          child: Text('Reset to Default', style: GoogleFonts.cairo(color: Colors.red)),
        ),
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: Text('Done', style: GoogleFonts.cairo(fontWeight: FontWeight.w600, color: textColor)),
        ),
      ],
    );
  }
}

/// Separate approval-tracking route. It deliberately reuses OrdersPage's
/// established layout, toolbar, table styling, scroll behavior and filters,
/// while enabling the additional audit-derived columns.
class ApprovalTrackingPage extends StatelessWidget {
  final SAPMainService sapService;
  final EmployeeAuth? loggedInEmployee;

  const ApprovalTrackingPage({
    super.key,
    required this.sapService,
    this.loggedInEmployee,
  });

  @override
  Widget build(BuildContext context) {
    // Approval Tracking is pushed from inside the app's zoomable content area.
    // Give it an explicit viewport size and its own Material surface so that
    // PopupMenuButton / InkWell controls have a Material ancestor and the
    // toolbar's LayoutBuilder receives finite width constraints.
    final viewport = MediaQuery.sizeOf(context);

    return SizedBox(
      width: viewport.width,
      height: viewport.height,
      child: Scaffold(
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        body: Material(
          color: Theme.of(context).scaffoldBackgroundColor,
          child: OrdersPage(
            sapService: sapService,
            loggedInEmployee: loggedInEmployee,
            // Keep the same permissions and full controls as the Orders page.
            // Approval Tracking only changes the displayed tracking columns.
            readOnly: false,
            approvalTrackingMode: true,
          ),
        ),
      ),
    );
  }
}

